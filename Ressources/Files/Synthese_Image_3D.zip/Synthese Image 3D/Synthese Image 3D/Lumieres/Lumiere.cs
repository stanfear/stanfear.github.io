﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using Projet_Objets_3D.Utilitaires;
using Projet_Objets_3D.Formes;

namespace Projet_Objets_3D.Lumieres
{
    [Serializable()]
    abstract class Lumiere
    {
        private Color _color;
        public Color Color { get { return _color; } set { _color = value; } }

        public String Nom { get; set; }
        public Double Intensite { get; set; }
        protected Simulation _simulation;

        public Lumiere(Color color, String nom, double intensite)
        {
            this._color = color;
            this.Nom = nom;
            this.Intensite = intensite;
        }

        public void setSimulation(Simulation sim)
        {
            this._simulation = sim;
        }

        public abstract Vector3 GetLightVector(Point3D point, Vector3 vNormalForme);
    }
}
