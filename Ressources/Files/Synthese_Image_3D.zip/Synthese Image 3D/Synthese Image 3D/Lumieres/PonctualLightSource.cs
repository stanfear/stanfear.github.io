﻿using Projet_Objets_3D.Utilitaires;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Projet_Objets_3D.Lumieres
{
    [Serializable()]
    class PonctualLightSource : Lumiere
    {
        private Point3D _position;
        public Point3D Location { get { return _position; } private set { _position = value; } }

        public PonctualLightSource(Point3D localisation)
            : base(System.Drawing.Color.White, "Source Ponctuelle", 1)
        {
            Location = localisation;
        }

        public override Vector3 GetLightVector(Point3D point, Vector3 vNormalForme)
        {
            Vector3 res = _position - point;
            res.Magnitude = this.Intensite;
            return res;
        }
    }
}
