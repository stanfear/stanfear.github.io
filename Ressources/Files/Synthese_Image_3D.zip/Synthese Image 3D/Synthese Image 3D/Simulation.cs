﻿using Projet_Objets_3D.Cameras;
using Projet_Objets_3D.Formes;
using Projet_Objets_3D.Lumieres;
using Projet_Objets_3D.Utilitaires;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading.Tasks;


namespace Projet_Objets_3D
{
    [Serializable()]
    class Simulation
    {
        private List<Forme> LForme;
        private List<Lumiere> LLumiere;
        private List<Camera> LCamera;
        private Size3D tailleSimul;
        private Point3D _centre = Point3D.Origine;
        private Forme[] bordures;

        public String Nom { get; set; }
        public Point3D Centre
        {
            get { return _centre; }
            set
            {
                _centre = value;
                this.UpdateBordures();
            }
        }
        public Size3D TailleSimulation
        {
            get { return tailleSimul; }
            set
            {
                tailleSimul = value;
                this.UpdateBordures();
            }
        }
        public List<Forme> LFormes
        {
            get { return LForme; }
            private set { LForme = value; }
        }
        public List<Lumiere> LLumieres
        {
            get { return LLumiere; }
            private set { LLumiere = value; }
        }
        public List<Camera> LCameras
        {
            get { return LCamera; }
            private set { LCamera = value; }
        }



        public Simulation()
        {
            LForme = new List<Forme>();
            LLumiere = new List<Lumiere>();
            LCameras = new List<Camera>();
        }


        public Simulation(Size3D taille, Point3D centre)
        {
            LForme = new List<Forme>();
            LLumiere = new List<Lumiere>();
            LCameras = new List<Camera>();
            _centre = centre;
            TailleSimulation = taille;
        }

        private void UpdateBordures()
        {
            bordures = new Forme[6] { 
                new Plan(new Vector3(0,0,1), new Point3D(_centre.X, _centre.Y, _centre.Z - TailleSimulation.Depth / 2)),
                new Plan(new Vector3(0,0,-1), new Point3D(_centre.X, _centre.Y, _centre.Z + TailleSimulation.Depth / 2)),
                new Plan(new Vector3(0,1,0), new Point3D(_centre.X, _centre.Y - TailleSimulation.Height/2, _centre.Z)),
                new Plan(new Vector3(0,-1,0), new Point3D(_centre.X, _centre.Y + TailleSimulation.Height/2, _centre.Z)),
                new Plan(new Vector3(1,0,0), new Point3D(_centre.X - TailleSimulation.Width/2, _centre.Y, _centre.Z)),
                new Plan(new Vector3(-1,0,0), new Point3D(_centre.X+ TailleSimulation.Width/2, _centre.Y, _centre.Z))
            };
        }
        public Simulation(Size3D taille) : this(taille, Point3D.Origine) { }
                
        public void AjouterForme(Forme forme)
        {
            LForme.Add(forme);
        }
        public void AjouterLumiere(Lumiere lumiere)
        {
            LLumiere.Add(lumiere);
        }

        public void AjouterCamera(Camera camera)
        {
            camera.SetSimulation(this);
            LCameras.Add(camera);
        }

        /// <summary>
        /// traite un rayon -> i.e. calcul la luminosité de la première forme croisant le rayon
        /// </summary>
        /// <param name="rayon">Le rayon pour lequel faire les calculs</param>
        /// <param name="distance">la distance à laquelle est la forme (en X*rayon(normalisé))</param>
        /// <param name="intensite">l'intensité lumineuse au point de croisement du rayon et de la forme la plus proche</param>
        /// <param name="color">la couleur de la forme au point de croisement du rayon et de la forme la plus proche</param>
        public void ProcessRay(Ray rayon, out double distance, out double intensite, out Color color)
        {
            List<Forme> formes = new List<Forme>();
            formes.AddRange(bordures);
            formes.AddRange(LForme.ToArray());

            Vector3 vNormal;
            Point3D intersection;
            // processing de la première forme
            Forme frontForme = formes[0];
            intersection = frontForme.CalculIntersection(rayon, out vNormal, out distance);
            formes.Remove(frontForme);

            double dist;
            Vector3 vNorm;
            Point3D intersect;
            foreach(Forme f in formes)
            {
                intersect = f.CalculIntersection(rayon, out vNorm, out dist);
                if((dist > 0 && dist < distance) || distance < 0) // si la forme est plus proche que la précédente
                {
                    vNormal = vNorm;
                    distance = dist;
                    intersection = intersect;
                    frontForme = f;
                }
            }
            // on maintenant les informations nécessaires sur la forme la plus en avant par rapport au rayon
            intensite = frontForme.CalculLuminosite(intersection, vNormal, LLumiere, out color);
        }


        internal double ProcessRayGetDistance(Ray rayon)
        {
            List<Forme> formes = new List<Forme>();
            formes.AddRange(bordures);
            formes.AddRange(LForme.ToArray());

            Vector3 vNormal;
            Point3D intersection;
            double distance;
            // processing de la première forme
            Forme frontForme = formes[0];
            intersection = frontForme.CalculIntersection(rayon, out vNormal, out distance);
            formes.Remove(frontForme);

            double dist;
            Vector3 vNorm;
            Point3D intersect;
            foreach (Forme f in formes)
            {
                intersect = f.CalculIntersection(rayon, out vNorm, out dist);
                if ((dist > 0 && dist < distance) || distance < 0) // si la forme est plus proche que la précédente
                {
                    vNormal = vNorm;
                    distance = dist;
                    intersection = intersect;
                    frontForme = f;
                }
            }
            return distance;
        }
    }
}
