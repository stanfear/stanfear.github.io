﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Projet_Objets_3D.Utilitaires
{
    public class Matrix3
    {
        public int rows = 3;
        public int cols = 3;
        public double[,] mat;

        public Matrix3()
        {
            mat = new double[3, 3];
        }
        public Matrix3(double[,] valeurs)
        {
            mat = valeurs;
        }

        public double this[int iRow, int iCol]
        {
            get { return mat[iRow, iCol]; }
            set { mat[iRow, iCol] = value; }
        }

        public static Matrix3 ZeroMatrix()
        {
            Matrix3 matrix = new Matrix3();
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    matrix[i, j] = 0;
            return matrix;
        }

        public static Matrix3 IdentityMatrix()
        {
            Matrix3 matrix = ZeroMatrix();
            for (int i = 0; i < 3; i++)
                matrix[i, i] = 1;
            return matrix;
        }

        private static Matrix3 Multiply(double n, Matrix3 m)
        {
            Matrix3 r = new Matrix3();
            for (int i = 0; i < m.rows; i++)
                for (int j = 0; j < m.cols; j++)
                    r[i, j] = m[i, j] * n;
            return r;
        }
        private static Matrix3 Add(Matrix3 m1, Matrix3 m2)
        {
            Matrix3 r = new Matrix3();
            for (int i = 0; i < r.rows; i++)
                for (int j = 0; j < r.cols; j++)
                    r[i, j] = m1[i, j] + m2[i, j];
            return r;
        }

        public static Matrix3 Multiply(Matrix3 m1, Matrix3 m2)
        {
            Matrix3 result = ZeroMatrix();
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    for (int k = 0; k < 3; k++)
                        result[i, j] += m1[i, k] * m2[k, j];
            return result;
        }


        public static Matrix3 operator -(Matrix3 m)
        { return Matrix3.Multiply(-1, m); }

        public static Matrix3 operator +(Matrix3 m1, Matrix3 m2)
        { return Matrix3.Add(m1, m2); }

        public static Matrix3 operator -(Matrix3 m1, Matrix3 m2)
        { return Matrix3.Add(m1, -m2); }

        public static Matrix3 operator *(double n, Matrix3 m)
        { return Matrix3.Multiply(n, m); }

        public static Matrix3 operator *(Matrix3 m1, Matrix3 m2)
        { return Matrix3.Multiply(m1, m2); }

        public static Vector3 operator *(Matrix3 m, Vector3 v)
        {
            return new Vector3(
                m[0, 0] * v.X + m[0, 1] * v.Y + m[0, 2] * v.Z,
                m[1, 0] * v.X + m[1, 1] * v.Y + m[1, 2] * v.Z,
                m[2, 0] * v.X + m[2, 1] * v.Y + m[2, 2] * v.Z
                );
        }
    }
}
