﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Projet_Objets_3D.Utilitaires
{
    interface IProgressTracker
    {
        int MaxValue { get; set; }
        int MinValue { get; set; }
        int CurentValue { get; set; }
        void report(int n);
        void init();
        /// <summary>
        /// initialise le visualisateur de progrès avec un nombre de processus
        /// </summary>
        /// <param name="p">le nombre de processus qui devront être fait</param>
        void init(int p);
        /// <summary>
        /// permet de "dire" au tracker que le processus précédent est fini -> on commence le suivant
        /// </summary>
        void NextStep();
        void SetUndefined();
        void SetDefined();
        /// <summary>
        /// permet de déclarer que l'étape suivie est terminée
        /// </summary>
        void reportFinish();
    }
}
