﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Projet_Objets_3D.Utilitaires
{
    internal class Utilitaires
    {

        internal static void SecondDegreeEquation(double a, double b, double c, out double Delta, out double x1, out double x2)
        {
            Delta = b * b - 4 * a * c;

            if(Delta > 0)
            {
                x1 = (-b - Math.Sqrt(Delta)) / (2 * a);
                x2 = (-b + Math.Sqrt(Delta)) / (2 * a);
            }
            else if(Delta == 0)
            {
                x1 = x2 = (-b) / (2 * a);
            }
            else //if(Delta < 0)
            {
                x1 = x2 = Double.NaN;
            }
        }
    }
}
