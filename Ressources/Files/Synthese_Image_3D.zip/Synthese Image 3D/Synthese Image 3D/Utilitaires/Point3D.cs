﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Projet_Objets_3D.Utilitaires
{
    [Serializable()]
    struct Point3D
    {
        private double _x;
        private double _y;
        private double _z;

        public double X
        {
            get { return _x; }
            set { _x = value; }
        }
        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }
        public double Z
        {
            get { return _z; }
            set { _z = value; }
        }
        
        public Point3D(double x, double y, double z)
        {
            _x = x;
            _y = y;
            _z = z;
        }

        public static Vector3 operator -(Point3D p1, Point3D p2)
        {
            return
            (
                new Vector3
                (
                    p1.X - p2.X,
                    p1.Y - p2.Y,
                    p1.Z - p2.Z
                )
            );
        }
        public static Point3D operator +(Point3D p, Vector3 v)
        {
            return
            (
                new Point3D
                (
                    p.X + v.X,
                    p.Y + v.Y,
                    p.Z + v.Z
                )
            );
        }

        public static readonly Point3D Origine = new Point3D(0, 0, 0);

        public static readonly Point3D Null = new Point3D(double.NaN, double.NaN, double.NaN);
    }
}
