﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Projet_Objets_3D.Utilitaires
{
    class Ray
    {
        public Point3D Start;
        public Vector3 Direction;

        public Ray(Point3D start, Vector3 dir)
        {
            this.Start = start;
            this.Direction = dir;
        }


    }
}
