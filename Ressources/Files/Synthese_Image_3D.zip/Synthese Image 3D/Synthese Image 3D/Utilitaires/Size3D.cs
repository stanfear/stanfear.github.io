﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Projet_Objets_3D.Utilitaires
{
    [Serializable()]
    class Size3D
    {
        private double _deltaX;
        private double _deltaY;
        private double _deltaZ;

        public double Width
        {
            get { return _deltaX; }
            set { _deltaX = value; }
        }
        public double Height
        {
            get { return _deltaY; }
            set { _deltaY = value; }
        }
        public double Depth
        {
            get { return _deltaZ; }
            set { _deltaZ = value; }
        }
        
        public Size3D(double x, double y, double z)
        {
            _deltaX = x;
            _deltaY = y;
            _deltaZ = z;
        }
    }
}
