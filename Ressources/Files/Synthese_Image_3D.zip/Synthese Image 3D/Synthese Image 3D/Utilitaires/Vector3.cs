﻿#region Imports

using System;
using System.Xml.Serialization;			// for various Xml attributes
using System.Globalization;

#endregion

/// <summary>
/// Vecteur en 3 dimensions
/// </summary>

namespace Projet_Objets_3D.Utilitaires
{
    [Serializable()]
    public struct Vector3
    {

        #region Class Variables

        /// <summary>
        /// Composante x du vecteur
        /// </summary>
        private double x;
        /// <summary>
        /// Composante y du vecteur
        /// </summary>
        private double y;
        /// <summary>
        /// Composante z du vecteur
        /// </summary>
        private double z;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructeur prenant en parametres 3 double
        /// </summary>
        /// <param name="x">valeur de la composante x du vecteur</param>
        /// <param name="y">valeur de la composante y du vecteur</param>
        /// <param name="z">valeur de la composante z du vecteur</param>
        public Vector3(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public Vector3(Vector3 LookDirection) : this(LookDirection.X, LookDirection.Y, LookDirection.Z) { }

        #endregion

        #region Accessors & Mutators

        /// <summary>
        /// Permet de modifier ou d'acceder à la composante x du vecteur
        /// </summary>
        public double X
        {
            get { return x; }
            set { x = value; }
        }

        /// <summary>
        /// Permet de modifier ou d'acceder à la composante y du vecteur
        /// </summary>
        public double Y
        {
            get { return y; }
            set { y = value; }
        }

        /// <summary>
        /// Permet de modifier ou d'acceder à la composante z du vecteur
        /// </summary>
        public double Z
        {
            get { return z; }
            set { z = value; }
        }

        /// <summary>
        /// Magnitude du vecteur (aka. longueur ou valeur absolue)
        /// </summary>
        public double Magnitude
        {
            get
            {
                return
                Math.Sqrt(SumComponentSqrs());
            }
            set
            {
                if (value < 0)
                { throw new ArgumentOutOfRangeException("value", value, "The magnitude of a Vector3 must be a positive value, (i.e. greater than 0)"); }

                if (this == new Vector3(0, 0, 0))
                { throw new ArgumentException("Cannot change the magnitude of Vector3(0,0,0)", "this"); }

                this = this * (value / Magnitude);
            }
        }
        #endregion

        #region Operators


        /// <summary>
        /// permet de calculler l'inverse d'un vecteur
        /// </summary>
        /// <param name="v1">le vecteur à inverser</param>
        /// <returns>le vecteur inversé</returns>
        public static Vector3 operator -(Vector3 v1)
        {
            return
            (
                new Vector3
                (
                    -v1.X,
                    -v1.Y,
                    -v1.Z
                )
            );
        }


        /// <summary>
        /// produit d'un scalair et d'un vecteur
        /// </summary>
        /// <param name="v1">vecteur a multiplier</param>
        /// <param name="s2">valeur par laquelle multiplier le vecteur</param>
        /// <returns>le vecteur3 correspondant au vecteur d'origine multiplié</returns>
        public static Vector3 operator *(Vector3 v1, double s2)
        {
            return
            (
                new Vector3
                (
                    v1.X * s2,
                    v1.Y * s2,
                    v1.Z * s2
                )
            );
        }

        /// <summary>
        /// produit d'un scalair et d'un vecteur
        /// </summary>
        /// <param name="s1">valeur par laquelle multiplier le vecteur</param>
        /// <param name="v2">vecteur a multiplier</param>
        /// <returns>le vecteur3 correspondant au vecteur d'origine multiplié</returns>
        public static Vector3 operator *(double s1, Vector3 v2)
        {
            return v2 * s1;
        }

        /// <summary>
        /// division d'un vecteur par un scalaire
        /// </summary>
        /// <param name="v1">le vecteur a diviser</param>
        /// <param name="s2">valeur par laquelle diviser le vecteur</param>
        /// <returns>le vecteur3 correspondant au vecteur d'origine divisé par la valeur</returns>
        public static Vector3 operator /(Vector3 v1, double s2)
        {
            return
            (
                new Vector3
                    (
                        v1.X / s2,
                        v1.Y / s2,
                        v1.Z / s2
                    )
            );
        }




        /// <summary>
        /// Test l'egualitée de deux vecteurs
        /// </summary>
        /// <param name="v1">Vector3 a comparer</param>
        /// <param name="v2">Vector3 a comparer</param>
        /// <returns>boolean representant l'égualité des deux vecteurs</returns>
        public static bool operator ==(Vector3 v1, Vector3 v2)
        {
            return
            (
                Math.Abs(v1.X - v2.X) <= Double.Epsilon &&
                Math.Abs(v1.Y - v2.Y) <= Double.Epsilon &&
                Math.Abs(v1.Z - v2.Z) <= Double.Epsilon
            );
        }

        /// <summary>
        /// Test la non égualitée de deux vecteurs
        /// </summary>       
        /// <param name="v1">Vector3 a comparer</param>
        /// <param name="v2">Vector3 a comparer</param>
        /// <returns>boolean representant l'inégualité des deux vecteurs</returns>
        public static bool operator !=(Vector3 v1, Vector3 v2)
        {
            return !(v1 == v2);
        }

        #endregion

        #region Functions
        /// <summary>
        /// Determine le produit Vectoriel entre deux vecteurs
        /// Determine le vecteur normal (Vector3 à 90° du plan)
        /// </summary>
        /// <param name="v1">le vecteur à multiplier</param>
        /// <param name="v2">le vecteur multiplicateur</param>
        /// <returns>Vector3 representant le produit vectoriel entre deux vecteurs</returns>
        public static Vector3 CrossProduct(Vector3 v1, Vector3 v2)
        {
            return
            (
                new Vector3
                (
                    v1.Y * v2.Z - v1.Z * v2.Y,
                    v1.Z * v2.X - v1.X * v2.Z,
                    v1.X * v2.Y - v1.Y * v2.X
                )
            );
        }

        /// <summary>
        /// Determine le produit Vectoriel entre deux vecteurs
        /// Determine le vecteur normal (Vector3 à 90° du plan)
        /// </summary>
        /// <param name="other">l'autre vecteur a multiplier</param>
        /// <returns>Vector3 representant le produit vectoriel entre deux vecteurs</returns>
        public Vector3 CrossProduct(Vector3 other)
        {
            return CrossProduct(this, other);
        }




        /// <summary>
        /// Calcul le produit scalaire de deux Vecteurs
        /// </summary>
        /// <param name="v1">Le premier vecteur a multiplier</param>
        /// <param name="v2">le deuxième vecteur a multiplier</param>
        /// <returns>double representant le produit scalaire des deux vecteurs entre eux</returns>
        public static double DotProduct(Vector3 v1, Vector3 v2)
        {
            return
            (
                v1.X * v2.X +
                v1.Y * v2.Y +
                v1.Z * v2.Z
            );
        }

        /// <summary>
        /// Calcul le produit scalaire de ce Vecteur avec un autre
        /// </summary>
        /// <param name="other">l'autre vecteur a multiplier</param>
        /// <returns>double representant le produit scalaire des deux vecteurs entre eux</returns>
        public double DotProduct(Vector3 other)
        {
            return DotProduct(this, other);
        }


        /// <summary>
        /// obtient le vecteur normal
        /// Obtient le vecteur unitaire
        /// met à l'echelle le vecteur pour avoir une magnitude de 1
        /// </summary>
        /// <param name="v1">le vecteur a normaliser</param>
        /// <returns>le Vector3 normalisé</returns>
        public static Vector3 Normalize(Vector3 v1)
        {
            // Check for divide by zero errors
            if (v1.Magnitude == 0)
            {
                throw new DivideByZeroException("Can not normalize a vector when it's magnitude is zero");
            }
            else
            {
                // find the inverse of the vectors magnitude
                double inverse = 1 / v1.Magnitude;
                return
                (
                    new Vector3
                    (
                    // multiply each component by the inverse of the magnitude
                        v1.X * inverse,
                        v1.Y * inverse,
                        v1.Z * inverse
                    )
                );
            }
        }

        /// <summary>
        /// obtient le vecteur normal
        /// Obtient le vecteur unitaire
        /// met à l'echelle le vecteur pour avoir une magnitude de 1
        /// </summary>
        /// <returns>le Vector3 normalisé</returns>
        public Vector3 Normalize()
        {
            return Vector3.Normalize(this);
        }


        /// <summary>
        /// Calcul le hashcode
        /// </summary>
        /// <returns>le Hashcode de l'instance de l'objet</returns>
        public override int GetHashCode()
        {
            return
            (
                (int)((X + Y + Z) % Int32.MaxValue)
            );
        }

        public override bool Equals(object other)
        {
            // Check object other is a Vector3 object
            if (other is Vector3)
            {
                // Convert object to Vector3
                Vector3 otherVector = (Vector3)other;

                // Check for equality
                return otherVector == this;
            }
            else
            {
                return false;
            }
        }

        #endregion

        #region Rotations
        // les fonction de rotations ont été récupérés sur internet -> summary en anglais

        /// <summary>
        /// Rotates a Vector3 around the Y axis
        /// Change the yaw of a Vector3
        /// </summary>
        /// <param name="v1">The Vector3 to be rotated</param>
        /// <param name="degree">The angle to rotate the Vector3 around in degrees</param>
        /// <returns>Vector3 representing the rotation around the Y axis</returns>
        public static Vector3 Yaw(Vector3 v1, double degree)
        {
            double x = (v1.Z * Math.Sin(degree)) + (v1.X * Math.Cos(degree));
            double y = v1.Y;
            double z = (v1.Z * Math.Cos(degree)) - (v1.X * Math.Sin(degree));
            return new Vector3(x, y, z);
        }

        /// <summary>
        /// Rotates the Vector3 around the Y axis
        /// Change the yaw of the Vector3
        /// </summary>
        /// <param name="degree">The angle to rotate the Vector3 around in degrees</param>
        /// <returns>Vector3 representing the rotation around the Y axis</returns>
        /// <implementation>
        /// <see cref="Yaw(Vector3, Double)"/>
        /// Uses function Yaw(Vector3, double) to avoid code duplication
        /// </implementation>
        public void Yaw(double degree)
        {
            this = Yaw(this, degree);
        }

        /// <summary>
        /// Rotates a Vector3 around the X axis
        /// Change the pitch of a Vector3
        /// </summary>
        /// <param name="v1">The Vector3 to be rotated</param>
        /// <param name="degree">The angle to rotate the Vector3 around in degrees</param>
        /// <returns>Vector3 representing the rotation around the X axis</returns>
        public static Vector3 Pitch(Vector3 v1, double degree)
        {
            double x = v1.X;
            double y = (v1.Y * Math.Cos(degree)) - (v1.Z * Math.Sin(degree));
            double z = (v1.Y * Math.Sin(degree)) + (v1.Z * Math.Cos(degree));
            return new Vector3(x, y, z);
        }

        /// <summary>
        /// Rotates a Vector3 around the X axis
        /// Change the pitch of a Vector3
        /// </summary>
        /// <param name="degree">The angle to rotate the Vector3 around in degrees</param>
        /// <returns>Vector3 representing the rotation around the X axis</returns>
        /// <see cref="Pitch(Vector3, Double)"/>
        /// <implementation>
        /// Uses function Pitch(Vector3, double) to avoid code duplication
        /// </implementation>
        public void Pitch(double degree)
        {
            this = Pitch(this, degree);
        }

        /// <summary>
        /// Rotates a Vector3 around the Z axis
        /// Change the roll of a Vector3
        /// </summary>
        /// <param name="v1">The Vector3 to be rotated</param>
        /// <param name="degree">The angle to rotate the Vector3 around in degrees</param>
        /// <returns>Vector3 representing the rotation around the Z axis</returns>
        public static Vector3 Roll(Vector3 v1, double degree)
        {
            double x = (v1.X * Math.Cos(degree)) - (v1.Y * Math.Sin(degree));
            double y = (v1.X * Math.Sin(degree)) + (v1.Y * Math.Cos(degree));
            double z = v1.Z;
            return new Vector3(x, y, z);
        }

        /// <summary>
        /// Rotates a Vector3 around the Z axis
        /// Change the roll of a Vector3
        /// </summary>
        /// <param name="degree">The angle to rotate the Vector3 around in degrees</param>
        /// <returns>Vector3 representing the rotation around the Z axis</returns>
        /// <implementation>
        /// <see cref="Roll(Vector3, Double)"/>
        /// Uses function Roll(Vector3, double) to avoid code duplication
        /// </implementation>
        public void Roll(double degree)
        {
            this = Roll(this, degree);
        }






        #endregion

        #region Component Operations
        /// <summary>
        /// la somme des carrés des composantes du vecteur
        /// </summary>
        /// <param name="v1">le Vecteur sur lequel effectuer l'opération</param>
        /// <returns>la somme des composantes au carré (X^2 + Y^2 + z^2)</returns>
        public static double SumComponentSqrs(Vector3 v1)
        {
            return
                v1.X * v1.X +
                v1.Y * v1.Y +
                v1.Z * v1.Z;
        }

        /// <summary>
        /// Somme des carrés des composants de ce vecteur (this)
        /// </summary>
        /// <returns>la somme des composantes au carré (X^2 + Y^2 + z^2)</returns>
        public double SumComponentSqrs()
        {
            return SumComponentSqrs(this);
        }
        #endregion


        public static readonly Vector3 Null = new Vector3(0, 0, 0);
        public static readonly Vector3 unitX = new Vector3(1, 0, 0);
        public static readonly Vector3 unitY = new Vector3(0, 1, 0);
        public static readonly Vector3 unitZ = new Vector3(0, 0, 1);
    }
}