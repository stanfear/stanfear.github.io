﻿using Projet_Objets_3D.Utilitaires;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Projet_Objets_3D.Formes
{
    [Serializable()]
    class Plan : Forme
    {
        private Point3D _a;
        private Vector3 n;

        public Plan(Vector3 vNormal, Point3D A)
        {
            n = vNormal.Normalize();
            _a = A;
        }


        public override Point3D CalculIntersection(Ray rayon, out Vector3 normal, out double time)
        {
            normal = n;
            time = (_a - rayon.Start).DotProduct(n) / rayon.Direction.DotProduct(n);
            return rayon.Start + rayon.Direction * time;
        }
    }
}
