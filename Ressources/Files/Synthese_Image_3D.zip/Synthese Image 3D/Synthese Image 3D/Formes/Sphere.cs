﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Projet_Objets_3D.Utilitaires;

namespace Projet_Objets_3D.Formes
{
    [Serializable()]
    class Sphere : Forme
    {
        public Point3D Centre { get; set; }
        public double Rayon { get; set; }


        public Sphere(Point3D point3D, double r)
        {
            // TODO: Complete member initialization
            this.Centre = point3D;
            this.Rayon = r;
        }




        public override Point3D CalculIntersection(Ray rayon, out Vector3 normal, out double time)
        {
            normal = Vector3.Null;
            time = -1;

            double a = rayon.Direction.DotProduct(rayon.Direction);
            double b = (2 * (rayon.Start - Centre)).DotProduct(rayon.Direction);
            double c = (rayon.Start - Centre).DotProduct((rayon.Start - Centre)) - (Rayon * Rayon);

            double delta, distance1, distance2;
            Utilitaires.Utilitaires.SecondDegreeEquation(a, b, c, out delta, out distance1, out distance2);


            if (delta < 0)
                return Point3D.Null;

            time = distance1 > distance2 ? distance2 : distance1;

            Point3D intersection = rayon.Start + rayon.Direction * time;
            normal = intersection - Centre;
            return intersection;
        }
    }
}
