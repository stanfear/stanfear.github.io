﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Projet_Objets_3D.Utilitaires;

namespace Projet_Objets_3D.Formes
{
    [Serializable()]
    class Cylindre : Forme
    {
        public Point3D Origine { get; set; }
        public Vector3 VecteurHauteur { get; set; }
        public double Rayon { get; set; }

        public Cylindre(Point3D origine, Vector3 hauteur, double rayon)
        {
            Origine = origine;
            VecteurHauteur = hauteur;
            Rayon = rayon;

        }

        public override Point3D CalculIntersection(Ray rayon, out Vector3 normal, out double time)
        {
            /// Line segment VS <cylinder>
            // - cylinder (A, B, r) (start point, end point, radius)
            // - line has starting point (x0, y0, z0) and ending point (x0+ux, y0+uy, z0+uz) ((ux, uy, uz) is "direction")
            // => start = (x0, y0, z0)
            //   dir = (ux, uy, uz)
            //   A
            //   B
            //   r
            //   optimize? (= don't care for t > 1)
            // <= t  = "time" of intersection
            //   norm = surface normal of intersection point
            //le point A est le point d'origine
            // B est le point récupéré grâce au vecteur hauteur appliqué sur le point d'origine

            //les deux variables seront plus tard données lors de l'appel de la fonction
            normal = Vector3.Null;
            time = -1;

            Vector3 AB = VecteurHauteur.Normalize() * VecteurHauteur.Magnitude; // nécéssité, sinon, le cyindre est plein de trous ...
            Vector3 AO = rayon.Start - Origine;
            Vector3 AOxAB = AO.CrossProduct(AB);
            Vector3 VxAB = rayon.Direction.CrossProduct(AB);

            double ab2 = AB.DotProduct(AB);
            double a = VxAB.DotProduct(VxAB);
            double b = 2 * VxAB.DotProduct(AOxAB);
            double c = AOxAB.DotProduct(AOxAB) - (Rayon * Rayon * ab2);
            double d = b * b - 4 * a * c;
            if (d < 0) return Point3D.Null;
            time = (-b - Math.Sqrt(d)) / (2 * a);
            if (time < 0) return Point3D.Null;

            Point3D intersection = rayon.Start + rayon.Direction * time;        // intersection point
            Point3D projection = Origine + (AB.DotProduct(intersection - Origine) / ab2) * AB; // intersection projected onto cylinder axis

            normal = (intersection - projection);
            normal.Normalize();

            // test de l'appartenance du point aux "bouchons" du cylindre
            // d'abord, on test si on est sur un bord du cylindre ou pas !
            if ((projection - Origine).Magnitude + ((Origine + AB) - projection).Magnitude <= AB.Magnitude) // THIS IS THE SLOW SAFE WAY
            {
                return intersection;
            }

            //Si on n'est pas sur le bord, on test les bouchons

            // test du bouchon coté origine
            double time1 = (Origine - rayon.Start).DotProduct(VecteurHauteur) / rayon.Direction.DotProduct(VecteurHauteur);
            double time2 = ((Origine + VecteurHauteur) - rayon.Start).DotProduct(VecteurHauteur) / rayon.Direction.DotProduct(VecteurHauteur);
            time = time1 > time2 ? time2 : time1;
            normal = time1 > time2 ? VecteurHauteur : -VecteurHauteur;
            intersection = rayon.Start + rayon.Direction * time;

            // si l'un des deux points ((x,y,Z1) ou (x,y,z2)) est sur un bouchon
            if ((intersection - Origine).Magnitude < Rayon || (intersection - (Origine + VecteurHauteur)).Magnitude < Rayon)
                return intersection;

            //si on n'est pas sur les bouchon, on renvois le point d'origine
            time = -1;
            return Point3D.Null;
        }
    }
}
