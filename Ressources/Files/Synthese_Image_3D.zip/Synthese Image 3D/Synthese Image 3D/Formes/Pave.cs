﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Projet_Objets_3D.Utilitaires;

namespace Projet_Objets_3D.Formes
{
    class Pave : Forme
    {
        private List<Triangle> lTriangle;
        public Pave(Point3D A, Vector3 v1,Vector3 v2,Vector3 v3)
        {
            Point3D B = A + v1;
            Point3D C = A + v1 + v2;
            Point3D D = A + v2;
            Point3D E = A + v3;
            Point3D F = B + v3;
            Point3D G = C + v3;
            Point3D H = D + v3;
            lTriangle = new List<Triangle>();
            //Face 1 (A,B,C,D)
            lTriangle.Add(new Triangle(A, B, D));
            lTriangle.Add(new Triangle(B, C, D));
            //Face 2 (A,B,F,E)
            lTriangle.Add(new Triangle(E, B, A));
            lTriangle.Add(new Triangle(E, B, F));
            //Face 3 (A,D,E,H)
            lTriangle.Add(new Triangle(E, D, A));
            lTriangle.Add(new Triangle(E, D, H));
            //Face 4 (E,F,G,H)
            lTriangle.Add(new Triangle(E, F, G));
            lTriangle.Add(new Triangle(E, H, G));
            //Face 5 (B,C,F,G)
            lTriangle.Add(new Triangle(B, C, G));
            lTriangle.Add(new Triangle(B, F, G));
            //Face 6 (D,C,G,H)
            lTriangle.Add(new Triangle(D, C, G));
            lTriangle.Add(new Triangle(D, H, G));
        }

        private bool IsInForme(double x, double y)
        {
            return true;
        }


        public override Point3D CalculIntersection(Ray rayon, out Vector3 normal, out double time)
        {
            //TODO : Calcul du point d'intersection pour le pavé
            normal = Vector3.Null;
            time = -1;
            return Point3D.Null;
        }
    }
}
