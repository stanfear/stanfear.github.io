﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Projet_Objets_3D.Utilitaires;


namespace Projet_Objets_3D.Formes
{


    class Triangle : Forme
    {
        private Point3D _A;
        private Point3D _B;
        private Point3D _C;

        private Vector3 n;
        private double cnst;



        public Triangle(Point3D A, Point3D B, Point3D C)
        {
            _A = A;
            _B = B;
            _C = C;
            Vector3 AB = _B - _A;
            Vector3 AC = _C - _A;
            n = Vector3.CrossProduct(AB, AC);
            cnst = (n.X * _A.X + n.Y * _A.Y) / n.Z + _A.Z;
        }

        /// <summary>
        /// test si le point M est dans le triangle formé par les points T1,T2,T3
        /// </summary>
        /// <param name="T1">coins 1 du triangle</param>
        /// <param name="T2">coins 2 du triangle</param>
        /// <param name="T3">coins 3 du triangle</param>
        /// <param name="M">Point dont on veut tester l'appartenance au triangle</param>
        /// <returns>Vrai si le point appartient au triangle, faux sinon</returns>
        /// <remarks>Pour le moment, les ponts sont testé en les projetant selon l'axe Z</remarks>
        public static bool IsInTriangle(Point3D T1,Point3D T2,Point3D T3,Point3D M)
        {
            return (
                Vector3.DotProduct(Vector3.CrossProduct(T2 - T1, M - T1), Vector3.CrossProduct(M - T1, T3 - T1)) >= 0 &&
                Vector3.DotProduct(Vector3.CrossProduct(T1 - T2, M - T2), Vector3.CrossProduct(M - T2, T3 - T2)) >= 0 &&
                Vector3.DotProduct(Vector3.CrossProduct(T1 - T3, M - T3), Vector3.CrossProduct(M - T3, T2 - T3)) >= 0
                );
        }

        public bool IsInTriangle(Point3D M)
        {
            return IsInTriangle(_A, _B, _C, M);
        }



        public override Point3D CalculIntersection(Ray rayon, out Vector3 normal, out double time)
        {

            //TODO : Calcul du point d'intersection pour le triangle
            normal = n;
            time = (_A - rayon.Start).DotProduct(n) / rayon.Direction.DotProduct(n);
            Point3D intersection = rayon.Start + rayon.Direction * time;

            if(IsInTriangle(intersection))
            {
                return intersection;
            }
            time = -1;
            return Point3D.Null;
        }

    }
}
