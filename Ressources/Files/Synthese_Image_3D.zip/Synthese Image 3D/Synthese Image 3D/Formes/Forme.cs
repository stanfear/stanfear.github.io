﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using Projet_Objets_3D.Utilitaires;
using Projet_Objets_3D.Formes;
using Projet_Objets_3D.Lumieres;

namespace Projet_Objets_3D.Formes
{
    [Serializable()]
    abstract class Forme
    {
        private Color _color = Color.White;
        public Color color { get { return _color; } set { _color = value; } }
        public String Nom { get; set; }
        
        /// <summary>
        /// permet de calculer le 1er point d'intersection entre un rayon et la forme
        /// calcul au passage le vecteur normal
        /// </summary>
        /// <param name="rayon">le rayon avec lequel on veut calculer l'intersection</param>
        /// <param name="normal">le vecteur normal au point calculé</param>
        /// <param name="time">l'indice de distance entre le point d'origine du rayon et le point d'intersection</param>
        /// <returns>renvois le point d'intersection entre le rayon et la forme le plus proche de la source du rayon</returns>
        public abstract Point3D CalculIntersection(Ray rayon, out Vector3 normal, out double time);


        /// <summary>
        /// Calcul la luminausité en uun point ayant un vecteur normal, à partir de la liste des lumières (calcul aussi la couleur de l'objet au point définit)
        /// </summary>
        /// <param name="intersection">Le point où calculer la luminosité</param>
        /// <param name="vNormal">le vecteur normal à la surface du point</param>
        /// <param name="LLumiere">la liste des lumières</param>
        /// <param name="color">la couleur calculée du point</param>
        /// <returns>renvois l'intensité lumineuse</returns>
        internal double CalculLuminosite(Point3D intersection, Vector3 vNormal, List<Lumiere> LLumiere, out Color color)
        {
            
            // récuperation de la norme du vecteur normal au point
            double normeP = vNormal.Magnitude;
            // On définit vecL, le vecteur du point orienté vers la source lumineuse (Xs,Ys,Zs)
            double SommeprodScalNL = 0;
            Color colorLight = Color.FromArgb(0, 0, 0);
            foreach (Lumiere light in LLumiere)
            {
                Vector3 vecL = light.GetLightVector(intersection, vNormal);
                double normeL = vecL.Magnitude;
                double prodScalNL = Vector3.DotProduct(vNormal, vecL);
                double prodScalNLNormalise = prodScalNL / normeP;
                if (prodScalNLNormalise < 0)
                    prodScalNLNormalise = 0;
                SommeprodScalNL += prodScalNLNormalise;


                // calcul de la couleur des lumières
                int r = colorLight.R + (int)(light.Color.R * light.Intensite);
                int g = colorLight.G + (int)(light.Color.G * light.Intensite);
                int b = colorLight.B + (int)(light.Color.B * light.Intensite);

                colorLight = Color.FromArgb(r > 255 ? 255 : r, g > 255 ? 255 : g, b > 255 ? 255 : b);
            }


            // Comparaison de la couleur fournies par les lumières et de la couleur de la forme.
            // on ne peut pas avoir une couleur plus claires que la couleur de la forme.
            int maxR = this._color.R;
            int maxG = this._color.G;
            int maxB = this._color.B;
            color = Color.FromArgb(colorLight.R > maxR ? maxR : colorLight.R, colorLight.G > maxG ? maxG : colorLight.G, colorLight.B > maxB ? maxB : colorLight.B);
            

            if (SommeprodScalNL > 1)
                SommeprodScalNL = 1;
            if (SommeprodScalNL < 0)
                SommeprodScalNL = 0;

            double intensite = SommeprodScalNL;
            return intensite;

        }
    }
}