﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Projet_Objets_3D.Utilitaires;

namespace Projet_Objets_3D
{
    class DumbTracker : IProgressTracker
    {
        public int MaxValue { get { return 0; } set { } }
        public int MinValue { get { return 0; } set { } }
        public int CurentValue { get { return 0; } set { } }
        public void report(int n) {}
        public void init() {}
        public void init(int p) {}
        public void NextStep() {}
        public void SetUndefined() {}
        public void SetDefined() {}
        public void reportFinish() {}
    }
}
