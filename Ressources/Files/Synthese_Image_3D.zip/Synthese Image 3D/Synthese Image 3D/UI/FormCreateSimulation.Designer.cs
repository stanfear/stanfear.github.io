﻿namespace Projet_Objets_3D.UI
{
    partial class FormCreateSimulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupBoxCentre = new System.Windows.Forms.GroupBox();
            this.labelPositionX = new System.Windows.Forms.Label();
            this.labelPositionY = new System.Windows.Forms.Label();
            this.textBoxPositionZ = new System.Windows.Forms.TextBox();
            this.labelPositionZ = new System.Windows.Forms.Label();
            this.textBoxPositionY = new System.Windows.Forms.TextBox();
            this.textBoxPositionX = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tBDeltaZ = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tBDeltaY = new System.Windows.Forms.TextBox();
            this.tBDeltaX = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tBNom = new System.Windows.Forms.TextBox();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonOK = new System.Windows.Forms.Button();
            this.GroupBoxCentre.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBoxCentre
            // 
            this.GroupBoxCentre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.GroupBoxCentre.Controls.Add(this.labelPositionX);
            this.GroupBoxCentre.Controls.Add(this.labelPositionY);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionZ);
            this.GroupBoxCentre.Controls.Add(this.labelPositionZ);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionY);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionX);
            this.GroupBoxCentre.Location = new System.Drawing.Point(12, 34);
            this.GroupBoxCentre.Name = "GroupBoxCentre";
            this.GroupBoxCentre.Size = new System.Drawing.Size(131, 95);
            this.GroupBoxCentre.TabIndex = 10;
            this.GroupBoxCentre.TabStop = false;
            this.GroupBoxCentre.Text = "Centre de la simulation";
            // 
            // labelPositionX
            // 
            this.labelPositionX.AutoSize = true;
            this.labelPositionX.Location = new System.Drawing.Point(37, 22);
            this.labelPositionX.Name = "labelPositionX";
            this.labelPositionX.Size = new System.Drawing.Size(20, 13);
            this.labelPositionX.TabIndex = 1;
            this.labelPositionX.Text = "X :";
            // 
            // labelPositionY
            // 
            this.labelPositionY.AutoSize = true;
            this.labelPositionY.Location = new System.Drawing.Point(37, 44);
            this.labelPositionY.Name = "labelPositionY";
            this.labelPositionY.Size = new System.Drawing.Size(20, 13);
            this.labelPositionY.TabIndex = 2;
            this.labelPositionY.Text = "Y :";
            // 
            // textBoxPositionZ
            // 
            this.textBoxPositionZ.Location = new System.Drawing.Point(63, 64);
            this.textBoxPositionZ.Name = "textBoxPositionZ";
            this.textBoxPositionZ.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionZ.TabIndex = 7;
            this.textBoxPositionZ.Text = "0";
            // 
            // labelPositionZ
            // 
            this.labelPositionZ.AutoSize = true;
            this.labelPositionZ.Location = new System.Drawing.Point(37, 67);
            this.labelPositionZ.Name = "labelPositionZ";
            this.labelPositionZ.Size = new System.Drawing.Size(20, 13);
            this.labelPositionZ.TabIndex = 3;
            this.labelPositionZ.Text = "Z :";
            // 
            // textBoxPositionY
            // 
            this.textBoxPositionY.Location = new System.Drawing.Point(63, 41);
            this.textBoxPositionY.Name = "textBoxPositionY";
            this.textBoxPositionY.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionY.TabIndex = 6;
            this.textBoxPositionY.Text = "0";
            // 
            // textBoxPositionX
            // 
            this.textBoxPositionX.Location = new System.Drawing.Point(63, 19);
            this.textBoxPositionX.Name = "textBoxPositionX";
            this.textBoxPositionX.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionX.TabIndex = 5;
            this.textBoxPositionX.Text = "0";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tBDeltaZ);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tBDeltaY);
            this.groupBox1.Controls.Add(this.tBDeltaX);
            this.groupBox1.Location = new System.Drawing.Point(153, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(175, 95);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "dimension de la simulation";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Largeur (ΔX) :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Hauteur (ΔY) :";
            // 
            // tBDeltaZ
            // 
            this.tBDeltaZ.Location = new System.Drawing.Point(110, 64);
            this.tBDeltaZ.Name = "tBDeltaZ";
            this.tBDeltaZ.Size = new System.Drawing.Size(59, 20);
            this.tBDeltaZ.TabIndex = 7;
            this.tBDeltaZ.Text = "5";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Profondeur (ΔZ) :";
            // 
            // tBDeltaY
            // 
            this.tBDeltaY.Location = new System.Drawing.Point(110, 41);
            this.tBDeltaY.Name = "tBDeltaY";
            this.tBDeltaY.Size = new System.Drawing.Size(59, 20);
            this.tBDeltaY.TabIndex = 6;
            this.tBDeltaY.Text = "5";
            // 
            // tBDeltaX
            // 
            this.tBDeltaX.Location = new System.Drawing.Point(110, 19);
            this.tBDeltaX.Name = "tBDeltaX";
            this.tBDeltaX.Size = new System.Drawing.Size(59, 20);
            this.tBDeltaX.TabIndex = 5;
            this.tBDeltaX.Text = "5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Nom de la simulation :";
            // 
            // tBNom
            // 
            this.tBNom.Location = new System.Drawing.Point(128, 6);
            this.tBNom.Name = "tBNom";
            this.tBNom.Size = new System.Drawing.Size(200, 20);
            this.tBNom.TabIndex = 13;
            this.tBNom.Text = "Sans titre";
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(334, 34);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(178, 23);
            this.buttonCancel.TabIndex = 15;
            this.buttonCancel.Text = "Annuler";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // buttonOK
            // 
            this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOK.Location = new System.Drawing.Point(334, 6);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(178, 23);
            this.buttonOK.TabIndex = 14;
            this.buttonOK.Text = "OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // FormCreateSimulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(524, 141);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.tBNom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.GroupBoxCentre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FormCreateSimulation";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Créer une Simulation";
            this.GroupBoxCentre.ResumeLayout(false);
            this.GroupBoxCentre.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GroupBoxCentre;
        private System.Windows.Forms.Label labelPositionX;
        private System.Windows.Forms.Label labelPositionY;
        private System.Windows.Forms.TextBox textBoxPositionZ;
        private System.Windows.Forms.Label labelPositionZ;
        private System.Windows.Forms.TextBox textBoxPositionY;
        private System.Windows.Forms.TextBox textBoxPositionX;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBDeltaZ;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBDeltaY;
        private System.Windows.Forms.TextBox tBDeltaX;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tBNom;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonOK;
    }
}