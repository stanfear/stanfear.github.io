﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Projet_Objets_3D.Utilitaires;
using Projet_Objets_3D.Lumieres;

namespace Projet_Objets_3D.UI
{
    public partial class UCPonctuelLightSource : UserControl
    {
        public UCPonctuelLightSource()
        {
            InitializeComponent();
        }

        internal UCPonctuelLightSource(PonctualLightSource sourceLumineuse) : this()
        {
            Position = sourceLumineuse.Location;
        }

        internal Point3D Position
        {
            get
            {
                return new Point3D(double.Parse(textBoxPositionX.Text), double.Parse(textBoxPositionY.Text), double.Parse(textBoxPositionZ.Text));
            }
            set
            {
                textBoxPositionX.Text = value.X.ToString();
                textBoxPositionY.Text = value.Y.ToString();
                textBoxPositionZ.Text = value.Z.ToString();
            }
        }

        public bool ValideData
        {
            get
            {
                double temp;
                return
                    double.TryParse(textBoxPositionX.Text, out temp) &&
                    double.TryParse(textBoxPositionY.Text, out temp) &&
                    double.TryParse(textBoxPositionZ.Text, out temp);
            }
        }
    }
}
