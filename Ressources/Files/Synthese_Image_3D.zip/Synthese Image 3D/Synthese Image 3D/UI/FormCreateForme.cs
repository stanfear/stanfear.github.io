﻿using Projet_Objets_3D.Formes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Projet_Objets_3D.UI
{
    public partial class FormCreateForme : Form
    {
        private Forme forme;
        private UserControl localUC;

        internal Forme NewForme
        {
            get { return forme; }
            set { forme = value; }
        }
        

        public FormCreateForme()
        {
            InitializeComponent();
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            colorDialog.ShowDialog();
            buttonColor.BackColor = colorDialog.Color;

        }

        private void CreateForme_Load(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
                comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (forme == null)
            {
                GroupBoxFormeConstruction.Controls.Remove(localUC);
                UserControl uc;
                switch (comboBox1.SelectedItem.ToString())
                {
                    case "Sphère":
                        textBoxNomForme.Text = "Sphère";
                        uc = new UCSphere();
                        break;
                    case "Cylindre":
                        textBoxNomForme.Text = "Cylindre";
                        uc = new UCCylindre();
                        break;
                    default:
                        uc = new UCSphere();
                        break;
                }
                uc.Location = new Point(6, 62);
                localUC = uc;
                GroupBoxFormeConstruction.Controls.Add(uc);
            }
            else
            {
                comboBox1.Enabled = false;
                textBoxNomForme.Text = forme.Nom;
                buttonColor.BackColor = forme.color;

                UserControl uc;
                switch (forme.GetType().Name)
                {
                    case "Sphere":
                        uc = new UCSphere(forme as Sphere);
                        comboBox1.SelectedItem = "Sphère";
                        break;
                    case "Cylindre":
                        uc = new UCCylindre(forme as Cylindre);
                        comboBox1.SelectedItem = "Cylindre";
                        break;
                    default: 
                        uc = new UCSphere();
                        forme = null;
                        break;
                }
                uc.Location = new Point(6, 62);
                localUC = uc;
                GroupBoxFormeConstruction.Controls.Add(uc);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            switch (comboBox1.SelectedItem.ToString())
            {
                case "Sphère":
                    {
                        UCSphere uc = localUC as UCSphere;
                        if (!uc.ValideData)
                            return;
                        forme = new Sphere(uc.PointCentre, uc.Rayon);
                        break;
                    }
                case "Cylindre":
                    {
                        UCCylindre uc = localUC as UCCylindre;
                        if (!uc.ValideData)
                            return;
                        forme = new Cylindre(uc.PointCentre, uc.VecteurHauteur, uc.Rayon);
                        break;
                    }
                default:
                    break;
            }
            forme.Nom = textBoxNomForme.Text;
            forme.color = buttonColor.BackColor;
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        internal void setSelectedForme(string p)
        {
            comboBox1.SelectedItem = p;
        }
    }
}
