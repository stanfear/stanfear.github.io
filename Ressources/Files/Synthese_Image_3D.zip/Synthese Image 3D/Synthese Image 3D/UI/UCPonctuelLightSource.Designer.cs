﻿namespace Projet_Objets_3D.UI
{
    partial class UCPonctuelLightSource
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupBoxCentre = new System.Windows.Forms.GroupBox();
            this.labelPositionX = new System.Windows.Forms.Label();
            this.labelPositionY = new System.Windows.Forms.Label();
            this.textBoxPositionZ = new System.Windows.Forms.TextBox();
            this.labelPositionZ = new System.Windows.Forms.Label();
            this.textBoxPositionY = new System.Windows.Forms.TextBox();
            this.textBoxPositionX = new System.Windows.Forms.TextBox();
            this.GroupBoxCentre.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBoxCentre
            // 
            this.GroupBoxCentre.Controls.Add(this.labelPositionX);
            this.GroupBoxCentre.Controls.Add(this.labelPositionY);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionZ);
            this.GroupBoxCentre.Controls.Add(this.labelPositionZ);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionY);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionX);
            this.GroupBoxCentre.Location = new System.Drawing.Point(147, 3);
            this.GroupBoxCentre.Name = "GroupBoxCentre";
            this.GroupBoxCentre.Size = new System.Drawing.Size(175, 95);
            this.GroupBoxCentre.TabIndex = 20;
            this.GroupBoxCentre.TabStop = false;
            this.GroupBoxCentre.Text = "Position de la source lumineuse";
            // 
            // labelPositionX
            // 
            this.labelPositionX.AutoSize = true;
            this.labelPositionX.Location = new System.Drawing.Point(84, 22);
            this.labelPositionX.Name = "labelPositionX";
            this.labelPositionX.Size = new System.Drawing.Size(20, 13);
            this.labelPositionX.TabIndex = 1;
            this.labelPositionX.Text = "X :";
            // 
            // labelPositionY
            // 
            this.labelPositionY.AutoSize = true;
            this.labelPositionY.Location = new System.Drawing.Point(84, 44);
            this.labelPositionY.Name = "labelPositionY";
            this.labelPositionY.Size = new System.Drawing.Size(20, 13);
            this.labelPositionY.TabIndex = 2;
            this.labelPositionY.Text = "Y :";
            // 
            // textBoxPositionZ
            // 
            this.textBoxPositionZ.Location = new System.Drawing.Point(110, 64);
            this.textBoxPositionZ.Name = "textBoxPositionZ";
            this.textBoxPositionZ.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionZ.TabIndex = 7;
            this.textBoxPositionZ.Text = "-2";
            // 
            // labelPositionZ
            // 
            this.labelPositionZ.AutoSize = true;
            this.labelPositionZ.Location = new System.Drawing.Point(84, 67);
            this.labelPositionZ.Name = "labelPositionZ";
            this.labelPositionZ.Size = new System.Drawing.Size(20, 13);
            this.labelPositionZ.TabIndex = 3;
            this.labelPositionZ.Text = "Z :";
            // 
            // textBoxPositionY
            // 
            this.textBoxPositionY.Location = new System.Drawing.Point(110, 41);
            this.textBoxPositionY.Name = "textBoxPositionY";
            this.textBoxPositionY.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionY.TabIndex = 6;
            this.textBoxPositionY.Text = "0";
            // 
            // textBoxPositionX
            // 
            this.textBoxPositionX.Location = new System.Drawing.Point(110, 19);
            this.textBoxPositionX.Name = "textBoxPositionX";
            this.textBoxPositionX.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionX.TabIndex = 5;
            this.textBoxPositionX.Text = "0";
            // 
            // UCPonctuelLightSource
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.GroupBoxCentre);
            this.Name = "UCPonctuelLightSource";
            this.Size = new System.Drawing.Size(325, 128);
            this.GroupBoxCentre.ResumeLayout(false);
            this.GroupBoxCentre.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GroupBoxCentre;
        private System.Windows.Forms.Label labelPositionX;
        private System.Windows.Forms.Label labelPositionY;
        private System.Windows.Forms.TextBox textBoxPositionZ;
        private System.Windows.Forms.Label labelPositionZ;
        private System.Windows.Forms.TextBox textBoxPositionY;
        private System.Windows.Forms.TextBox textBoxPositionX;
    }
}
