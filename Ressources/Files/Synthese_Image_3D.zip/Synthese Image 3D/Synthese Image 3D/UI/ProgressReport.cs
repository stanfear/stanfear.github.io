﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Projet_Objets_3D.Utilitaires;

namespace Projet_Objets_3D.UI
{
    public partial class ProgressReport : Form, IProgressTracker
    {
        int nbprocess;
        int actprocess;

        public ProgressReport()
        {
            InitializeComponent();
        }

        public int MaxValue
        {
            get
            {
                return this.progressBar1.Maximum;
            }
            set
            {
                this.progressBar1.Maximum = value;
            }
        }

        public int MinValue
        {
            get
            {
                return this.progressBar1.Minimum;
            }
            set
            {
                this.progressBar1.Minimum = value;
            }
        }

        public int CurentValue
        {
            get
            {
                return this.progressBar1.Value;
            }
            set
            {
                this.progressBar1.Value = value;
            }
        }

        public void report(int n)
        {
            this.BeginInvoke(
                new Action(() =>
                {
                    this.progressBar1.Step = n;
                    this.progressBar1.PerformStep();
                }
            ));
        }


        public void init()
        {
            this.progressBar1.Style = ProgressBarStyle.Continuous;
            this.progressBar1.Minimum = 0;
            this.progressBar1.Maximum = this.progressBar1.Size.Width;
            this.progressBar1.Value = MinValue;
            this.Show();
        }

        public void init(int p)
        {
            nbprocess = p;
            this.BeginInvoke(
                new Action(() =>
                {
                    actprocess = 1;
                    this.sideLabel.Text = actprocess + " / " + nbprocess;
                }
            ));
        }

        public void NextStep()
        {
            this.BeginInvoke(
                new Action(() =>
                {
                    actprocess++;
                    this.sideLabel.Text = actprocess + " / " + nbprocess;
                    this.progressBar1.Value = MinValue;
                }
            ));
        }


        public void SetUndefined()
        {
            this.BeginInvoke(
                new Action(() =>
                {
                    this.progressBar1.Style = ProgressBarStyle.Marquee;
                }
            ));
        }

        public void SetDefined()
        {
            this.BeginInvoke(
                new Action(() =>
                {
                    this.progressBar1.Style = ProgressBarStyle.Continuous;
                }
            ));
        }


        public void reportFinish()
        {
            this.Close();
        }
    }
}
