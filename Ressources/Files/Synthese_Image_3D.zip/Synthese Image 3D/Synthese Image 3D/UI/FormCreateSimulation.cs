﻿using Projet_Objets_3D.Utilitaires;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Projet_Objets_3D.UI
{
    public partial class FormCreateSimulation : Form
    {

        public FormCreateSimulation()
        {
            InitializeComponent();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (ValideData)
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }


        internal string NomSimulation
        {
            get
            {
                return tBNom.Text;
            }
            set
            {
                tBNom.Text = value;
            }
        }

        internal Point3D PointCentre
        {
            get
            {
                return new Point3D(double.Parse(textBoxPositionX.Text), double.Parse(textBoxPositionY.Text), double.Parse(textBoxPositionZ.Text));
            }
            set
            {
                textBoxPositionX.Text = value.X.ToString();
                textBoxPositionY.Text = value.Y.ToString();
                textBoxPositionZ.Text = value.Z.ToString();
            }
        }

        internal Size3D Dimensions
        {
            get
            {
                return new Size3D(double.Parse(tBDeltaX.Text), double.Parse(tBDeltaY.Text), double.Parse(tBDeltaZ.Text));
            }
            set
            {
                tBDeltaX.Text = value.Width.ToString();
                tBDeltaY.Text = value.Height.ToString();
                tBDeltaZ.Text = value.Depth.ToString();
            }
        }

        public bool ValideData
        {
            get
            {
                double temp;
                return
                    double.TryParse(textBoxPositionX.Text, out temp) &&
                    double.TryParse(textBoxPositionY.Text, out temp) &&
                    double.TryParse(textBoxPositionZ.Text, out temp) &&
                    double.TryParse(tBDeltaX.Text, out temp) &&
                    double.TryParse(tBDeltaY.Text, out temp) &&
                    double.TryParse(tBDeltaZ.Text, out temp);
            }
        }
    }
}
