﻿namespace Projet_Objets_3D.UI
{
    partial class UCCameraPerspective
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GBCamPerspective = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxLargeur = new System.Windows.Forms.TextBox();
            this.textBoxHauteur = new System.Windows.Forms.TextBox();
            this.labelChampY = new System.Windows.Forms.Label();
            this.labelChampX = new System.Windows.Forms.Label();
            this.GBCamPerspective.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBCamPerspective
            // 
            this.GBCamPerspective.Controls.Add(this.label1);
            this.GBCamPerspective.Controls.Add(this.textBoxLargeur);
            this.GBCamPerspective.Controls.Add(this.textBoxHauteur);
            this.GBCamPerspective.Controls.Add(this.labelChampY);
            this.GBCamPerspective.Controls.Add(this.labelChampX);
            this.GBCamPerspective.Location = new System.Drawing.Point(3, 3);
            this.GBCamPerspective.Name = "GBCamPerspective";
            this.GBCamPerspective.Size = new System.Drawing.Size(200, 175);
            this.GBCamPerspective.TabIndex = 0;
            this.GBCamPerspective.TabStop = false;
            this.GBCamPerspective.Text = "Camera Perspective";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 60);
            this.label1.TabIndex = 8;
            this.label1.Text = "Attention, la caméra Perspective est \r\nencore en développement et peut avoir \r\nun" +
    " comportement non prévisible,\r\n l\'image obtenue ne représente \r\npas nécessaireme" +
    "nt l\'etat de la simulation";
            // 
            // textBoxLargeur
            // 
            this.textBoxLargeur.Location = new System.Drawing.Point(81, 72);
            this.textBoxLargeur.Name = "textBoxLargeur";
            this.textBoxLargeur.Size = new System.Drawing.Size(100, 20);
            this.textBoxLargeur.TabIndex = 7;
            this.textBoxLargeur.Text = "45";
            // 
            // textBoxHauteur
            // 
            this.textBoxHauteur.Location = new System.Drawing.Point(81, 33);
            this.textBoxHauteur.Name = "textBoxHauteur";
            this.textBoxHauteur.Size = new System.Drawing.Size(100, 20);
            this.textBoxHauteur.TabIndex = 6;
            this.textBoxHauteur.Text = "45";
            // 
            // labelChampY
            // 
            this.labelChampY.AutoSize = true;
            this.labelChampY.Location = new System.Drawing.Point(6, 56);
            this.labelChampY.Name = "labelChampY";
            this.labelChampY.Size = new System.Drawing.Size(122, 13);
            this.labelChampY.TabIndex = 5;
            this.labelChampY.Text = "Angle de vision verticale";
            // 
            // labelChampX
            // 
            this.labelChampX.AutoSize = true;
            this.labelChampX.Location = new System.Drawing.Point(6, 17);
            this.labelChampX.Name = "labelChampX";
            this.labelChampX.Size = new System.Drawing.Size(128, 13);
            this.labelChampX.TabIndex = 4;
            this.labelChampX.Text = "angle de vision Horizontal";
            // 
            // UCCameraPerspective
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.GBCamPerspective);
            this.Name = "UCCameraPerspective";
            this.Size = new System.Drawing.Size(208, 183);
            this.GBCamPerspective.ResumeLayout(false);
            this.GBCamPerspective.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GBCamPerspective;
        private System.Windows.Forms.TextBox textBoxLargeur;
        private System.Windows.Forms.TextBox textBoxHauteur;
        private System.Windows.Forms.Label labelChampY;
        private System.Windows.Forms.Label labelChampX;
        private System.Windows.Forms.Label label1;

    }
}
