﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;

namespace Projet_Objets_3D.UI
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void àproposdeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox3DpicturesSyntheses aboutBox = new AboutBox3DpicturesSyntheses();
            aboutBox.ShowDialog();
        }

        private void MainWindow_Load(object sender, EventArgs e)
        {
            /*UserControl uc = new UCGeneral();
            uc.Location = new Point(0,24);
            this.Controls.Add(uc);*/
        }

        private void nouveauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCreateSimulation f = new FormCreateSimulation();
            if (f.ShowDialog() != System.Windows.Forms.DialogResult.Cancel)
            {
                TabPage tabPage = new TabPage(f.NomSimulation);
                simulationsTabControl.Controls.Add(tabPage);
                UCGeneral uc = new UCGeneral();
                Simulation simu = new Simulation(f.Dimensions, f.PointCentre);
                simu.Nom = f.NomSimulation;
                uc.SetSimulation(simu);
                uc.SetParent(tabPage);
                uc.Dock = DockStyle.Fill;
                uc.SetUnsaved();
                tabPage.Controls.Add(uc);
                // le tag de l'onglet va servir de mémoire pour le chemin du fichier
                tabPage.Tag = null;

                enregistrersousToolStripMenuItem1.Enabled = true;
                simulationsTabControl_SelectedIndexChanged(this, EventArgs.Empty);
            }
        }

        private void supprimerLaSimulationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //TODO : Confirmer quitter
            simulationsTabControl.Controls.Remove(simulationsTabControl.SelectedTab);
            //TODO : vérifier si tous les onglets sont fermés -> si oui, désactiver la possibilité de sauver
            // enregistrersousToolStripMenuItem1.Enabled = false;
        }

        private void ouvrirToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                Stream TestFileStream = openFileDialog.OpenFile();
                BinaryFormatter deserializer = new BinaryFormatter();
                Simulation simulation = (Simulation)deserializer.Deserialize(TestFileStream);
                TestFileStream.Close();

                TabPage tabPage = new TabPage(openFileDialog.SafeFileName);
                simulationsTabControl.Controls.Add(tabPage);
                UCGeneral uc = new UCGeneral();
                uc.SetSimulation(simulation);
                uc.SetParent(tabPage);
                uc.Dock = DockStyle.Fill;
                uc.SetSaved();
                tabPage.Controls.Add(uc);
                // le tag de l'onglet va servir de mémoire pour le chemin du fichier
                tabPage.Tag = openFileDialog.FileName;

                //activation du la possibilité de sauver la simulation
                enregistrersousToolStripMenuItem1.Enabled = true;
                simulationsTabControl_SelectedIndexChanged(this, EventArgs.Empty);
            }
        }

        private void enregistrerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // sauvegarde de la simulation active (si un fichier pour cette simulation existe)
            TabPage tp = simulationsTabControl.SelectedTab;
            Simulation simulation = (tp.Controls[0] as UCGeneral).getSimulation();
            (tp.Controls[0] as UCGeneral).SetSaved();

            Stream TestFileStream = File.Create(tp.Tag.ToString());
            BinaryFormatter serializer = new BinaryFormatter();
            serializer.Serialize(TestFileStream, simulation);
            TestFileStream.Close();


            simulationsTabControl.SelectedTab = tp;
        }

        private void enregistrersousToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            TabPage tp = simulationsTabControl.SelectedTab; 
            Simulation simulation = (tp.Controls[0] as UCGeneral).getSimulation();
            // sauvegarde de la simulation active sous un nouveau fichier
            if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                tp.Tag = saveFileDialog.FileName;
                (tp.Controls[0] as UCGeneral).SetSaved();

                Stream TestFileStream = File.Create(tp.Tag.ToString());
                BinaryFormatter serializer = new BinaryFormatter();
                serializer.Serialize(TestFileStream, simulation);
                TestFileStream.Close();

                simulationsTabControl.SelectedTab = tp;
            }
        }

        private void simulationsTabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(simulationsTabControl.SelectedTab.Tag == null)
            {
                enregistrerToolStripMenuItem.Enabled = false;
            }
            else
            {
                enregistrerToolStripMenuItem.Enabled = true;
            }
        }
    }
}
