﻿namespace Projet_Objets_3D.UI
{
    partial class UCCameraOrthogonale
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GBCamOrthogonale = new System.Windows.Forms.GroupBox();
            this.textBoxLargeur = new System.Windows.Forms.TextBox();
            this.textBoxHauteur = new System.Windows.Forms.TextBox();
            this.labelLargeur = new System.Windows.Forms.Label();
            this.labelHauteur = new System.Windows.Forms.Label();
            this.GBCamOrthogonale.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBCamOrthogonale
            // 
            this.GBCamOrthogonale.Controls.Add(this.textBoxLargeur);
            this.GBCamOrthogonale.Controls.Add(this.textBoxHauteur);
            this.GBCamOrthogonale.Controls.Add(this.labelLargeur);
            this.GBCamOrthogonale.Controls.Add(this.labelHauteur);
            this.GBCamOrthogonale.Location = new System.Drawing.Point(2, 3);
            this.GBCamOrthogonale.Name = "GBCamOrthogonale";
            this.GBCamOrthogonale.Size = new System.Drawing.Size(200, 175);
            this.GBCamOrthogonale.TabIndex = 0;
            this.GBCamOrthogonale.TabStop = false;
            this.GBCamOrthogonale.Text = "Camera Orthogonale";
            // 
            // textBoxLargeur
            // 
            this.textBoxLargeur.Location = new System.Drawing.Point(74, 105);
            this.textBoxLargeur.Name = "textBoxLargeur";
            this.textBoxLargeur.Size = new System.Drawing.Size(100, 20);
            this.textBoxLargeur.TabIndex = 3;
            this.textBoxLargeur.Text = "1";
            // 
            // textBoxHauteur
            // 
            this.textBoxHauteur.Location = new System.Drawing.Point(74, 40);
            this.textBoxHauteur.Name = "textBoxHauteur";
            this.textBoxHauteur.Size = new System.Drawing.Size(100, 20);
            this.textBoxHauteur.TabIndex = 2;
            this.textBoxHauteur.Text = "1";
            // 
            // labelLargeur
            // 
            this.labelLargeur.AutoSize = true;
            this.labelLargeur.Location = new System.Drawing.Point(6, 108);
            this.labelLargeur.Name = "labelLargeur";
            this.labelLargeur.Size = new System.Drawing.Size(43, 13);
            this.labelLargeur.TabIndex = 1;
            this.labelLargeur.Text = "Largeur";
            // 
            // labelHauteur
            // 
            this.labelHauteur.AutoSize = true;
            this.labelHauteur.Location = new System.Drawing.Point(6, 43);
            this.labelHauteur.Name = "labelHauteur";
            this.labelHauteur.Size = new System.Drawing.Size(45, 13);
            this.labelHauteur.TabIndex = 0;
            this.labelHauteur.Text = "Hauteur";
            // 
            // UCCameraOrthogonale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.GBCamOrthogonale);
            this.Name = "UCCameraOrthogonale";
            this.Size = new System.Drawing.Size(205, 181);
            this.GBCamOrthogonale.ResumeLayout(false);
            this.GBCamOrthogonale.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GBCamOrthogonale;
        private System.Windows.Forms.Label labelHauteur;
        private System.Windows.Forms.Label labelLargeur;
        private System.Windows.Forms.TextBox textBoxLargeur;
        private System.Windows.Forms.TextBox textBoxHauteur;
    }
}
