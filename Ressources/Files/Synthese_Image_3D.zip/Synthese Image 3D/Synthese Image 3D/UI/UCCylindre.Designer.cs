﻿namespace Projet_Objets_3D.UI
{
    partial class UCCylindre
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rayonSphere = new System.Windows.Forms.Label();
            this.Titre_sphere = new System.Windows.Forms.Label();
            this.positionX = new System.Windows.Forms.Label();
            this.positionY = new System.Windows.Forms.Label();
            this.positionZ = new System.Windows.Forms.Label();
            this.GroupBoxCentre = new System.Windows.Forms.GroupBox();
            this.labelPositionX = new System.Windows.Forms.Label();
            this.labelPositionY = new System.Windows.Forms.Label();
            this.textBoxPositionZ = new System.Windows.Forms.TextBox();
            this.labelPositionZ = new System.Windows.Forms.Label();
            this.textBoxPositionY = new System.Windows.Forms.TextBox();
            this.textBoxPositionX = new System.Windows.Forms.TextBox();
            this.textBoxRayonCylindre = new System.Windows.Forms.TextBox();
            this.labelRayonSphere = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tBVecteurHauteurZ = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tBVecteurHauteurY = new System.Windows.Forms.TextBox();
            this.tBVecteurHauteurX = new System.Windows.Forms.TextBox();
            this.GroupBoxCentre.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rayonSphere
            // 
            this.rayonSphere.AutoSize = true;
            this.rayonSphere.Location = new System.Drawing.Point(-121, 151);
            this.rayonSphere.Name = "rayonSphere";
            this.rayonSphere.Size = new System.Drawing.Size(45, 13);
            this.rayonSphere.TabIndex = 15;
            this.rayonSphere.Text = "RAYON";
            // 
            // Titre_sphere
            // 
            this.Titre_sphere.AutoSize = true;
            this.Titre_sphere.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Titre_sphere.Location = new System.Drawing.Point(-29, -20);
            this.Titre_sphere.Name = "Titre_sphere";
            this.Titre_sphere.Size = new System.Drawing.Size(205, 13);
            this.Titre_sphere.TabIndex = 11;
            this.Titre_sphere.Text = "OUTILS DE CREATION D\'UNE SPHERE";
            this.Titre_sphere.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // positionX
            // 
            this.positionX.AutoSize = true;
            this.positionX.Location = new System.Drawing.Point(-137, 43);
            this.positionX.Name = "positionX";
            this.positionX.Size = new System.Drawing.Size(86, 13);
            this.positionX.TabIndex = 12;
            this.positionX.Text = "POSITION EN X";
            // 
            // positionY
            // 
            this.positionY.AutoSize = true;
            this.positionY.Location = new System.Drawing.Point(-137, 81);
            this.positionY.Name = "positionY";
            this.positionY.Size = new System.Drawing.Size(86, 13);
            this.positionY.TabIndex = 13;
            this.positionY.Text = "POSITION EN Y";
            // 
            // positionZ
            // 
            this.positionZ.AutoSize = true;
            this.positionZ.Location = new System.Drawing.Point(-137, 119);
            this.positionZ.Name = "positionZ";
            this.positionZ.Size = new System.Drawing.Size(86, 13);
            this.positionZ.TabIndex = 14;
            this.positionZ.Text = "POSITION EN Z";
            // 
            // GroupBoxCentre
            // 
            this.GroupBoxCentre.Controls.Add(this.labelPositionX);
            this.GroupBoxCentre.Controls.Add(this.labelPositionY);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionZ);
            this.GroupBoxCentre.Controls.Add(this.labelPositionZ);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionY);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionX);
            this.GroupBoxCentre.Location = new System.Drawing.Point(148, 3);
            this.GroupBoxCentre.Name = "GroupBoxCentre";
            this.GroupBoxCentre.Size = new System.Drawing.Size(175, 95);
            this.GroupBoxCentre.TabIndex = 18;
            this.GroupBoxCentre.TabStop = false;
            this.GroupBoxCentre.Text = "Centre du cercle base";
            // 
            // labelPositionX
            // 
            this.labelPositionX.AutoSize = true;
            this.labelPositionX.Location = new System.Drawing.Point(84, 22);
            this.labelPositionX.Name = "labelPositionX";
            this.labelPositionX.Size = new System.Drawing.Size(20, 13);
            this.labelPositionX.TabIndex = 1;
            this.labelPositionX.Text = "X :";
            // 
            // labelPositionY
            // 
            this.labelPositionY.AutoSize = true;
            this.labelPositionY.Location = new System.Drawing.Point(84, 44);
            this.labelPositionY.Name = "labelPositionY";
            this.labelPositionY.Size = new System.Drawing.Size(20, 13);
            this.labelPositionY.TabIndex = 2;
            this.labelPositionY.Text = "Y :";
            // 
            // textBoxPositionZ
            // 
            this.textBoxPositionZ.Location = new System.Drawing.Point(110, 64);
            this.textBoxPositionZ.Name = "textBoxPositionZ";
            this.textBoxPositionZ.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionZ.TabIndex = 7;
            this.textBoxPositionZ.Text = "0";
            // 
            // labelPositionZ
            // 
            this.labelPositionZ.AutoSize = true;
            this.labelPositionZ.Location = new System.Drawing.Point(84, 67);
            this.labelPositionZ.Name = "labelPositionZ";
            this.labelPositionZ.Size = new System.Drawing.Size(20, 13);
            this.labelPositionZ.TabIndex = 3;
            this.labelPositionZ.Text = "Z :";
            // 
            // textBoxPositionY
            // 
            this.textBoxPositionY.Location = new System.Drawing.Point(110, 41);
            this.textBoxPositionY.Name = "textBoxPositionY";
            this.textBoxPositionY.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionY.TabIndex = 6;
            this.textBoxPositionY.Text = "0";
            // 
            // textBoxPositionX
            // 
            this.textBoxPositionX.Location = new System.Drawing.Point(110, 19);
            this.textBoxPositionX.Name = "textBoxPositionX";
            this.textBoxPositionX.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionX.TabIndex = 5;
            this.textBoxPositionX.Text = "0";
            // 
            // textBoxRayonCylindre
            // 
            this.textBoxRayonCylindre.Location = new System.Drawing.Point(258, 205);
            this.textBoxRayonCylindre.Name = "textBoxRayonCylindre";
            this.textBoxRayonCylindre.Size = new System.Drawing.Size(59, 20);
            this.textBoxRayonCylindre.TabIndex = 17;
            this.textBoxRayonCylindre.Text = "0,3";
            // 
            // labelRayonSphere
            // 
            this.labelRayonSphere.AutoSize = true;
            this.labelRayonSphere.Location = new System.Drawing.Point(147, 208);
            this.labelRayonSphere.Name = "labelRayonSphere";
            this.labelRayonSphere.Size = new System.Drawing.Size(92, 13);
            this.labelRayonSphere.TabIndex = 16;
            this.labelRayonSphere.Text = "Rayon du cylindre";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tBVecteurHauteurZ);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tBVecteurHauteurY);
            this.groupBox1.Controls.Add(this.tBVecteurHauteurX);
            this.groupBox1.Location = new System.Drawing.Point(148, 104);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(175, 95);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vecteur hauteur";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "X :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Y :";
            // 
            // tBVecteurHauteurZ
            // 
            this.tBVecteurHauteurZ.Location = new System.Drawing.Point(110, 64);
            this.tBVecteurHauteurZ.Name = "tBVecteurHauteurZ";
            this.tBVecteurHauteurZ.Size = new System.Drawing.Size(59, 20);
            this.tBVecteurHauteurZ.TabIndex = 7;
            this.tBVecteurHauteurZ.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Z :";
            // 
            // tBVecteurHauteurY
            // 
            this.tBVecteurHauteurY.Location = new System.Drawing.Point(110, 41);
            this.tBVecteurHauteurY.Name = "tBVecteurHauteurY";
            this.tBVecteurHauteurY.Size = new System.Drawing.Size(59, 20);
            this.tBVecteurHauteurY.TabIndex = 6;
            this.tBVecteurHauteurY.Text = "1";
            // 
            // tBVecteurHauteurX
            // 
            this.tBVecteurHauteurX.Location = new System.Drawing.Point(110, 19);
            this.tBVecteurHauteurX.Name = "tBVecteurHauteurX";
            this.tBVecteurHauteurX.Size = new System.Drawing.Size(59, 20);
            this.tBVecteurHauteurX.TabIndex = 5;
            this.tBVecteurHauteurX.Text = "0";
            // 
            // UCCylindre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.GroupBoxCentre);
            this.Controls.Add(this.textBoxRayonCylindre);
            this.Controls.Add(this.labelRayonSphere);
            this.Controls.Add(this.rayonSphere);
            this.Controls.Add(this.positionZ);
            this.Controls.Add(this.positionY);
            this.Controls.Add(this.positionX);
            this.Controls.Add(this.Titre_sphere);
            this.Name = "UCCylindre";
            this.Size = new System.Drawing.Size(326, 291);
            this.GroupBoxCentre.ResumeLayout(false);
            this.GroupBoxCentre.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label rayonSphere;
        private System.Windows.Forms.Label Titre_sphere;
        private System.Windows.Forms.Label positionX;
        private System.Windows.Forms.Label positionY;
        private System.Windows.Forms.Label positionZ;
        private System.Windows.Forms.GroupBox GroupBoxCentre;
        private System.Windows.Forms.Label labelPositionX;
        private System.Windows.Forms.Label labelPositionY;
        private System.Windows.Forms.TextBox textBoxPositionZ;
        private System.Windows.Forms.Label labelPositionZ;
        private System.Windows.Forms.TextBox textBoxPositionY;
        private System.Windows.Forms.TextBox textBoxPositionX;
        private System.Windows.Forms.TextBox textBoxRayonCylindre;
        private System.Windows.Forms.Label labelRayonSphere;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBVecteurHauteurZ;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBVecteurHauteurY;
        private System.Windows.Forms.TextBox tBVecteurHauteurX;

    }
}
