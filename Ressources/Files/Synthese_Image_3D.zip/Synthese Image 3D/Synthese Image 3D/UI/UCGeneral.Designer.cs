﻿namespace Projet_Objets_3D.UI
{
    partial class UCGeneral
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

       // private fenetre_cylindre _fenCyl;


        /// <summary> 
        /// Clean up any resources being used
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Formes = new System.Windows.Forms.ListBox();
            this.Cameras = new System.Windows.Forms.ListBox();
            this.genererSim = new System.Windows.Forms.Button();
            this.comboBoxCamera = new System.Windows.Forms.ComboBox();
            this.groupBoxFormes = new System.Windows.Forms.GroupBox();
            this.toolStripContainerFormes = new System.Windows.Forms.ToolStripContainer();
            this.toolStripFormes = new System.Windows.Forms.ToolStrip();
            this.groupBoxSources = new System.Windows.Forms.GroupBox();
            this.toolStripContainerLightSources = new System.Windows.Forms.ToolStripContainer();
            this.toolStripLightSources = new System.Windows.Forms.ToolStrip();
            this.Sources = new System.Windows.Forms.ListBox();
            this.groupBoxCameras = new System.Windows.Forms.GroupBox();
            this.toolStripContainerCameras = new System.Windows.Forms.ToolStripContainer();
            this.toolStripCameras = new System.Windows.Forms.ToolStrip();
            this.labelChoixCamera = new System.Windows.Forms.Label();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.toolStripSplitButtonAddCamera = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripMenuItemAddPerspectiveCamera = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemAddOrthogonaleCaméra = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButtonEditCamera = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonRemoveCamera = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButtonAddLightSource = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripMenuItemAddPonctualLightSource = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemAddAmbiantLightSource = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButtonEditLightSource = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonRemoveLightSource = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButtonAddForme = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripMenuItemAddCylindre = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemAddSphere = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButtonEditForme = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonDeleteForme = new System.Windows.Forms.ToolStripButton();
            this.groupBoxFormes.SuspendLayout();
            this.toolStripContainerFormes.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainerFormes.ContentPanel.SuspendLayout();
            this.toolStripContainerFormes.SuspendLayout();
            this.toolStripFormes.SuspendLayout();
            this.groupBoxSources.SuspendLayout();
            this.toolStripContainerLightSources.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainerLightSources.ContentPanel.SuspendLayout();
            this.toolStripContainerLightSources.SuspendLayout();
            this.toolStripLightSources.SuspendLayout();
            this.groupBoxCameras.SuspendLayout();
            this.toolStripContainerCameras.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainerCameras.ContentPanel.SuspendLayout();
            this.toolStripContainerCameras.SuspendLayout();
            this.toolStripCameras.SuspendLayout();
            this.SuspendLayout();
            // 
            // Formes
            // 
            this.Formes.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Formes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Formes.FormattingEnabled = true;
            this.Formes.Location = new System.Drawing.Point(0, 0);
            this.Formes.Name = "Formes";
            this.Formes.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.Formes.Size = new System.Drawing.Size(162, 119);
            this.Formes.TabIndex = 0;
            this.Formes.SelectedIndexChanged += new System.EventHandler(this.Formes_SelectedIndexChanged);
            // 
            // Cameras
            // 
            this.Cameras.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Cameras.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Cameras.FormattingEnabled = true;
            this.Cameras.Location = new System.Drawing.Point(0, 0);
            this.Cameras.Name = "Cameras";
            this.Cameras.Size = new System.Drawing.Size(163, 127);
            this.Cameras.TabIndex = 2;
            this.Cameras.SelectedIndexChanged += new System.EventHandler(this.Cameras_SelectedIndexChanged);
            this.Cameras.DataSourceChanged += new System.EventHandler(this.Cameras_DataSourceChanged);
            this.Cameras.Leave += new System.EventHandler(this.Cameras_Leave);
            // 
            // genererSim
            // 
            this.genererSim.Location = new System.Drawing.Point(664, 449);
            this.genererSim.Name = "genererSim";
            this.genererSim.Size = new System.Drawing.Size(106, 23);
            this.genererSim.TabIndex = 8;
            this.genererSim.Text = "Lancer Simulation";
            this.genererSim.UseVisualStyleBackColor = true;
            this.genererSim.Click += new System.EventHandler(this.genererSim_Click);
            // 
            // comboBoxCamera
            // 
            this.comboBoxCamera.FormattingEnabled = true;
            this.comboBoxCamera.Location = new System.Drawing.Point(484, 455);
            this.comboBoxCamera.Name = "comboBoxCamera";
            this.comboBoxCamera.Size = new System.Drawing.Size(129, 21);
            this.comboBoxCamera.TabIndex = 9;
            // 
            // groupBoxFormes
            // 
            this.groupBoxFormes.Controls.Add(this.toolStripContainerFormes);
            this.groupBoxFormes.Location = new System.Drawing.Point(1, 0);
            this.groupBoxFormes.Name = "groupBoxFormes";
            this.groupBoxFormes.Size = new System.Drawing.Size(168, 163);
            this.groupBoxFormes.TabIndex = 12;
            this.groupBoxFormes.TabStop = false;
            this.groupBoxFormes.Text = "Formes";
            this.groupBoxFormes.Leave += new System.EventHandler(this.groupBoxFormes_Leave);
            // 
            // toolStripContainerFormes
            // 
            // 
            // toolStripContainerFormes.BottomToolStripPanel
            // 
            this.toolStripContainerFormes.BottomToolStripPanel.Controls.Add(this.toolStripFormes);
            // 
            // toolStripContainerFormes.ContentPanel
            // 
            this.toolStripContainerFormes.ContentPanel.Controls.Add(this.Formes);
            this.toolStripContainerFormes.ContentPanel.Size = new System.Drawing.Size(162, 119);
            this.toolStripContainerFormes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainerFormes.LeftToolStripPanelVisible = false;
            this.toolStripContainerFormes.Location = new System.Drawing.Point(3, 16);
            this.toolStripContainerFormes.Name = "toolStripContainerFormes";
            this.toolStripContainerFormes.RightToolStripPanelVisible = false;
            this.toolStripContainerFormes.Size = new System.Drawing.Size(162, 144);
            this.toolStripContainerFormes.TabIndex = 0;
            this.toolStripContainerFormes.Text = "toolStripContainer1";
            this.toolStripContainerFormes.TopToolStripPanelVisible = false;
            // 
            // toolStripFormes
            // 
            this.toolStripFormes.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStripFormes.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripFormes.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButtonAddForme,
            this.toolStripButtonEditForme,
            this.toolStripButtonDeleteForme});
            this.toolStripFormes.Location = new System.Drawing.Point(3, 0);
            this.toolStripFormes.Name = "toolStripFormes";
            this.toolStripFormes.Padding = new System.Windows.Forms.Padding(0);
            this.toolStripFormes.Size = new System.Drawing.Size(80, 25);
            this.toolStripFormes.TabIndex = 0;
            // 
            // groupBoxSources
            // 
            this.groupBoxSources.Controls.Add(this.toolStripContainerLightSources);
            this.groupBoxSources.Location = new System.Drawing.Point(1, 171);
            this.groupBoxSources.Margin = new System.Windows.Forms.Padding(5);
            this.groupBoxSources.Name = "groupBoxSources";
            this.groupBoxSources.Size = new System.Drawing.Size(168, 155);
            this.groupBoxSources.TabIndex = 13;
            this.groupBoxSources.TabStop = false;
            this.groupBoxSources.Text = "Sources lumineuses";
            // 
            // toolStripContainerLightSources
            // 
            // 
            // toolStripContainerLightSources.BottomToolStripPanel
            // 
            this.toolStripContainerLightSources.BottomToolStripPanel.Controls.Add(this.toolStripLightSources);
            // 
            // toolStripContainerLightSources.ContentPanel
            // 
            this.toolStripContainerLightSources.ContentPanel.Controls.Add(this.Sources);
            this.toolStripContainerLightSources.ContentPanel.Size = new System.Drawing.Size(162, 111);
            this.toolStripContainerLightSources.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainerLightSources.LeftToolStripPanelVisible = false;
            this.toolStripContainerLightSources.Location = new System.Drawing.Point(3, 16);
            this.toolStripContainerLightSources.Name = "toolStripContainerLightSources";
            this.toolStripContainerLightSources.RightToolStripPanelVisible = false;
            this.toolStripContainerLightSources.Size = new System.Drawing.Size(162, 136);
            this.toolStripContainerLightSources.TabIndex = 16;
            this.toolStripContainerLightSources.Text = "toolStripContainer1";
            this.toolStripContainerLightSources.TopToolStripPanelVisible = false;
            // 
            // toolStripLightSources
            // 
            this.toolStripLightSources.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStripLightSources.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripLightSources.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButtonAddLightSource,
            this.toolStripButtonEditLightSource,
            this.toolStripButtonRemoveLightSource});
            this.toolStripLightSources.Location = new System.Drawing.Point(3, 0);
            this.toolStripLightSources.Name = "toolStripLightSources";
            this.toolStripLightSources.Size = new System.Drawing.Size(81, 25);
            this.toolStripLightSources.TabIndex = 0;
            // 
            // Sources
            // 
            this.Sources.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Sources.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Sources.FormattingEnabled = true;
            this.Sources.Location = new System.Drawing.Point(0, 0);
            this.Sources.Name = "Sources";
            this.Sources.Size = new System.Drawing.Size(162, 111);
            this.Sources.TabIndex = 1;
            this.Sources.SelectedIndexChanged += new System.EventHandler(this.Sources_SelectedIndexChanged);
            this.Sources.Leave += new System.EventHandler(this.Sources_Leave);
            // 
            // groupBoxCameras
            // 
            this.groupBoxCameras.Controls.Add(this.toolStripContainerCameras);
            this.groupBoxCameras.Location = new System.Drawing.Point(0, 334);
            this.groupBoxCameras.Name = "groupBoxCameras";
            this.groupBoxCameras.Size = new System.Drawing.Size(169, 171);
            this.groupBoxCameras.TabIndex = 14;
            this.groupBoxCameras.TabStop = false;
            this.groupBoxCameras.Text = "Cameras";
            // 
            // toolStripContainerCameras
            // 
            // 
            // toolStripContainerCameras.BottomToolStripPanel
            // 
            this.toolStripContainerCameras.BottomToolStripPanel.Controls.Add(this.toolStripCameras);
            // 
            // toolStripContainerCameras.ContentPanel
            // 
            this.toolStripContainerCameras.ContentPanel.Controls.Add(this.Cameras);
            this.toolStripContainerCameras.ContentPanel.Size = new System.Drawing.Size(163, 127);
            this.toolStripContainerCameras.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainerCameras.LeftToolStripPanelVisible = false;
            this.toolStripContainerCameras.Location = new System.Drawing.Point(3, 16);
            this.toolStripContainerCameras.Name = "toolStripContainerCameras";
            this.toolStripContainerCameras.RightToolStripPanelVisible = false;
            this.toolStripContainerCameras.Size = new System.Drawing.Size(163, 152);
            this.toolStripContainerCameras.TabIndex = 17;
            this.toolStripContainerCameras.Text = "toolStripContainer2";
            this.toolStripContainerCameras.TopToolStripPanelVisible = false;
            // 
            // toolStripCameras
            // 
            this.toolStripCameras.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStripCameras.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripCameras.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButtonAddCamera,
            this.toolStripButtonEditCamera,
            this.toolStripButtonRemoveCamera});
            this.toolStripCameras.Location = new System.Drawing.Point(3, 0);
            this.toolStripCameras.Name = "toolStripCameras";
            this.toolStripCameras.Size = new System.Drawing.Size(112, 25);
            this.toolStripCameras.TabIndex = 0;
            // 
            // labelChoixCamera
            // 
            this.labelChoixCamera.AutoSize = true;
            this.labelChoixCamera.Location = new System.Drawing.Point(513, 439);
            this.labelChoixCamera.Name = "labelChoixCamera";
            this.labelChoixCamera.Size = new System.Drawing.Size(72, 13);
            this.labelChoixCamera.TabIndex = 15;
            this.labelChoixCamera.Text = "Choix Caméra";
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Size = new System.Drawing.Size(141, 100);
            // 
            // toolStripSplitButtonAddCamera
            // 
            this.toolStripSplitButtonAddCamera.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButtonAddCamera.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemAddPerspectiveCamera,
            this.toolStripMenuItemAddOrthogonaleCaméra});
            this.toolStripSplitButtonAddCamera.Image = global::Projet_Objets_3D.Properties.Resources.ajouterCamera;
            this.toolStripSplitButtonAddCamera.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButtonAddCamera.Name = "toolStripSplitButtonAddCamera";
            this.toolStripSplitButtonAddCamera.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButtonAddCamera.Text = "Ajouter une Caméra";
            this.toolStripSplitButtonAddCamera.ToolTipText = "Ajouter une Caméra";
            this.toolStripSplitButtonAddCamera.ButtonClick += new System.EventHandler(this.toolStripSplitButtonAddCamera_ButtonClick);
            // 
            // toolStripMenuItemAddPerspectiveCamera
            // 
            this.toolStripMenuItemAddPerspectiveCamera.Name = "toolStripMenuItemAddPerspectiveCamera";
            this.toolStripMenuItemAddPerspectiveCamera.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItemAddPerspectiveCamera.Text = "Caméra Perspective";
            this.toolStripMenuItemAddPerspectiveCamera.Click += new System.EventHandler(this.toolStripMenuItemAddPerspectiveCamera_Click);
            // 
            // toolStripMenuItemAddOrthogonaleCaméra
            // 
            this.toolStripMenuItemAddOrthogonaleCaméra.Name = "toolStripMenuItemAddOrthogonaleCaméra";
            this.toolStripMenuItemAddOrthogonaleCaméra.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItemAddOrthogonaleCaméra.Text = "Caméra orthogonale";
            this.toolStripMenuItemAddOrthogonaleCaméra.Click += new System.EventHandler(this.toolStripMenuItemAddOrthogonaleCaméra_Click);
            // 
            // toolStripButtonEditCamera
            // 
            this.toolStripButtonEditCamera.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEditCamera.Enabled = false;
            this.toolStripButtonEditCamera.Image = global::Projet_Objets_3D.Properties.Resources.modifierCamera;
            this.toolStripButtonEditCamera.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEditCamera.Name = "toolStripButtonEditCamera";
            this.toolStripButtonEditCamera.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonEditCamera.Text = "Modifier la Caméra";
            this.toolStripButtonEditCamera.ToolTipText = "Modifier la Caméra";
            this.toolStripButtonEditCamera.Click += new System.EventHandler(this.toolStripButtonEditCamera_Click);
            // 
            // toolStripButtonRemoveCamera
            // 
            this.toolStripButtonRemoveCamera.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonRemoveCamera.Enabled = false;
            this.toolStripButtonRemoveCamera.Image = global::Projet_Objets_3D.Properties.Resources.supprimerCamera;
            this.toolStripButtonRemoveCamera.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRemoveCamera.Name = "toolStripButtonRemoveCamera";
            this.toolStripButtonRemoveCamera.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonRemoveCamera.Text = "Supprimer";
            this.toolStripButtonRemoveCamera.Click += new System.EventHandler(this.toolStripButtonRemoveCamera_Click);
            // 
            // toolStripSplitButtonAddLightSource
            // 
            this.toolStripSplitButtonAddLightSource.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButtonAddLightSource.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemAddPonctualLightSource,
            this.toolStripMenuItemAddAmbiantLightSource});
            this.toolStripSplitButtonAddLightSource.Image = global::Projet_Objets_3D.Properties.Resources.ajouterLumiere;
            this.toolStripSplitButtonAddLightSource.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButtonAddLightSource.Name = "toolStripSplitButtonAddLightSource";
            this.toolStripSplitButtonAddLightSource.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButtonAddLightSource.Text = "Ajouter une source lumineuse";
            this.toolStripSplitButtonAddLightSource.ButtonClick += new System.EventHandler(this.toolStripSplitButtonAddLightSource_ButtonClick);
            // 
            // toolStripMenuItemAddPonctualLightSource
            // 
            this.toolStripMenuItemAddPonctualLightSource.Name = "toolStripMenuItemAddPonctualLightSource";
            this.toolStripMenuItemAddPonctualLightSource.Size = new System.Drawing.Size(222, 22);
            this.toolStripMenuItemAddPonctualLightSource.Text = "Source ponctuelle";
            this.toolStripMenuItemAddPonctualLightSource.Click += new System.EventHandler(this.toolStripMenuItemAddPonctualLightSource_Click);
            // 
            // toolStripMenuItemAddAmbiantLightSource
            // 
            this.toolStripMenuItemAddAmbiantLightSource.Enabled = false;
            this.toolStripMenuItemAddAmbiantLightSource.Name = "toolStripMenuItemAddAmbiantLightSource";
            this.toolStripMenuItemAddAmbiantLightSource.Size = new System.Drawing.Size(222, 22);
            this.toolStripMenuItemAddAmbiantLightSource.Text = "Source de lumière ambiante";
            this.toolStripMenuItemAddAmbiantLightSource.Click += new System.EventHandler(this.toolStripMenuItemAddAmbiantLightSource_Click);
            // 
            // toolStripButtonEditLightSource
            // 
            this.toolStripButtonEditLightSource.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEditLightSource.Enabled = false;
            this.toolStripButtonEditLightSource.Image = global::Projet_Objets_3D.Properties.Resources.modifierLumiere;
            this.toolStripButtonEditLightSource.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEditLightSource.Name = "toolStripButtonEditLightSource";
            this.toolStripButtonEditLightSource.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonEditLightSource.Text = "Modifier la source de lumière";
            this.toolStripButtonEditLightSource.Click += new System.EventHandler(this.toolStripButtonEditLightSource_Click);
            // 
            // toolStripButtonRemoveLightSource
            // 
            this.toolStripButtonRemoveLightSource.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonRemoveLightSource.Enabled = false;
            this.toolStripButtonRemoveLightSource.Image = global::Projet_Objets_3D.Properties.Resources.supprimerLumiere;
            this.toolStripButtonRemoveLightSource.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRemoveLightSource.Name = "toolStripButtonRemoveLightSource";
            this.toolStripButtonRemoveLightSource.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonRemoveLightSource.Text = "Supprimer";
            this.toolStripButtonRemoveLightSource.Click += new System.EventHandler(this.toolStripButtonRemoveLightSource_Click);
            // 
            // toolStripSplitButtonAddForme
            // 
            this.toolStripSplitButtonAddForme.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButtonAddForme.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemAddCylindre,
            this.toolStripMenuItemAddSphere});
            this.toolStripSplitButtonAddForme.Image = global::Projet_Objets_3D.Properties.Resources.ajouterForme;
            this.toolStripSplitButtonAddForme.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButtonAddForme.Name = "toolStripSplitButtonAddForme";
            this.toolStripSplitButtonAddForme.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButtonAddForme.Text = "Ajouter une forme";
            this.toolStripSplitButtonAddForme.ButtonClick += new System.EventHandler(this.toolStripSplitButtonAddForme_ButtonClick);
            // 
            // toolStripMenuItemAddCylindre
            // 
            this.toolStripMenuItemAddCylindre.Name = "toolStripMenuItemAddCylindre";
            this.toolStripMenuItemAddCylindre.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItemAddCylindre.Text = "Cylindre";
            this.toolStripMenuItemAddCylindre.Click += new System.EventHandler(this.toolStripMenuItemAddCylindre_Click);
            // 
            // toolStripMenuItemAddSphere
            // 
            this.toolStripMenuItemAddSphere.Name = "toolStripMenuItemAddSphere";
            this.toolStripMenuItemAddSphere.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItemAddSphere.Text = "Sphère";
            this.toolStripMenuItemAddSphere.Click += new System.EventHandler(this.toolStripMenuItemAddSphere_Click);
            // 
            // toolStripButtonEditForme
            // 
            this.toolStripButtonEditForme.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEditForme.Enabled = false;
            this.toolStripButtonEditForme.Image = global::Projet_Objets_3D.Properties.Resources.modifierForme;
            this.toolStripButtonEditForme.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEditForme.Name = "toolStripButtonEditForme";
            this.toolStripButtonEditForme.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonEditForme.Text = "Modifier";
            this.toolStripButtonEditForme.Click += new System.EventHandler(this.toolStripButtonEditForme_Click);
            // 
            // toolStripButtonDeleteForme
            // 
            this.toolStripButtonDeleteForme.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonDeleteForme.Enabled = false;
            this.toolStripButtonDeleteForme.Image = global::Projet_Objets_3D.Properties.Resources.supprimerForme;
            this.toolStripButtonDeleteForme.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonDeleteForme.Name = "toolStripButtonDeleteForme";
            this.toolStripButtonDeleteForme.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonDeleteForme.Text = "Supprimer";
            this.toolStripButtonDeleteForme.Click += new System.EventHandler(this.toolStripButtonDeleteForme_Click);
            // 
            // UCGeneral
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Controls.Add(this.labelChoixCamera);
            this.Controls.Add(this.comboBoxCamera);
            this.Controls.Add(this.groupBoxCameras);
            this.Controls.Add(this.groupBoxSources);
            this.Controls.Add(this.groupBoxFormes);
            this.Controls.Add(this.genererSim);
            this.Name = "UCGeneral";
            this.Padding = new System.Windows.Forms.Padding(5, 20, 5, 0);
            this.Size = new System.Drawing.Size(884, 505);
            this.Load += new System.EventHandler(this.UCGeneral_Load);
            this.groupBoxFormes.ResumeLayout(false);
            this.toolStripContainerFormes.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainerFormes.BottomToolStripPanel.PerformLayout();
            this.toolStripContainerFormes.ContentPanel.ResumeLayout(false);
            this.toolStripContainerFormes.ResumeLayout(false);
            this.toolStripContainerFormes.PerformLayout();
            this.toolStripFormes.ResumeLayout(false);
            this.toolStripFormes.PerformLayout();
            this.groupBoxSources.ResumeLayout(false);
            this.toolStripContainerLightSources.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainerLightSources.BottomToolStripPanel.PerformLayout();
            this.toolStripContainerLightSources.ContentPanel.ResumeLayout(false);
            this.toolStripContainerLightSources.ResumeLayout(false);
            this.toolStripContainerLightSources.PerformLayout();
            this.toolStripLightSources.ResumeLayout(false);
            this.toolStripLightSources.PerformLayout();
            this.groupBoxCameras.ResumeLayout(false);
            this.toolStripContainerCameras.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainerCameras.BottomToolStripPanel.PerformLayout();
            this.toolStripContainerCameras.ContentPanel.ResumeLayout(false);
            this.toolStripContainerCameras.ResumeLayout(false);
            this.toolStripContainerCameras.PerformLayout();
            this.toolStripCameras.ResumeLayout(false);
            this.toolStripCameras.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox Formes;
        private System.Windows.Forms.ListBox Cameras;
        private System.Windows.Forms.Button genererSim;
        private System.Windows.Forms.ComboBox comboBoxCamera;
        private System.Windows.Forms.GroupBox groupBoxFormes;
        private System.Windows.Forms.GroupBox groupBoxSources;
        private System.Windows.Forms.GroupBox groupBoxCameras;
        private System.Windows.Forms.Label labelChoixCamera;
        private System.Windows.Forms.ToolStrip toolStripFormes;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButtonAddForme;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemAddCylindre;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemAddSphere;
        private System.Windows.Forms.ToolStripButton toolStripButtonEditForme;
        private System.Windows.Forms.ToolStripContainer toolStripContainerFormes;
        private System.Windows.Forms.ToolStripButton toolStripButtonDeleteForme;
        private System.Windows.Forms.ToolStripContainer toolStripContainerLightSources;
        private System.Windows.Forms.ToolStrip toolStripLightSources;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButtonAddLightSource;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemAddPonctualLightSource;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemAddAmbiantLightSource;
        private System.Windows.Forms.ToolStripButton toolStripButtonEditLightSource;
        private System.Windows.Forms.ToolStripButton toolStripButtonRemoveLightSource;
        private System.Windows.Forms.ListBox Sources;
        private System.Windows.Forms.ToolStripContainer toolStripContainerCameras;
        private System.Windows.Forms.ToolStrip toolStripCameras;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButtonAddCamera;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemAddPerspectiveCamera;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemAddOrthogonaleCaméra;
        private System.Windows.Forms.ToolStripButton toolStripButtonEditCamera;
        private System.Windows.Forms.ToolStripButton toolStripButtonRemoveCamera;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
    }
}
