﻿namespace Projet_Objets_3D.UI
{
    partial class FormCreateCameras
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CBTypeCamera = new System.Windows.Forms.ComboBox();
            this.buttonAnnuler = new System.Windows.Forms.Button();
            this.buttonValider = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tBVecteurDirectionZ = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tBVecteurDirectionY = new System.Windows.Forms.TextBox();
            this.tBVecteurDirectionX = new System.Windows.Forms.TextBox();
            this.GroupBoxCentre = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxPositionZ = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxPositionY = new System.Windows.Forms.TextBox();
            this.textBoxPositionX = new System.Windows.Forms.TextBox();
            this.textBoxNomForme = new System.Windows.Forms.TextBox();
            this.NomFormeLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.GroupBoxCentre.SuspendLayout();
            this.SuspendLayout();
            // 
            // CBTypeCamera
            // 
            this.CBTypeCamera.FormattingEnabled = true;
            this.CBTypeCamera.Items.AddRange(new object[] {
            "Orthogonale",
            "Perspective"});
            this.CBTypeCamera.Location = new System.Drawing.Point(12, 35);
            this.CBTypeCamera.Name = "CBTypeCamera";
            this.CBTypeCamera.Size = new System.Drawing.Size(121, 21);
            this.CBTypeCamera.TabIndex = 5;
            this.CBTypeCamera.Text = "Type de Camera";
            this.CBTypeCamera.SelectedIndexChanged += new System.EventHandler(this.CBTypeCamera_SelectedIndexChanged);
            this.CBTypeCamera.SelectedValueChanged += new System.EventHandler(this.CBTypeCamera_SelectedIndexChanged);
            // 
            // buttonAnnuler
            // 
            this.buttonAnnuler.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonAnnuler.Location = new System.Drawing.Point(295, 241);
            this.buttonAnnuler.Name = "buttonAnnuler";
            this.buttonAnnuler.Size = new System.Drawing.Size(75, 23);
            this.buttonAnnuler.TabIndex = 8;
            this.buttonAnnuler.Text = "Annuler";
            this.buttonAnnuler.UseVisualStyleBackColor = true;
            // 
            // buttonValider
            // 
            this.buttonValider.Location = new System.Drawing.Point(391, 241);
            this.buttonValider.Name = "buttonValider";
            this.buttonValider.Size = new System.Drawing.Size(75, 23);
            this.buttonValider.TabIndex = 9;
            this.buttonValider.Text = "Valider";
            this.buttonValider.UseVisualStyleBackColor = true;
            this.buttonValider.Click += new System.EventHandler(this.buttonValider_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tBVecteurDirectionZ);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tBVecteurDirectionY);
            this.groupBox1.Controls.Add(this.tBVecteurDirectionX);
            this.groupBox1.Location = new System.Drawing.Point(12, 163);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(175, 95);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vecteur direction";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "X :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Y :";
            // 
            // tBVecteurDirectionZ
            // 
            this.tBVecteurDirectionZ.Location = new System.Drawing.Point(110, 64);
            this.tBVecteurDirectionZ.Name = "tBVecteurDirectionZ";
            this.tBVecteurDirectionZ.Size = new System.Drawing.Size(59, 20);
            this.tBVecteurDirectionZ.TabIndex = 7;
            this.tBVecteurDirectionZ.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Z :";
            // 
            // tBVecteurDirectionY
            // 
            this.tBVecteurDirectionY.Location = new System.Drawing.Point(110, 41);
            this.tBVecteurDirectionY.Name = "tBVecteurDirectionY";
            this.tBVecteurDirectionY.Size = new System.Drawing.Size(59, 20);
            this.tBVecteurDirectionY.TabIndex = 6;
            this.tBVecteurDirectionY.Text = "0";
            // 
            // tBVecteurDirectionX
            // 
            this.tBVecteurDirectionX.Location = new System.Drawing.Point(110, 19);
            this.tBVecteurDirectionX.Name = "tBVecteurDirectionX";
            this.tBVecteurDirectionX.Size = new System.Drawing.Size(59, 20);
            this.tBVecteurDirectionX.TabIndex = 5;
            this.tBVecteurDirectionX.Text = "0";
            // 
            // GroupBoxCentre
            // 
            this.GroupBoxCentre.Controls.Add(this.label4);
            this.GroupBoxCentre.Controls.Add(this.label5);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionZ);
            this.GroupBoxCentre.Controls.Add(this.label6);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionY);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionX);
            this.GroupBoxCentre.Location = new System.Drawing.Point(12, 62);
            this.GroupBoxCentre.Name = "GroupBoxCentre";
            this.GroupBoxCentre.Size = new System.Drawing.Size(175, 95);
            this.GroupBoxCentre.TabIndex = 20;
            this.GroupBoxCentre.TabStop = false;
            this.GroupBoxCentre.Text = "Position de la caméra";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(84, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "X :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(84, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Y :";
            // 
            // textBoxPositionZ
            // 
            this.textBoxPositionZ.Location = new System.Drawing.Point(110, 64);
            this.textBoxPositionZ.Name = "textBoxPositionZ";
            this.textBoxPositionZ.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionZ.TabIndex = 7;
            this.textBoxPositionZ.Text = "-1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(84, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Z :";
            // 
            // textBoxPositionY
            // 
            this.textBoxPositionY.Location = new System.Drawing.Point(110, 41);
            this.textBoxPositionY.Name = "textBoxPositionY";
            this.textBoxPositionY.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionY.TabIndex = 6;
            this.textBoxPositionY.Text = "0";
            // 
            // textBoxPositionX
            // 
            this.textBoxPositionX.Location = new System.Drawing.Point(110, 19);
            this.textBoxPositionX.Name = "textBoxPositionX";
            this.textBoxPositionX.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionX.TabIndex = 5;
            this.textBoxPositionX.Text = "0";
            // 
            // textBoxNomForme
            // 
            this.textBoxNomForme.Location = new System.Drawing.Point(109, 9);
            this.textBoxNomForme.Name = "textBoxNomForme";
            this.textBoxNomForme.Size = new System.Drawing.Size(78, 20);
            this.textBoxNomForme.TabIndex = 23;
            // 
            // NomFormeLabel
            // 
            this.NomFormeLabel.AutoSize = true;
            this.NomFormeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NomFormeLabel.Location = new System.Drawing.Point(9, 12);
            this.NomFormeLabel.Name = "NomFormeLabel";
            this.NomFormeLabel.Size = new System.Drawing.Size(94, 13);
            this.NomFormeLabel.TabIndex = 22;
            this.NomFormeLabel.Text = "Nom de la Caméra";
            // 
            // FormCreateCameras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(476, 270);
            this.Controls.Add(this.textBoxNomForme);
            this.Controls.Add(this.NomFormeLabel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.GroupBoxCentre);
            this.Controls.Add(this.buttonValider);
            this.Controls.Add(this.buttonAnnuler);
            this.Controls.Add(this.CBTypeCamera);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FormCreateCameras";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Nouvelle Caméra";
            this.Load += new System.EventHandler(this.UCCameras_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.GroupBoxCentre.ResumeLayout(false);
            this.GroupBoxCentre.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CBTypeCamera;
        private System.Windows.Forms.Button buttonAnnuler;
        private System.Windows.Forms.Button buttonValider;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBVecteurDirectionZ;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBVecteurDirectionY;
        private System.Windows.Forms.TextBox tBVecteurDirectionX;
        private System.Windows.Forms.GroupBox GroupBoxCentre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxPositionZ;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxPositionY;
        private System.Windows.Forms.TextBox textBoxPositionX;
        private System.Windows.Forms.TextBox textBoxNomForme;
        private System.Windows.Forms.Label NomFormeLabel;

    }
}
