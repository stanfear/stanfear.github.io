﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Projet_Objets_3D.Utilitaires;

namespace Projet_Objets_3D.UI
{
    public partial class UCCylindre : UserControl
    {

        public UCCylindre()
        {
            InitializeComponent();
        }

        internal UCCylindre(Formes.Cylindre cylindre) : this()
        {
            this.Rayon = cylindre.Rayon;
            this.VecteurHauteur = cylindre.VecteurHauteur;
            this.PointCentre = cylindre.Origine;

        }

        
        public double Rayon 
        {
            get 
            {
                return double.Parse(textBoxRayonCylindre.Text);
            }
            set 
            {
                textBoxRayonCylindre.Text = value.ToString();
            }
        }

        internal Point3D PointCentre 
        {
            get
            {
                return new Point3D(double.Parse(textBoxPositionX.Text), double.Parse(textBoxPositionY.Text), double.Parse(textBoxPositionZ.Text)); 
            }
            set
            { 
                textBoxPositionX.Text = value.X.ToString();
                textBoxPositionY.Text = value.Y.ToString();
                textBoxPositionZ.Text = value.Z.ToString();
            }
        }   
        
        internal Vector3 VecteurHauteur 
        {
            get
            {
                return new Vector3(double.Parse(tBVecteurHauteurX.Text), double.Parse(tBVecteurHauteurY.Text), double.Parse(tBVecteurHauteurZ.Text)); 
            }
            set
            {
                tBVecteurHauteurX.Text = value.X.ToString();
                tBVecteurHauteurY.Text = value.Y.ToString();
                tBVecteurHauteurZ.Text = value.Z.ToString();
            }
        }


        public bool ValideData
        { 
            get
            {          
                double temp;
                return 
                    double.TryParse(textBoxPositionX.Text, out temp) && 
                    double.TryParse(textBoxPositionY.Text, out temp) && 
                    double.TryParse(textBoxPositionZ.Text, out temp) &&
                    double.TryParse(tBVecteurHauteurX.Text, out temp) && 
                    double.TryParse(tBVecteurHauteurY.Text, out temp) && 
                    double.TryParse(tBVecteurHauteurZ.Text, out temp) &&
                    double.TryParse(textBoxRayonCylindre.Text, out temp);
            }
        }
    }
}
