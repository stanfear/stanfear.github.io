﻿using Projet_Objets_3D.Cameras;
using Projet_Objets_3D.Formes;
using Projet_Objets_3D.Utilitaires;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet_Objets_3D.UI
{
    public partial class FormViewSimulation : Form, IProgressTracker
    {
        private Camera _camera;
        int nbprocess;
        int actprocess;

        public FormViewSimulation()
        {
            InitializeComponent();
        }

        internal void setCamera(Camera c)
        {
            this._camera = c;
        }

        private void toolStripContainer1_ContentPanel_Load(object sender, EventArgs e)
        {
            if (_camera == null)
                this.Close();


            Task t = Task.Factory.StartNew(() =>
            {

                Image bmp = _camera.Draw(new Size(400,400), this);

                bmp.Save("test.png");
                this.BeginInvoke(
                        new Action(() =>
                        {
                            this.toolStripContainer1.ContentPanel.BackgroundImage = bmp;
                            this.UseWaitCursor = false;
                        }
                    ));

            });

             

        }



        public int MaxValue
        {
            get
            {
                return toolStripProgressBar1.Maximum;
            }
            set
            {
                toolStripProgressBar1.Maximum = value;
            }
        }

        public int MinValue
        {
            get
            {
                return toolStripProgressBar1.Minimum;
            }
            set
            {
                toolStripProgressBar1.Minimum = value;
            }
        }

        public int CurentValue
        {
            get
            {
                return toolStripProgressBar1.Value;
            }
            set
            {
                toolStripProgressBar1.Value = value;
            }
        }

        public void report(int n)
        {
            this.BeginInvoke(
                new Action(() =>
                {
                    this.toolStripProgressBar1.Step = n;
                    this.toolStripProgressBar1.PerformStep();
                }
            ));
        }


        public void init()
        {
            this.toolStripProgressBar1.Enabled = true;
            this.toolStripProgressBar1.Style = ProgressBarStyle.Continuous;
            this.toolStripProgressBar1.Minimum = 0;
            this.toolStripProgressBar1.Maximum = this.toolStripProgressBar1.Size.Width;
            this.toolStripProgressBar1.Value = MinValue;
        }

        public void init(int p)
        {
            nbprocess = p;
            this.BeginInvoke(
                new Action(() =>
                {
                    actprocess = 1;
                    this.toolStripLabel1.Text = actprocess + " / " + nbprocess;
                }
            ));
        }

        public void NextStep()
        {
            this.BeginInvoke(
                new Action(() =>
                {
                    actprocess++;
                    this.toolStripLabel1.Text = actprocess + " / " + nbprocess;
                    this.toolStripProgressBar1.Value = MinValue;
                }
            ));
        }


        public void SetUndefined()
        {
            this.BeginInvoke(
                new Action(() =>
                {
                    this.toolStripProgressBar1.Style = ProgressBarStyle.Marquee;
                }
            ));
        }

        public void SetDefined()
        {
            this.BeginInvoke(
                new Action(() =>
                {
                    this.toolStripProgressBar1.Style = ProgressBarStyle.Continuous;
                }
            ));
        }

        public void reportFinish()
        {            
            this.BeginInvoke(
                new Action(() =>
                {
                    this.toolStripProgressBar1.Style = ProgressBarStyle.Continuous;
                    this.toolStripProgressBar1.Value = 0;
                    this.toolStripProgressBar1.Enabled = false;
                    this.toolStripLabel1.Text = "fini";
                }));

            
        }
    }
}
