﻿namespace Projet_Objets_3D.UI
{
    partial class UCSphere
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPositionX = new System.Windows.Forms.Label();
            this.labelPositionY = new System.Windows.Forms.Label();
            this.labelPositionZ = new System.Windows.Forms.Label();
            this.labelRayonSphere = new System.Windows.Forms.Label();
            this.textBoxPositionX = new System.Windows.Forms.TextBox();
            this.textBoxPositionY = new System.Windows.Forms.TextBox();
            this.textBoxPositionZ = new System.Windows.Forms.TextBox();
            this.textBoxRayonSphere = new System.Windows.Forms.TextBox();
            this.GroupBoxCentre = new System.Windows.Forms.GroupBox();
            this.GroupBoxCentre.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelPositionX
            // 
            this.labelPositionX.AutoSize = true;
            this.labelPositionX.Location = new System.Drawing.Point(84, 22);
            this.labelPositionX.Name = "labelPositionX";
            this.labelPositionX.Size = new System.Drawing.Size(20, 13);
            this.labelPositionX.TabIndex = 1;
            this.labelPositionX.Text = "X :";
            // 
            // labelPositionY
            // 
            this.labelPositionY.AutoSize = true;
            this.labelPositionY.Location = new System.Drawing.Point(84, 44);
            this.labelPositionY.Name = "labelPositionY";
            this.labelPositionY.Size = new System.Drawing.Size(20, 13);
            this.labelPositionY.TabIndex = 2;
            this.labelPositionY.Text = "Y :";
            // 
            // labelPositionZ
            // 
            this.labelPositionZ.AutoSize = true;
            this.labelPositionZ.Location = new System.Drawing.Point(84, 67);
            this.labelPositionZ.Name = "labelPositionZ";
            this.labelPositionZ.Size = new System.Drawing.Size(20, 13);
            this.labelPositionZ.TabIndex = 3;
            this.labelPositionZ.Text = "Z :";
            // 
            // labelRayonSphere
            // 
            this.labelRayonSphere.AutoSize = true;
            this.labelRayonSphere.Location = new System.Drawing.Point(153, 104);
            this.labelRayonSphere.Name = "labelRayonSphere";
            this.labelRayonSphere.Size = new System.Drawing.Size(105, 13);
            this.labelRayonSphere.TabIndex = 4;
            this.labelRayonSphere.Text = "Rayon de la sphère :";
            // 
            // textBoxPositionX
            // 
            this.textBoxPositionX.Location = new System.Drawing.Point(110, 19);
            this.textBoxPositionX.Name = "textBoxPositionX";
            this.textBoxPositionX.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionX.TabIndex = 5;
            this.textBoxPositionX.Text = "0";
            // 
            // textBoxPositionY
            // 
            this.textBoxPositionY.Location = new System.Drawing.Point(110, 41);
            this.textBoxPositionY.Name = "textBoxPositionY";
            this.textBoxPositionY.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionY.TabIndex = 6;
            this.textBoxPositionY.Text = "0";
            // 
            // textBoxPositionZ
            // 
            this.textBoxPositionZ.Location = new System.Drawing.Point(110, 64);
            this.textBoxPositionZ.Name = "textBoxPositionZ";
            this.textBoxPositionZ.Size = new System.Drawing.Size(59, 20);
            this.textBoxPositionZ.TabIndex = 7;
            this.textBoxPositionZ.Text = "0";
            // 
            // textBoxRayonSphere
            // 
            this.textBoxRayonSphere.Location = new System.Drawing.Point(258, 101);
            this.textBoxRayonSphere.Name = "textBoxRayonSphere";
            this.textBoxRayonSphere.Size = new System.Drawing.Size(59, 20);
            this.textBoxRayonSphere.TabIndex = 8;
            this.textBoxRayonSphere.Text = "0,3";
            // 
            // GroupBoxCentre
            // 
            this.GroupBoxCentre.Controls.Add(this.labelPositionX);
            this.GroupBoxCentre.Controls.Add(this.labelPositionY);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionZ);
            this.GroupBoxCentre.Controls.Add(this.labelPositionZ);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionY);
            this.GroupBoxCentre.Controls.Add(this.textBoxPositionX);
            this.GroupBoxCentre.Location = new System.Drawing.Point(148, 3);
            this.GroupBoxCentre.Name = "GroupBoxCentre";
            this.GroupBoxCentre.Size = new System.Drawing.Size(175, 95);
            this.GroupBoxCentre.TabIndex = 9;
            this.GroupBoxCentre.TabStop = false;
            this.GroupBoxCentre.Text = "Centre de la sphère";
            // 
            // UCSphere
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Controls.Add(this.GroupBoxCentre);
            this.Controls.Add(this.textBoxRayonSphere);
            this.Controls.Add(this.labelRayonSphere);
            this.Name = "UCSphere";
            this.Size = new System.Drawing.Size(326, 291);
            this.GroupBoxCentre.ResumeLayout(false);
            this.GroupBoxCentre.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPositionX;
        private System.Windows.Forms.Label labelPositionY;
        private System.Windows.Forms.Label labelPositionZ;
        private System.Windows.Forms.Label labelRayonSphere;
        private System.Windows.Forms.TextBox textBoxPositionX;
        private System.Windows.Forms.TextBox textBoxPositionY;
        private System.Windows.Forms.TextBox textBoxPositionZ;
        private System.Windows.Forms.TextBox textBoxRayonSphere;
        private System.Windows.Forms.GroupBox GroupBoxCentre;
    }
}
