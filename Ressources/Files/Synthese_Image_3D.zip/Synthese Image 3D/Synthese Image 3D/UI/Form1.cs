﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Projet_Objets_3D.Utilitaires;
using Projet_Objets_3D.Formes;
using System.Threading;
using System.Threading.Tasks;
using Projet_Objets_3D.Cameras;
using Projet_Objets_3D.Lumieres;

namespace Projet_Objets_3D.UI
{
    public partial class Form1 : Form
    {

        private Image bmp;
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            //double Scale = 0.5;
            //Cylindre cy = new Cylindre(new Point3D(-0.75, 0, 0), new Vector3(0.1, 0.1, -0.1), new Vector3(0, 0, 0), 0.2);

            Simulation s = new Simulation(new Size3D(5 + 0.02, 5 + 0.02, 5 + 0.02)); // -> de -1 à 1 dans tous les sens
            s.AjouterForme(new Sphere(new Point3D(-0.35, -0.40, 0.5), 0.2));
            s.AjouterForme(new Sphere(new Point3D(0, 0, 0), 0.5));
            //s.AjouterForme(new Sphere(new Point3D(600, 555, 400), 100));
            s.AjouterForme(new Triangle(new Point3D(-1, 1, 0), new Point3D(0, 1, 0), new Point3D(0, 1, 2)));
            s.AjouterForme(new Triangle(new Point3D(-1, 1, 0), new Point3D(-1, 1, 2), new Point3D(0, 1, 2)));
            //s.AjouterForme(new Pave(new Point3D(500, 100, 200), new Vector3(-100, -80, 200), new Vector3(100, -80, 150), new Vector3(-50, 200, 50)));
            //s.AjouterForme(cy);
            //s.AjouterLumiere(new Lumiere(new Point3D(750, 750, 999), Color.White));
            //s.AjouterLumiere(new Lumiere(new Point3D(50, 50, 999), Color.White));
            s.AjouterLumiere(new PonctualLightSource(new Point3D(0, 0, -0.999)));

            // avant de permettre de placer la camera, verifier qu'elle est dans la simulation
            Point3D positionCamera = new Point3D(-1, 1, -2);

            //s.AjouterCamera(new CameraPerspective(positionCamera, new Vector3(0.2,-0.4,1)));
            s.AjouterCamera(new CameraOrthographique(positionCamera, new Vector3(0.2, -0.1, 1), 3.5, 3.5));


            Task t = Task.Factory.StartNew(() =>
            {
                /*IProgressTracker progressTracker = new ProgressReport();
                */
                IProgressTracker progressTracker = new DumbTracker();


                var watch = Stopwatch.StartNew();
                bmp = s.LCameras[0].Draw(new Size(400, 400), progressTracker);
                bmp.Save("test.png");
                this.BeginInvoke(
                        new Action(() =>
                        {
                            this.BackgroundImage = bmp;
                            this.UseWaitCursor = false;
                        }
                    ));
                MessageBox.Show(watch.Elapsed.ToString());
                
                /*
                double phi = 3.14;
                while (true)
                {
                    progressTracker = new DumbTracker();
                    progressTracker.init();
                    Point3D Lumiere = s.LLumieres[0].Location;
                    Point3D nouvelleLocation = new Point3D(300 + 500 * Math.Sin(phi), 500 + 1000 * Math.Cos(phi), 500 + 499 * Math.Sin(phi));
                    s.LLumieres[0].Move(nouvelleLocation  - Lumiere);
                    bmp = s.DrawWithLighting(Scale, progressTracker);
                    this.BeginInvoke(
                        new Action(() =>
                        {
                            this.BackgroundImage = bmp;
                            this.UseWaitCursor = false;
                        }
                    ));
                    phi += 0.1;
                }*/
                 
            });
        }

        private void actualize(Image SimulPic)
        {
        }
    }
}
