﻿namespace Projet_Objets_3D.UI
{
    partial class FormCreateLumieres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonColor = new System.Windows.Forms.Button();
            this.labelPuissance = new System.Windows.Forms.Label();
            this.NumUDPuissance = new System.Windows.Forms.NumericUpDown();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.GroupBoxFormeConstruction = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBoxNomForme = new System.Windows.Forms.TextBox();
            this.NomFormeLabel = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.buttonOK = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NumUDPuissance)).BeginInit();
            this.GroupBoxFormeConstruction.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonColor
            // 
            this.buttonColor.BackColor = System.Drawing.Color.White;
            this.buttonColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonColor.Location = new System.Drawing.Point(261, 29);
            this.buttonColor.Name = "buttonColor";
            this.buttonColor.Size = new System.Drawing.Size(54, 27);
            this.buttonColor.TabIndex = 7;
            this.buttonColor.UseVisualStyleBackColor = false;
            this.buttonColor.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelPuissance
            // 
            this.labelPuissance.AutoSize = true;
            this.labelPuissance.Location = new System.Drawing.Point(122, 68);
            this.labelPuissance.Name = "labelPuissance";
            this.labelPuissance.Size = new System.Drawing.Size(129, 13);
            this.labelPuissance.TabIndex = 3;
            this.labelPuissance.Text = "Puissance lumineuse (%) :";
            // 
            // NumUDPuissance
            // 
            this.NumUDPuissance.Enabled = false;
            this.NumUDPuissance.Location = new System.Drawing.Point(261, 66);
            this.NumUDPuissance.Name = "NumUDPuissance";
            this.NumUDPuissance.Size = new System.Drawing.Size(54, 20);
            this.NumUDPuissance.TabIndex = 4;
            this.NumUDPuissance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumUDPuissance.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // GroupBoxFormeConstruction
            // 
            this.GroupBoxFormeConstruction.Controls.Add(this.label1);
            this.GroupBoxFormeConstruction.Controls.Add(this.comboBox1);
            this.GroupBoxFormeConstruction.Controls.Add(this.labelPuissance);
            this.GroupBoxFormeConstruction.Controls.Add(this.NumUDPuissance);
            this.GroupBoxFormeConstruction.Controls.Add(this.buttonColor);
            this.GroupBoxFormeConstruction.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxFormeConstruction.Location = new System.Drawing.Point(9, 31);
            this.GroupBoxFormeConstruction.Name = "GroupBoxFormeConstruction";
            this.GroupBoxFormeConstruction.Size = new System.Drawing.Size(338, 228);
            this.GroupBoxFormeConstruction.TabIndex = 12;
            this.GroupBoxFormeConstruction.TabStop = false;
            this.GroupBoxFormeConstruction.Text = "Type de source :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Couleur de la Source lumineuse :";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Ponctuelle"});
            this.comboBox1.Location = new System.Drawing.Point(92, 0);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(208, 21);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.SelectedValueChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBoxNomForme
            // 
            this.textBoxNomForme.Location = new System.Drawing.Point(159, 6);
            this.textBoxNomForme.Name = "textBoxNomForme";
            this.textBoxNomForme.Size = new System.Drawing.Size(188, 20);
            this.textBoxNomForme.TabIndex = 16;
            // 
            // NomFormeLabel
            // 
            this.NomFormeLabel.AutoSize = true;
            this.NomFormeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NomFormeLabel.Location = new System.Drawing.Point(12, 9);
            this.NomFormeLabel.Name = "NomFormeLabel";
            this.NomFormeLabel.Size = new System.Drawing.Size(141, 13);
            this.NomFormeLabel.TabIndex = 15;
            this.NomFormeLabel.Text = "Nom de la source de lumière";
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(356, 33);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(250, 23);
            this.button2.TabIndex = 14;
            this.button2.Text = "Annuler";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // buttonOK
            // 
            this.buttonOK.Location = new System.Drawing.Point(356, 4);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(250, 23);
            this.buttonOK.TabIndex = 13;
            this.buttonOK.Text = "OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // FormCreateLumieres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(611, 268);
            this.Controls.Add(this.GroupBoxFormeConstruction);
            this.Controls.Add(this.textBoxNomForme);
            this.Controls.Add(this.NomFormeLabel);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.buttonOK);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FormCreateLumieres";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Nouvelle source lumineuse";
            this.Load += new System.EventHandler(this.FormLumieres_Load);
            ((System.ComponentModel.ISupportInitialize)(this.NumUDPuissance)).EndInit();
            this.GroupBoxFormeConstruction.ResumeLayout(false);
            this.GroupBoxFormeConstruction.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPuissance;
        private System.Windows.Forms.NumericUpDown NumUDPuissance;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button buttonColor;
        private System.Windows.Forms.GroupBox GroupBoxFormeConstruction;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBoxNomForme;
        private System.Windows.Forms.Label NomFormeLabel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button buttonOK;
    }
}