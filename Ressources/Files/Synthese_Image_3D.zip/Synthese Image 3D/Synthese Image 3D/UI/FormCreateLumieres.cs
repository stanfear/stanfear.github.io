﻿using Projet_Objets_3D.Lumieres;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Projet_Objets_3D.UI
{
    public partial class FormCreateLumieres : Form
    {
        private UserControl localUC;
        private Lumiere sourceLumineuse;


        internal Lumiere NewLightSource
        {
            get { return sourceLumineuse; }
            set { sourceLumineuse = value; }
        }


        public FormCreateLumieres()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            buttonColor.BackColor = colorDialog1.Color;
        }

        internal void setSelectedSourceType(string s)
        {
            comboBox1.SelectedItem = s;
        }

        private void FormLumieres_Load(object sender, EventArgs e)
        {

            if (comboBox1.SelectedItem == null)
                comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (sourceLumineuse == null)
            {
                GroupBoxFormeConstruction.Controls.Remove(localUC);
                UserControl uc;
                switch (comboBox1.SelectedItem.ToString())
                {
                    case "Ponctuelle":
                        textBoxNomForme.Text = "Source Ponctuelle";
                        uc = new UCPonctuelLightSource();
                        break;
                    default:
                        uc = new UCPonctuelLightSource();
                        break;
                }
                uc.Location = new Point(7, 94);
                localUC = uc;
                GroupBoxFormeConstruction.Controls.Add(uc);
            }
            else
            {
                comboBox1.Enabled = false;
                textBoxNomForme.Text = sourceLumineuse.Nom;
                buttonColor.BackColor = sourceLumineuse.Color;

                UserControl uc;
                switch (sourceLumineuse.GetType().Name)
                {
                    case "PonctualLightSource":
                        uc = new UCPonctuelLightSource(sourceLumineuse as PonctualLightSource);
                        comboBox1.SelectedItem = "Ponctuelle";
                        break;
                    default:
                        uc = new UCPonctuelLightSource();
                        sourceLumineuse = null;
                        break;
                }
                uc.Location = new Point(7, 94);
                localUC = uc;
                GroupBoxFormeConstruction.Controls.Add(uc);
            }
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedItem.ToString())
            {
                case "Ponctuelle":
                    {
                        UCPonctuelLightSource uc = localUC as UCPonctuelLightSource;
                        if (!uc.ValideData)
                            return;
                        sourceLumineuse = new PonctualLightSource(uc.Position);
                        break;
                    }
                default:
                    break;
            }
            sourceLumineuse.Color = buttonColor.BackColor;
            sourceLumineuse.Nom = textBoxNomForme.Text;
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

    }
}
