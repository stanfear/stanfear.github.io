﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Projet_Objets_3D.Cameras;
using Projet_Objets_3D.Lumieres;
using Projet_Objets_3D.Formes;
using Projet_Objets_3D.Utilitaires;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Projet_Objets_3D.UI
{
    public partial class UCGeneral : UserControl
    {
        private Simulation _simulation;
        private TabPage _parent;

        public UCGeneral()
        {
            InitializeComponent();
        }

        internal void SetSimulation(Simulation simu)
        {
            _simulation = simu;
        }
        internal void SetParent(TabPage tab)
        {
            _parent = tab;
        }

        private void Fenetre_generale_Load(object sender, EventArgs e)
        {
            // avant arriver ici, la simulation a forcément été crée
            if (_simulation == null)
                throw new Exception("Formulaire de gestion de simulation chargé sans simulation !");
        }


        private void UCGeneral_Load(object sender, EventArgs e)
        {
            if (_simulation.LCameras.Count == 0)
            {
                Camera c = new CameraOrthographique(new Utilitaires.Point3D(0, 0, -2), new Utilitaires.Vector3(0, 0, 1));
                c.Nom = "default";
                _simulation.AjouterCamera(c);
            }

            this.Formes.DisplayMember = "Nom";
            this.Cameras.DisplayMember = "Nom";
            this.Sources.DisplayMember = "Nom";

            this.Formes.DataSource = _simulation.LFormes;
            this.Cameras.DataSource = _simulation.LCameras;
            this.Sources.DataSource = _simulation.LLumieres;

            this.Formes.SelectedIndices.Clear();
            this.Cameras.SelectedIndices.Clear();
            this.Sources.SelectedIndices.Clear();
        }

        #region Modifying Formes (add - Edit - Remove)

        private void toolStripSplitButtonAddForme_ButtonClick(object sender, EventArgs e)
        {
            // par défault, on choisis de selectionner la sphère
            AddForme("Sphère");
        }

        private void toolStripMenuItemAddSphere_Click(object sender, EventArgs e)
        {
            AddForme("Sphère");
        }

        private void toolStripMenuItemAddCylindre_Click(object sender, EventArgs e)
        {
            AddForme("Cylindre");
        }

        private void AddForme(string s)
        {
            FormCreateForme f = new FormCreateForme();
            f.setSelectedForme(s);
            if(f.ShowDialog() != DialogResult.OK)
                return;
            _simulation.AjouterForme(f.NewForme);

            // rafraichis la liste
            this.Formes.DataSource = null;
            this.Formes.DisplayMember = "Nom";
            this.Formes.DataSource = _simulation.LFormes;
        }

        private void Formes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Formes.SelectedIndices.Count != 1)
                toolStripButtonEditForme.Enabled = false;
            else
                toolStripButtonEditForme.Enabled = true;
            if (Formes.SelectedIndices.Count >= 1)
                toolStripButtonDeleteForme.Enabled = true;
            else
                toolStripButtonDeleteForme.Enabled = false;
        }

        private void groupBoxFormes_Leave(object sender, EventArgs e)
        {
            Formes.SelectedIndices.Clear();
        }

        private void toolStripButtonEditForme_Click(object sender, EventArgs e)
        {
            FormCreateForme f = new FormCreateForme();
            f.NewForme = Formes.SelectedItem as Forme;
            if (f.ShowDialog() != DialogResult.OK)
                return;
            _simulation.LFormes.Remove(Formes.SelectedItem as Forme);
            _simulation.AjouterForme(f.NewForme);
            // rafraichis la liste
            this.Formes.DataSource = null;
            this.Formes.DisplayMember = "Nom";
            this.Formes.DataSource = _simulation.LFormes;
        }

        private void toolStripButtonDeleteForme_Click(object sender, EventArgs e)
        {
            _simulation.LFormes.Remove(Formes.SelectedItem as Forme);
            // rafraichis la liste
            this.Formes.DataSource = null;
            this.Formes.DisplayMember = "Nom";
            this.Formes.DataSource = _simulation.LFormes;
        }
        #endregion

        #region Modifying Lights (add - Edit - Remove)

        private void toolStripSplitButtonAddLightSource_ButtonClick(object sender, EventArgs e)
        {
            AddLight("ponctuel");
        }


        private void toolStripMenuItemAddPonctualLightSource_Click(object sender, EventArgs e)
        {
            AddLight("ponctuel");
        }

        private void toolStripMenuItemAddAmbiantLightSource_Click(object sender, EventArgs e)
        {
            AddLight("Ambiant");
        }

        private void AddLight(string s)
        {
            FormCreateLumieres f = new FormCreateLumieres();
            f.setSelectedSourceType(s);
            if (f.ShowDialog() != DialogResult.OK)
                return;
            f.NewLightSource.setSimulation(_simulation);
            _simulation.AjouterLumiere(f.NewLightSource);


            // rafraichis la liste
            this.Sources.DataSource = null;
            this.Sources.DisplayMember = "Nom";
            this.Sources.DataSource = _simulation.LLumieres;
        }

        private void Sources_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Sources.SelectedIndices.Count != 1)
                toolStripButtonEditLightSource.Enabled = false;
            else
                toolStripButtonEditLightSource.Enabled = true;
            if (Sources.SelectedIndices.Count >= 1)
                toolStripButtonRemoveLightSource.Enabled = true;
            else
                toolStripButtonRemoveLightSource.Enabled = false;
        }

        private void Sources_Leave(object sender, EventArgs e)
        {
            Sources.SelectedIndices.Clear();
        }

        private void toolStripButtonEditLightSource_Click(object sender, EventArgs e)
        {            
            
            FormCreateLumieres f = new FormCreateLumieres();
            f.NewLightSource = Sources.SelectedItem as Lumiere;
            if (f.ShowDialog() != DialogResult.OK)
                return;

            _simulation.LLumieres.Remove(Sources.SelectedItem as Lumiere);
            _simulation.AjouterLumiere(f.NewLightSource);
            // rafraichis la liste
            this.Sources.DataSource = null;
            this.Sources.DisplayMember = "Nom";
            this.Sources.DataSource = _simulation.LLumieres;
        }
        private void toolStripButtonRemoveLightSource_Click(object sender, EventArgs e)
        {
            _simulation.LLumieres.Remove(Sources.SelectedItem as Lumiere);
            // rafraichis la liste
            this.Sources.DataSource = null;
            this.Sources.DisplayMember = "Nom";
            this.Sources.DataSource = _simulation.LLumieres;
        }
        #endregion

        #region Modifying Caméras (add - Edit - Remove)


        private void toolStripSplitButtonAddCamera_ButtonClick(object sender, EventArgs e)
        {
            AddCamera("Orthogonale");
        }

        private void toolStripMenuItemAddPerspectiveCamera_Click(object sender, EventArgs e)
        {
            AddCamera("Perspective");
        }

        private void toolStripMenuItemAddOrthogonaleCaméra_Click(object sender, EventArgs e)
        {
            AddCamera("Orthogonale");
        }

        private void AddCamera(string s)
        {
            FormCreateCameras f = new FormCreateCameras();
            f.setSelectedCameraType(s);
            if (f.ShowDialog() != DialogResult.OK)
                return;
            _simulation.AjouterCamera(f.NewCamera);

            // rafraichis la liste
            this.Cameras.DataSource = null;
            this.Cameras.DisplayMember = "Nom";
            this.Cameras.DataSource = _simulation.LCameras;
        }

        private void Cameras_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Cameras.SelectedIndices.Count != 1)
                toolStripButtonEditCamera.Enabled = false;
            else
                toolStripButtonEditCamera.Enabled = true;
            if (Cameras.SelectedIndices.Count >= 1)
                toolStripButtonRemoveCamera.Enabled = true;
            else
                toolStripButtonRemoveCamera.Enabled = false;
        }

        private void Cameras_Leave(object sender, EventArgs e)
        {
            Sources.SelectedIndices.Clear();
        }
        
        private void toolStripButtonEditCamera_Click(object sender, EventArgs e)
        {
            FormCreateCameras f = new FormCreateCameras();
            f.NewCamera = Cameras.SelectedItem as Camera;
            if (f.ShowDialog() != DialogResult.OK)
                return;
            _simulation.LCameras.Remove(Cameras.SelectedItem as Camera);
            _simulation.AjouterCamera(f.NewCamera);

            // rafraichis la liste
            this.Cameras.DataSource = null;
            this.Cameras.DisplayMember = "Nom";
            this.Cameras.DataSource = _simulation.LCameras;
        }

        private void toolStripButtonRemoveCamera_Click(object sender, EventArgs e)
        {
            _simulation.LCameras.Remove(Cameras.SelectedItem as Camera);
            // rafraichis la liste
            this.Cameras.DataSource = null;
            this.Cameras.DisplayMember = "Nom";
            this.Cameras.DataSource = _simulation.LCameras;
        }
        #endregion

        private void Cameras_DataSourceChanged(object sender, EventArgs e)
        {
            comboBoxCamera.DataSource = null;
            comboBoxCamera.DisplayMember = "Nom";
            comboBoxCamera.DataSource = _simulation.LCameras;
        }

        private void genererSim_Click(object sender, EventArgs e)
        {
            FormViewSimulation f = new FormViewSimulation();
            f.setCamera(comboBoxCamera.SelectedItem as Camera);
            f.Show();
        }


        internal void SetUnsaved()
        {
            this._parent.Text = _simulation.Nom + "*";
        }
        internal void SetSaved()
        {
            this._parent.Text = _simulation.Nom;
        }

        internal Simulation getSimulation()
        {
            return _simulation;
        }
    }
}
