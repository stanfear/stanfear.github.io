﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Projet_Objets_3D.Cameras;
using Projet_Objets_3D.Utilitaires;

namespace Projet_Objets_3D.UI
{
    public partial class FormCreateCameras : Form
    {
        private Camera camera;
        private UserControl ucLocalCam;

        internal Camera NewCamera
        {
            get { return camera; }
            set { camera = value; }
        }

        public FormCreateCameras()
        {
            InitializeComponent();
        }

        private void CBTypeCamera_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (camera == null)
            {
                UserControl ucCam;

                this.Controls.Remove(ucLocalCam);

                switch (CBTypeCamera.SelectedItem.ToString())
                {
                    case "Orthogonale":
                        ucCam = new UCCameraOrthogonale();
                        break;

                    case "Perspective":
                        ucCam = new UCCameraPerspective();
                        break;

                    default:
                        ucCam = new UCCameraOrthogonale();
                        break;
                }
                ucLocalCam = ucCam;
                ucCam.Location = new Point(282, 52);
                this.Controls.Add(ucCam);
            }
            else
            {
                CBTypeCamera.Enabled = false;

                this.Position = camera.Position;
                this.Direction = camera.LookDirection;
                this.textBoxNomForme.Text = camera.Nom;
                UserControl ucCam;
                switch (camera.GetType().Name)
                {
                    case "CameraOrthographique":
                        ucCam = new UCCameraOrthogonale(camera as CameraOrthographique);
                        CBTypeCamera.SelectedItem = "Orthogonale";
                        break;
                    case "CameraPerspective":
                        ucCam = new UCCameraPerspective(camera as CameraPerspective);
                        CBTypeCamera.SelectedItem = "Perspective";
                        break;
                    default:
                        ucCam = new UCCameraOrthogonale();
                        camera = null;
                        break;
                }                   
                ucLocalCam = ucCam;
                ucCam.Location = new Point(282, 52);
                this.Controls.Add(ucCam);
            }





        }
        
        private void buttonValider_Click(object sender, EventArgs e)
        {
            switch (CBTypeCamera.SelectedItem.ToString())
            {
                case "Orthogonale":
                    {
                        UCCameraOrthogonale uc = ucLocalCam as UCCameraOrthogonale;
                        if (!uc.ValideData && this.ValideData)
                            return;
                        camera = new CameraOrthographique(this.Position, this.Direction, uc.FieldViewWidth, uc.FieldViewHeight);
                        break;
                    }
                case "Perspective":
                    {
                        UCCameraPerspective uc = ucLocalCam as UCCameraPerspective;
                        if (!uc.ValideData && this.ValideData)
                            return;
                        camera = new CameraPerspective(this.Position, this.Direction, uc.FieldOfViewX, uc.FieldOfViewY);
                        break;
                    }
                //case "Triangle":
                //    break;
                default:
                    break;
            }
            camera.Nom = textBoxNomForme.Text;
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void UCCameras_Load(object sender, EventArgs e)
        {
            if (CBTypeCamera.SelectedItem == null)
                CBTypeCamera.SelectedIndex = 0;
        }

        internal void setSelectedCameraType(string s)
        {
            CBTypeCamera.SelectedItem = s;
        }

        internal Point3D Position
        {
            get
            {
                return new Point3D(double.Parse(textBoxPositionX.Text), double.Parse(textBoxPositionY.Text), double.Parse(textBoxPositionZ.Text));
            }
            set
            {
                textBoxPositionX.Text = value.X.ToString();
                textBoxPositionY.Text = value.Y.ToString();
                textBoxPositionZ.Text = value.Z.ToString();
            }
        }

        internal Vector3 Direction
        {
            get
            {
                return new Vector3(double.Parse(tBVecteurDirectionX.Text), double.Parse(tBVecteurDirectionY.Text), double.Parse(tBVecteurDirectionZ.Text));
            }
            set
            {
                tBVecteurDirectionX.Text = value.X.ToString();
                tBVecteurDirectionY.Text = value.Y.ToString();
                tBVecteurDirectionZ.Text = value.Z.ToString();
            }
        }

        public bool ValideData
        {
            get
            {
                double temp;
                return
                    double.TryParse(textBoxPositionX.Text, out temp) &&
                    double.TryParse(textBoxPositionY.Text, out temp) &&
                    double.TryParse(textBoxPositionZ.Text, out temp) &&
                    double.TryParse(tBVecteurDirectionX.Text, out temp) &&
                    double.TryParse(tBVecteurDirectionY.Text, out temp) &&
                    double.TryParse(tBVecteurDirectionZ.Text, out temp);
            }
        }
    }
}
