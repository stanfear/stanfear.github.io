﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Projet_Objets_3D.Cameras;

namespace Projet_Objets_3D.UI
{
    public partial class UCCameraOrthogonale : UserControl
    {
        public UCCameraOrthogonale()
        {
            InitializeComponent();
        }

        internal UCCameraOrthogonale(CameraOrthographique cameraOrthographique) : this()
        {
            FieldViewHeight = cameraOrthographique.Height;
            FieldViewWidth = cameraOrthographique.Width;

        }

        public double FieldViewWidth
        {
            get
            {
                return double.Parse(textBoxLargeur.Text);
            }
            set
            {
                textBoxLargeur.Text = value.ToString();
            }
        }

        public double FieldViewHeight
        {
            get
            {
                return double.Parse(textBoxHauteur.Text);
            }
            set
            {
                textBoxHauteur.Text = value.ToString();
            }
        }

        public bool ValideData
        {
            get
            {
                double x, y;

                return double.TryParse(textBoxLargeur.Text, out x) &&
                       double.TryParse(textBoxHauteur.Text, out y) &&
                       x > 0 &&
                       y > 0;
            }
        }
    }
}
