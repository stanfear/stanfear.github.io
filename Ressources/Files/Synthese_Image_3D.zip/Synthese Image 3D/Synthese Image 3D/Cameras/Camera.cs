﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Projet_Objets_3D.Utilitaires;
using System.Drawing;
using Projet_Objets_3D.Formes;
using System.Threading.Tasks;
using System.Drawing.Imaging;

namespace Projet_Objets_3D.Cameras
{
    [Serializable()]
    abstract class Camera
    {
        public Point3D Position { get; set; }
        public Vector3 LookDirection { get; set; }
        public Simulation SimulationPropietaire { get; set; }
        public string Nom { get; set; }

        public Camera()
        {
            Position = new Point3D(0,0,-2);
            LookDirection = new Vector3(0, 0, 1);
        }

        public Camera(Point3D Position, Vector3 LookDirection)
        {
            this.Position = Position;
            this.LookDirection = LookDirection;
        }


        /// <summary>
        /// Permet de d'essiner la simulation dans une image de taille imageOutputSize. informe de la progression par ptracker
        /// </summary>
        /// <param name="imageOutputSize"></param>
        /// <param name="ptracker"></param>
        /// <returns></returns>
        /// <implementation>
        /// pour accelerer la création de l'image, un thread par processeur accessible est créé,
        /// chacun de ces threads doit générer une partie de l'image
        /// </implementation>
        public Image Draw(Size imageOutputSize, IProgressTracker ptracker)
        {
            ptracker.init(2);
            int nbSteps = (ptracker.MaxValue - ptracker.MinValue);
            int invNbSteps = nbSteps != 0 ? nbSteps : 1;
            int deltaSteps = (int)(imageOutputSize.Height * invNbSteps);

            Bitmap bmp = new Bitmap(imageOutputSize.Width, imageOutputSize.Height);

            // préparation des varialbe pour chaques threads
            int ProcessCount = System.Environment.ProcessorCount;

            int tailleATraiterParThread = imageOutputSize.Height / ProcessCount;
            int largeurImage = imageOutputSize.Width;

            // preparation des tableaux que chaque threads devra remplir
            int bytesPerPixels = 3;
            int tailleTable = bytesPerPixels * tailleATraiterParThread * largeurImage;
            byte[][] bmpTableauComplete = new byte[ProcessCount][];

            // creer un tableaux des rayons
            Ray[][,] rayons = this.createRayArray(imageOutputSize, ProcessCount);


            // Remplissage des tableaux
            Parallel.For(0, ProcessCount, (i) =>
            {
                Ray[,] rayonsThread = rayons[i];
                int Yoffset = tailleATraiterParThread * (i);

                byte[] argbValues = new byte[tailleTable];
                bmpTableauComplete[i] = argbValues;
                
                for (int ytab = 0; ytab < tailleATraiterParThread; ytab++)
                {
                    // calcul de la composante Y du vecteur direction
                    // calcul de la première partie de la composante Z
                    for (int xtab = 0; xtab < largeurImage; xtab++)
                    {
                        // calcul de la composante X du vecteur
                        // finalisation du calcul de la composante Z

                        // récuperer la couleur / intensité à afficher
                        // récuperer le rayon à afficher
                        Ray rayon = rayonsThread[ytab, xtab];
                        double distance;
                        double intensite;
                        Color couleur;

                        SimulationPropietaire.ProcessRay(rayon, out distance, out intensite, out couleur);

                        Color c = Color.FromArgb((int)(couleur.R * intensite), (int)(couleur.G * intensite), (int)(couleur.B * intensite));

                        argbValues[(xtab + ytab * largeurImage) * bytesPerPixels] = c.B;
                        argbValues[(xtab + ytab * largeurImage) * bytesPerPixels + 1] = c.G;
                        argbValues[(xtab + ytab * largeurImage) * bytesPerPixels + 2] = c.R;
                    }
                    if (ytab % deltaSteps == 0)
                    {
                        lock (ptracker)
                        {
                            ptracker.report(1);
                        }
                    }

                }
            });

            ptracker.NextStep();
            ptracker.SetUndefined();

            // construction de l'image à partir des tableaux remplis précédement
            // on n'utilise pas setpixel car la fonction est lourde, on copie plutôt les couleurs en tant que triplets de bytes
            PixelFormat pxf = PixelFormat.Format24bppRgb;
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            BitmapData bmpData = bmp.LockBits(rect, ImageLockMode.ReadWrite, pxf);

            IntPtr ptr = bmpData.Scan0;
            int nbrbytes = bmpData.Stride * bmp.Height;

            // fusion des tableaux
            byte[] bmpRaw = new byte[nbrbytes];
            System.Runtime.InteropServices.Marshal.Copy(ptr, bmpRaw, 0, nbrbytes);

            for (int i = 0; i < ProcessCount; i++)
                Array.Copy(bmpTableauComplete[i], 0, bmpRaw, i * tailleTable, tailleTable);

            System.Runtime.InteropServices.Marshal.Copy(bmpRaw, 0, ptr, nbrbytes);
            bmp.UnlockBits(bmpData);

            ptracker.reportFinish();
            return bmp;
        }


        /// <summary>
        /// crée un tableau contenant les rayons nécessaires à la création de l'image
        /// </summary>
        /// <param name="imageOutputSize">La taille de l'image à générer (-> le nombre de rayons à créer)</param>
        /// <param name="ProcessCount">Le nombre de processeurs à disposition (-> le nombre de tableau de tableaux à creer)</param>
        /// <returns></returns>
        protected abstract Ray[][,] createRayArray(Size imageOutputSize, int ProcessCount);






        /*public Image DrawWithLighting(double scale, IProgressTracker ptracker)
        {
            CalculColor cc = (x, y) =>
            {
                Forme f = GetFormeInFront(x, y);
                return f.CalculLuminosite(x, y, LLumiere);
            };
            return Draw(scale, ptracker, cc);
        }
        public Image DrawDepthMap(double scale, IProgressTracker ptracker)
        {
            CalculColor cc = (x, y) =>
            {
                Forme f = GetFormeInFront(x, y);
                int intensite = (int)(f.CalculProfondeur(x, y) * 255 / 1000);
                Color c;
                if (intensite == 255)
                    c = Color.Fuchsia;
                else
                    c = Color.FromArgb(intensite, intensite, intensite);
                return c;
            };
            return Draw(scale, ptracker, cc);
        }

        private delegate Color CalculColor(double x, double y);

        /// <summary>
        /// Crée l'image de la simulation en utilisant une fonction de type 
        /// </summary>
        /// <param name="scale">L'echelle à laquelle dessiner l'image</param>
        /// <param name="calculCouleur">Le traitement a effectuer pour connaitre la couleur en un point (x,y)</param>
        /// <returns>Renvoie la modelisation de la simulation</returns>
        private Image Draw(double scale, IProgressTracker ptracker, CalculColor cc)
        {
            ptracker.init(2);

            int delta = (ptracker.MaxValue - ptracker.MinValue);
            int d = (int)((tailleSimul.Width * scale) / delta);
            Bitmap bmp = new Bitmap((int)(scale * TailleSimulation.Width), (int)(scale * TailleSimulation.Height));

            int ProcessCount = System.Environment.ProcessorCount;
            int tailleATraiter = bmp.Size.Height / ProcessCount;
            int largeurImage = bmp.Size.Width;

            int bytesPerPixels = 3;

            int tailleTable = bytesPerPixels * tailleATraiter * largeurImage;

            byte[][] bmpTableauComplete = new byte[ProcessCount][];

            Parallel.For(0, ProcessCount, (i) =>
            {
                int Yoffset = tailleATraiter * (i);

                byte[] argbValues = new byte[tailleTable];
                bmpTableauComplete[i] = argbValues;

                for (int ytab = 0; ytab < tailleATraiter; ytab++)
                {
                    double ysimu = (double)(ytab + Yoffset) / scale;
                    for (int xtab = 0; xtab < largeurImage; xtab++)
                    {
                        Color c = cc((double)xtab / scale, ysimu);
                        argbValues[(xtab + ytab * largeurImage) * bytesPerPixels] = c.R;
                        argbValues[(xtab + ytab * largeurImage) * bytesPerPixels + 1] = c.G;
                        argbValues[(xtab + ytab * largeurImage) * bytesPerPixels + 2] = c.B;
                    }
                    if (ytab % d == 0)
                    {
                        lock (ptracker)
                        {
                            ptracker.report(1);
                        }
                    }

                }
            });

            ptracker.NextStep();
            ptracker.SetUndefined();

            PixelFormat pxf = PixelFormat.Format24bppRgb;
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            BitmapData bmpData = bmp.LockBits(rect, ImageLockMode.ReadWrite, pxf);

            IntPtr ptr = bmpData.Scan0;
            int nbrbytes = bmpData.Stride * bmp.Height;


            // fusion des tableaux
            byte[] bmpRaw = new byte[nbrbytes];
            System.Runtime.InteropServices.Marshal.Copy(ptr, bmpRaw, 0, nbrbytes);

            for (int i = 0; i < ProcessCount; i++)
                Array.Copy(bmpTableauComplete[i], 0, bmpRaw, i * tailleTable, tailleTable);

            System.Runtime.InteropServices.Marshal.Copy(bmpRaw, 0, ptr, nbrbytes);
            bmp.UnlockBits(bmpData);

            return bmp;
        }*/

        internal void SetSimulation(Simulation simulation)
        {
            SimulationPropietaire = simulation;
        }

    }
}
