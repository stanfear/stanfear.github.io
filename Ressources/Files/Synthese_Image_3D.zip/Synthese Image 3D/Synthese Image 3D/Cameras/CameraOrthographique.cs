﻿using Projet_Objets_3D.Utilitaires;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Projet_Objets_3D.Cameras
{
    [Serializable()]
    class CameraOrthographique : Camera
    {

        public double Width { get; set; }
        public double Height { get; set; }

        public CameraOrthographique() : base()
        {
            Width = 1;
            Height = 1;
        }

        public CameraOrthographique(Point3D Position, Vector3 LookDirection)
            : base(Position, LookDirection)
        {
            Width = 1;
            Height = 1;
        }

        public CameraOrthographique(Point3D Position, Vector3 LookDirection, double width, double height)
            : base(Position, LookDirection)
        {
            Width = width;
            Height = height;
        }



        protected override Ray[][,] createRayArray(Size imageOutputSize, int ProcessCount)
        {
            //TODO : verifier que les rayons créés sont corrects apparament c'est bon !

            Ray[][,] res = new Ray[ProcessCount][,];


            // calcul du vecteur autour duquel fair la rotation + calcul de l'angle de la rotation
            Matrix3 T;
            Vector3 axis = Vector3.CrossProduct(Vector3.unitZ, LookDirection);
            if (axis != Vector3.Null)
            {
                axis.Normalize();
                double angle = Math.Acos(Vector3.DotProduct(Vector3.unitZ, LookDirection) / Vector3.unitZ.Magnitude / LookDirection.Magnitude);

                // Calcul de la Matrice de rotation
                Matrix3 W = new Matrix3(new double[,] { { 0, -axis.Z, axis.Y }, { axis.Z, 0, -axis.X }, { -axis.Y, axis.X, 0 } });
                T = Matrix3.IdentityMatrix() + Math.Sin(angle) * W + (1 - Math.Cos(angle)) * W * W;
            }
            else
            {
                T = Matrix3.IdentityMatrix();
            }
            Vector3 deltaX = T * new Vector3(Width / imageOutputSize.Width, 0, 0);
            Vector3 deltaY = T * new Vector3(0, Height / imageOutputSize.Height, 0);

            int tailleATraiter = imageOutputSize.Height / ProcessCount;

            for (int i = 0; i < ProcessCount; i++)
            {
                Point3D coinsTraitement = 
                    Position // position de départ
                    + (deltaX * imageOutputSize.Width / 2 *(-1))  // déplacement ves le bord
                    + (deltaY * imageOutputSize.Height/2 *(-1)) // déplacement vers le haut (-> on est dans le coins de l'image)
                    + i*tailleATraiter*deltaY; // déplacement vers le point représentant le coins de la zone à traiter
                Ray[,] resI = new Ray[tailleATraiter, imageOutputSize.Width];
                for(int y = 0; y < tailleATraiter; y++)
                {
                    double PosY = (coinsTraitement + (y * deltaY)).Y;
                    double PosZ = (coinsTraitement + (y * deltaY)).Z;
                    for(int x = 0; x < imageOutputSize.Width; x++)
                    {
                        double PosX = (coinsTraitement + (x * deltaX)).X;
                        resI[y, x] = new Ray(new Point3D(PosX, PosY, PosZ), LookDirection);
                        PosZ += deltaX.Z;
                    }
                }
                res[i] = resI;
            }
            return res;
        }
    }
}
