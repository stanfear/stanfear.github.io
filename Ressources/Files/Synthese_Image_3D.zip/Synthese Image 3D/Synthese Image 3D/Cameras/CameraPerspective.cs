﻿using Projet_Objets_3D.Formes;
using Projet_Objets_3D.Utilitaires;
using System;
using System.Drawing;
using System.Drawing.Imaging;

namespace Projet_Objets_3D.Cameras
{
    [Serializable()]
    class CameraPerspective : Camera
    {
        public double FieldOfViewX { get; set; }
        public double FieldOfViewY { get; set; }


        public CameraPerspective() : base()
        {
            FieldOfViewX = 45;
            FieldOfViewY = 45;
        }

        public CameraPerspective(Point3D Position, Vector3 LookDirection)
            : base(Position, LookDirection)
        {
            FieldOfViewX = 45;
            FieldOfViewY = 45;
        }

        public CameraPerspective(Point3D Position, Vector3 LookDirection, double fieldOfViewX, double fieldOfViewY)
            : base(Position, LookDirection)
        {
            FieldOfViewX = fieldOfViewX;
            FieldOfViewY = fieldOfViewY;
        }

        protected override Ray[][,] createRayArray(Size imageOutputSize, int ProcessCount)
        {
            //TODO : verifier que les rayons créés sont corrects
            
            Ray[][,] res = new Ray[ProcessCount][,];

            int tailleATraiter = imageOutputSize.Height / ProcessCount;
            double FieldOfViewXRadian = FieldOfViewX / 180 * Math.PI;
            double FieldOfViewYRadian = FieldOfViewY / 180 * Math.PI;

            double deltaX = (FieldOfViewXRadian / imageOutputSize.Width);
            double deltaY = (FieldOfViewYRadian / imageOutputSize.Height);

            for (int i = 0; i < ProcessCount; i++)
            {

                Ray[,] resI = new Ray[tailleATraiter, imageOutputSize.Width];
                for (int y = 0; y < tailleATraiter; y++)
                {
                    Vector3 tempY = new Vector3(LookDirection);
                    tempY.Pitch(((i * tailleATraiter + y) - imageOutputSize.Height / 2) * deltaY);
                    for (int x = 0; x < imageOutputSize.Width; x++)
                    {
                        Vector3 tempX = new Vector3(tempY);
                        tempX.Yaw((x - imageOutputSize.Width/2) * deltaX);
                        resI[y, x] = new Ray(Position, tempX.Normalize());
                    }
                }
                res[i] = resI;
            }
            return res;
        }

    }
}
