﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Perceptron_1_couche
{
    class Neurone
    {
        private Double[] entrees;
        private Double[] poids;
        private Double seuil;
        private Double sortie;

        public Neurone(double seuil = 1, params Double[] poids)
        {
            this.entrees = new Double[poids.Length];
            this.poids = (double[])poids.Clone();

            this.seuil = seuil;
            sortie = double.NaN;
        }

        public void SetPoid(int i, Double value)
        {
            poids[i] = value;
        }

        public Double GetPoids(int i)
        {
            if (i < poids.Length && i >= 0)
                return poids[i];
            else
                return Double.NaN;
        }
        public void SetEntree(int i, Double value)
        {
            entrees[i] = value;
        }

        public Double Getentree(int i)
        {
            if (i < poids.Length && i >= 0)
                return entrees[i];
            else
                return Double.NaN;
        }

        public void CalculeSortie()
        {
            double somme = 0;
            for (int i = 0; i < poids.Length; i++)
            {
                somme += entrees[i] * poids[i];
            }
            sortie = (somme > seuil) ? 1 : 0;
        }

        public double Sortie
        {
            get { return sortie; }
            set { sortie = value; }
        }


        public int NombreEntree { get { return entrees.Length; } }
    }
}
