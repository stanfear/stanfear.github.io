﻿namespace Perceptron_1_couche
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bLRongeurInit = new System.Windows.Forms.Button();
            this.bNeuronInit = new System.Windows.Forms.Button();
            this.tbwL1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbwL3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbwL2 = new System.Windows.Forms.TextBox();
            this.bApplyAlgo = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tbNBErreurs = new System.Windows.Forms.TextBox();
            this.tbS2 = new System.Windows.Forms.TextBox();
            this.tbS3 = new System.Windows.Forms.TextBox();
            this.tbS1 = new System.Windows.Forms.TextBox();
            this.lVi = new System.Windows.Forms.Label();
            this.lVf = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbNbItterations = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // bLRongeurInit
            // 
            this.bLRongeurInit.Location = new System.Drawing.Point(12, 12);
            this.bLRongeurInit.Name = "bLRongeurInit";
            this.bLRongeurInit.Size = new System.Drawing.Size(113, 44);
            this.bLRongeurInit.TabIndex = 0;
            this.bLRongeurInit.Text = "Initialisation de la liste de rongeurs";
            this.bLRongeurInit.UseVisualStyleBackColor = true;
            this.bLRongeurInit.Click += new System.EventHandler(this.button1_Click);
            // 
            // bNeuronInit
            // 
            this.bNeuronInit.Location = new System.Drawing.Point(131, 12);
            this.bNeuronInit.Name = "bNeuronInit";
            this.bNeuronInit.Size = new System.Drawing.Size(113, 44);
            this.bNeuronInit.TabIndex = 1;
            this.bNeuronInit.Text = "Initialisation du neurone";
            this.bNeuronInit.UseVisualStyleBackColor = true;
            this.bNeuronInit.Click += new System.EventHandler(this.bNeuronInit_Click);
            // 
            // tbwL1
            // 
            this.tbwL1.Location = new System.Drawing.Point(144, 120);
            this.tbwL1.Name = "tbwL1";
            this.tbwL1.Size = new System.Drawing.Size(100, 20);
            this.tbwL1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Poids liaison 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Poids liaison 3";
            // 
            // tbwL3
            // 
            this.tbwL3.Location = new System.Drawing.Point(144, 172);
            this.tbwL3.Name = "tbwL3";
            this.tbwL3.Size = new System.Drawing.Size(100, 20);
            this.tbwL3.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Poids liaison 2";
            // 
            // tbwL2
            // 
            this.tbwL2.Location = new System.Drawing.Point(144, 146);
            this.tbwL2.Name = "tbwL2";
            this.tbwL2.Size = new System.Drawing.Size(100, 20);
            this.tbwL2.TabIndex = 6;
            // 
            // bApplyAlgo
            // 
            this.bApplyAlgo.Location = new System.Drawing.Point(275, 198);
            this.bApplyAlgo.Name = "bApplyAlgo";
            this.bApplyAlgo.Size = new System.Drawing.Size(100, 38);
            this.bApplyAlgo.TabIndex = 8;
            this.bApplyAlgo.Text = "Appliquer l\'algorithme";
            this.bApplyAlgo.UseVisualStyleBackColor = true;
            this.bApplyAlgo.Click += new System.EventHandler(this.bApplyAlgo_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(182, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Nombre d\'erreurs";
            // 
            // tbNBErreurs
            // 
            this.tbNBErreurs.Location = new System.Drawing.Point(275, 242);
            this.tbNBErreurs.Name = "tbNBErreurs";
            this.tbNBErreurs.Size = new System.Drawing.Size(100, 20);
            this.tbNBErreurs.TabIndex = 9;
            // 
            // tbS2
            // 
            this.tbS2.Location = new System.Drawing.Point(275, 146);
            this.tbS2.Name = "tbS2";
            this.tbS2.Size = new System.Drawing.Size(100, 20);
            this.tbS2.TabIndex = 13;
            // 
            // tbS3
            // 
            this.tbS3.Location = new System.Drawing.Point(275, 172);
            this.tbS3.Name = "tbS3";
            this.tbS3.Size = new System.Drawing.Size(100, 20);
            this.tbS3.TabIndex = 12;
            // 
            // tbS1
            // 
            this.tbS1.Location = new System.Drawing.Point(275, 120);
            this.tbS1.Name = "tbS1";
            this.tbS1.Size = new System.Drawing.Size(100, 20);
            this.tbS1.TabIndex = 11;
            // 
            // lVi
            // 
            this.lVi.AutoSize = true;
            this.lVi.Location = new System.Drawing.Point(156, 92);
            this.lVi.Name = "lVi";
            this.lVi.Size = new System.Drawing.Size(79, 13);
            this.lVi.TabIndex = 14;
            this.lVi.Text = "Valeurs initiales";
            // 
            // lVf
            // 
            this.lVf.AutoSize = true;
            this.lVf.Location = new System.Drawing.Point(254, 92);
            this.lVf.Name = "lVf";
            this.lVf.Size = new System.Drawing.Size(140, 13);
            this.lVf.TabIndex = 15;
            this.lVf.Text = "Valeurs après apprentissage";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(169, 271);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Nombre d\'iterations";
            // 
            // tbNbItterations
            // 
            this.tbNbItterations.Location = new System.Drawing.Point(275, 268);
            this.tbNbItterations.Name = "tbNbItterations";
            this.tbNbItterations.Size = new System.Drawing.Size(100, 20);
            this.tbNbItterations.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 323);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbNbItterations);
            this.Controls.Add(this.lVf);
            this.Controls.Add(this.lVi);
            this.Controls.Add(this.tbS2);
            this.Controls.Add(this.tbS3);
            this.Controls.Add(this.tbS1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbNBErreurs);
            this.Controls.Add(this.bApplyAlgo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbwL2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbwL3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbwL1);
            this.Controls.Add(this.bNeuronInit);
            this.Controls.Add(this.bLRongeurInit);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bLRongeurInit;
        private System.Windows.Forms.Button bNeuronInit;
        private System.Windows.Forms.TextBox tbwL1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbwL3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbwL2;
        private System.Windows.Forms.Button bApplyAlgo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbNBErreurs;
        private System.Windows.Forms.TextBox tbS2;
        private System.Windows.Forms.TextBox tbS3;
        private System.Windows.Forms.TextBox tbS1;
        private System.Windows.Forms.Label lVi;
        private System.Windows.Forms.Label lVf;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbNbItterations;
    }
}

