﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Perceptron_1_couche
{
    enum EspeceRongeur
    {
        A,
        B,
    }

    class Rongeur
    {
        private double _taille;
        private double _masse;
        private EspeceRongeur _espece;

        #region propriétés
        public double Taille
        {
            get { return _taille; }
            set { _taille = value; }
        }

        public double Masse
        {
            get { return _masse; }
            set { _masse = value; }
        }

        public EspeceRongeur Espece
        {
            get { return _espece; }
            set { _espece = value; }
        }      
        #endregion

        #region Constructeurs
        public Rongeur(EspeceRongeur nom, double taille, double poids) 
        {
            this._espece = nom;
            this._taille = taille;
            this._masse = poids;
        }
        #endregion

    }
}
