﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Perceptron_1_couche
{
    public partial class Form1 : Form
    {
        List<Rongeur> lrongeurs;
        Neurone neurone;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lrongeurs = new List<Rongeur>();

            lrongeurs.Add(new Rongeur(EspeceRongeur.A, 36, 17));
            lrongeurs.Add(new Rongeur(EspeceRongeur.A, 41, 16));
            lrongeurs.Add(new Rongeur(EspeceRongeur.A, 48, 18));
            lrongeurs.Add(new Rongeur(EspeceRongeur.A, 47, 18));
            lrongeurs.Add(new Rongeur(EspeceRongeur.A, 50, 22));
            lrongeurs.Add(new Rongeur(EspeceRongeur.A, 48, 21));

            lrongeurs.Add(new Rongeur(EspeceRongeur.B, 48, 12));
            lrongeurs.Add(new Rongeur(EspeceRongeur.B, 56, 16));
            lrongeurs.Add(new Rongeur(EspeceRongeur.B, 62, 13));
            lrongeurs.Add(new Rongeur(EspeceRongeur.B, 60, 24));
            lrongeurs.Add(new Rongeur(EspeceRongeur.B, 65, 18));
            lrongeurs.Add(new Rongeur(EspeceRongeur.B, 66, 21));
        }

        private void bNeuronInit_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            neurone = new Neurone(1, (r.NextDouble() - 0.5) * 200, (r.NextDouble() - 0.5) * 200, (r.NextDouble() - 0.5) * 200);

            this.tbwL1.Text = String.Format("{0:0.0000}", neurone.GetPoids(0));
            this.tbwL2.Text = String.Format("{0:0.0000}", neurone.GetPoids(1));
            this.tbwL3.Text = String.Format("{0:0.0000}", neurone.GetPoids(2));

        }

        private void bApplyAlgo_Click(object sender, EventArgs e)
        {
            int i = 0;
            int erreur = 12;

            // affichage des wi
            this.tbwL1.Text = String.Format("{0:0.0000}", neurone.GetPoids(0));
            this.tbwL2.Text = String.Format("{0:0.0000}", neurone.GetPoids(1));
            this.tbwL3.Text = String.Format("{0:0.0000}", neurone.GetPoids(2));

            while(erreur > 0 && i <100000)
            {
                erreur = 0;
                foreach (Rongeur rongeur in lrongeurs)
                {
                    neurone.SetEntree(0, 1);
                    neurone.SetEntree(1, rongeur.Taille);
                    neurone.SetEntree(2, rongeur.Masse);

                    neurone.CalculeSortie();
                    bool sortieOK = true;
                    if (neurone.Sortie == 0 && rongeur.Espece == EspeceRongeur.A)
                    {
                        for (int j = 0; j < neurone.NombreEntree; j++)
                            neurone.SetPoid(j, neurone.GetPoids(j) + neurone.Getentree(j));
                        sortieOK = false;
                    }

                    if (neurone.Sortie == 1 && rongeur.Espece == EspeceRongeur.B)
                    {
                        for (int j = 0; j < neurone.NombreEntree; j++)
                            neurone.SetPoid(j, neurone.GetPoids(j) - neurone.Getentree(j));
                        sortieOK = false;
                    }

                    if (!sortieOK)
                        erreur++;
                }
                i++;
            }


            this.tbS1.Text = String.Format("{0:0.0000}", neurone.GetPoids(0));
            this.tbS2.Text = String.Format("{0:0.0000}", neurone.GetPoids(1));
            this.tbS3.Text = String.Format("{0:0.0000}", neurone.GetPoids(2));

            this.tbNBErreurs.Text = erreur.ToString();
            this.tbNbItterations.Text = i.ToString();
        }
    }
}
