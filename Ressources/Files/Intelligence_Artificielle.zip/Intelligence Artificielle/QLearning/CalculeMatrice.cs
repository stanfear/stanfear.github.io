﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLearning
{
    class CalculeMatrice
    {
        private Double[,] matriceR, matriceQ;
        private Double nbEpisode;
        private Double k;
        public Double[,] MatriceQ { get { return (Double[,])matriceQ.Clone(); } }
        public Double K
        {
            get { return k; }
            set { k = value; }
        }
        public Double NbEpisodes
        {
            get { return nbEpisode; }
            set { nbEpisode = value; }
        }


        //CONSTRUCTEUR
        public CalculeMatrice()
        {
            this.matriceQ = new Double[6, 6];
            this.matriceR = new Double[6, 6];
            InitMatriceQ();
            InitMatriceR();

        }

        private void InitMatriceQ()
        {
            for (int i = 0; i < matriceQ.GetLength(0); i++)
            {
                for (int j = 0; j < matriceQ.GetLength(1); j++)
                    matriceQ[i, j] = 0;

            }
        }
        private void InitMatriceR()
        {

            this.matriceR = new Double[,] {{ -1, 0, -1, -1, 0,-1 },
                                           { 0,-1,-1,0,-1,100},
                                           { -1,-1,-1,0,-1,-1},
                                           { -1,0,0,-1,0,-1},
                                           { 0,-1,-1,0,-1,-1},
                                           { -1,0,-1,-1,-1,-1} };
        }


        public int AlgoQlearning()
        {
            Random r = new Random();
            double[,] mattemp = new double[matriceQ.GetLength(0),matriceQ.GetLength(1)];
            int i = 1;
            do
            //for (int i = 1; i < nbEpisode ; i++)
            {
                int etatCourant = r.Next(0, 5);
                //Peut le choisir?
                mattemp = (double[,])matriceQ.Clone();
                do
                {
                    int nextState;
                    //passage d'une piece a l'autre
                    do{ nextState = r.Next(0,6); } while(matriceR[etatCourant, nextState] == -1);
                    double max = -2;
                    for (int j = 0; j < matriceQ.GetLength(1); j++)
			        {
                        max = Math.Max(max, matriceQ[nextState, j]);	
			        }
                    matriceQ[etatCourant, nextState] = matriceR[etatCourant, nextState] + k*max;
                    etatCourant = nextState;
                    //tant qu'on est pas sorti de la maison, donc on l'explore
                    //explore en fonction de la pièce.
                } while(etatCourant != 5);
                i++;
            }while(i < nbEpisode && !MatrixAreEqual(mattemp, matriceQ));
            return i;
        }



        static bool MatrixAreEqual(double[,] matrixA, double[,] matrixB)
        {
            // true if all values in A == corresponding values in B
            if (matrixA.GetLength(0) != matrixB.GetLength(0))
                return false;
            if (matrixA.GetLength(1) != matrixB.GetLength(1))
                return false;

            int Rows = matrixA.GetLength(0);
            int Cols = matrixA.GetLength(1);
            for (int i = 0; i < Rows; ++i) // each row of A and B
                for (int j = 0; j < Cols; ++j) // each col of A and B
                    if (matrixA[i,j] != matrixB[i,j])
                        return false;
            return true;
        }

    }
}
