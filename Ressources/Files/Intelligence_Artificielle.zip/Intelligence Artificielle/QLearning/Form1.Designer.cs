﻿namespace QLearning
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbRecupK = new System.Windows.Forms.TextBox();
            this.tbRecupN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAfficheMatrice = new System.Windows.Forms.Button();
            this.rtbMatriceQ = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "k";
            // 
            // tbRecupK
            // 
            this.tbRecupK.Location = new System.Drawing.Point(44, 19);
            this.tbRecupK.Name = "tbRecupK";
            this.tbRecupK.Size = new System.Drawing.Size(100, 20);
            this.tbRecupK.TabIndex = 1;
            // 
            // tbRecupN
            // 
            this.tbRecupN.Location = new System.Drawing.Point(44, 59);
            this.tbRecupN.Name = "tbRecupN";
            this.tbRecupN.Size = new System.Drawing.Size(100, 20);
            this.tbRecupN.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "N";
            // 
            // btnAfficheMatrice
            // 
            this.btnAfficheMatrice.Location = new System.Drawing.Point(44, 103);
            this.btnAfficheMatrice.Name = "btnAfficheMatrice";
            this.btnAfficheMatrice.Size = new System.Drawing.Size(100, 56);
            this.btnAfficheMatrice.TabIndex = 4;
            this.btnAfficheMatrice.Text = "Afficher la matrice Q";
            this.btnAfficheMatrice.UseVisualStyleBackColor = true;
            this.btnAfficheMatrice.Click += new System.EventHandler(this.btnAfficheMatrice_Click);
            // 
            // rtbMatriceQ
            // 
            this.rtbMatriceQ.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbMatriceQ.Location = new System.Drawing.Point(161, 19);
            this.rtbMatriceQ.Name = "rtbMatriceQ";
            this.rtbMatriceQ.Size = new System.Drawing.Size(273, 227);
            this.rtbMatriceQ.TabIndex = 5;
            this.rtbMatriceQ.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 262);
            this.Controls.Add(this.rtbMatriceQ);
            this.Controls.Add(this.btnAfficheMatrice);
            this.Controls.Add(this.tbRecupN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbRecupK);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbRecupK;
        private System.Windows.Forms.TextBox tbRecupN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAfficheMatrice;
        private System.Windows.Forms.RichTextBox rtbMatriceQ;
    }
}

