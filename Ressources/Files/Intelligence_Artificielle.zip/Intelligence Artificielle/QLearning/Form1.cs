﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLearning
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAfficheMatrice_Click(object sender, EventArgs e)
        {
            CalculeMatrice cm = new CalculeMatrice();
            double k,n;
            if (!Double.TryParse(tbRecupK.Text, out k))
            {
                MessageBox.Show("Valeur de K invalide", "valeur non valide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            cm.K = k;
            if (!Double.TryParse(tbRecupN.Text, out n))
            {
                MessageBox.Show("Valeur de N invalide", "valeur non valide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            cm.NbEpisodes = n;

            int i = cm.AlgoQlearning();
            if (i >= n)
                MessageBox.Show("on a fait toutes les itérations et les matrices n'ont pas convergées");
            else
                MessageBox.Show("Les matrices sont arrivées à la convergence");

            this.rtbMatriceQ.Text = Matrice2String(cm.MatriceQ);
        }

        private string Matrice2String(double[,] p)
        {
            string res = "";

            for (int i = 0; i < p.GetLength(0); i++)
            {
                for (int j = 0; j < p.GetLength(1); j++)
                {
                    res += String.Format(" {0,3} ", p[i, j]);
                }
                res += '\n';
            }

            return res;
        
        }
    }
}
