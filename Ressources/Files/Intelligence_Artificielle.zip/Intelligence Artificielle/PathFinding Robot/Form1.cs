﻿using ProjetIA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PathFinding_Robot
{
    enum TypeCaseToAdd
    {
        ground,
        wall,
        Start,
        End,
        pitfall,
        rock,
        waypoint,
        none
    }

    public partial class Form1 : Form
    {
        Random rand;
        Grille grid;
        int exerciseGenrated = 0;

        public Form1()
        {
            rand = new Random();
            InitializeComponent();

            // ajout de l'icon de la fenetre
            Bitmap TileSet = global::PathFinding_Robot.Properties.Resources.Tile;
            Bitmap Robot = TileSet.Clone(new Rectangle(4 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            IntPtr Hicon = Robot.GetHicon();
            this.Icon = Icon.FromHandle(Hicon);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // initialisation du seed
            int seed = rand.Next(Int32.MinValue, Int32.MaxValue);
            this.tbSeed.Text = seed.ToString();

            // seed qui posait problème pendant un temps
            // this.tbSeed.Text = "560627982";

            
            this.tbSeed.Tag = ++seed;

            bGenerateMap_Click(sender, EventArgs.Empty);

            #region chargement des images + préparation aux modifications de la grille
            Bitmap TileSet = global::PathFinding_Robot.Properties.Resources.Tile;
            Bitmap ground = TileSet.Clone(new Rectangle(0 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap wall = TileSet.Clone(new Rectangle(1 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap Start = TileSet.Clone(new Rectangle(2 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap End = TileSet.Clone(new Rectangle(3 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap waypoint = TileSet.Clone(new Rectangle(5 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap rock = TileSet.Clone(new Rectangle(7 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap pitfall = TileSet.Clone(new Rectangle(6 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            // bontons cliquable en permanances
            this.tsbGround.Image = ground;
            this.tsbGround.Tag = TypeCaseToAdd.ground;
            this.tsbWall.Image = wall;
            this.tsbWall.Tag = TypeCaseToAdd.wall;
            this.tsbStartingPoint.Image = Start;
            this.tsbStartingPoint.Tag = TypeCaseToAdd.Start;
            // boutons non cliquables en permanance
            this.tsbEndingPoint.Image = End;
            this.tsbEndingPoint.Tag = TypeCaseToAdd.End;
            this.tsbPitFall.Image = pitfall;
            this.tsbPitFall.Tag = TypeCaseToAdd.pitfall;
            this.tsbRock.Image = rock;
            this.tsbRock.Tag = TypeCaseToAdd.rock;
            this.tsbWayPoint.Image = waypoint;
            this.tsbWayPoint.Tag = TypeCaseToAdd.waypoint;
            #endregion
        }

        private void bGenerateMap_Click(object sender, EventArgs e)
        {
            // arret de l'animation
            bwAnimatePath.CancelAsync();

            // deselection du bouton de modification
            foreach (ToolStripButton button in Selecteur.Items)
            {
                button.Checked = false;
            }

            // desactive les 4 elements non communs à toutes les générations de grille
            this.tsbEndingPoint.Enabled = false;
            this.tsbPitFall.Enabled = false;
            this.tsbRock.Enabled = false;
            this.tsbWayPoint.Enabled = false;

            // génération des elements nécessaires à la création de la grille
            int newExerciseGenrated = 0;
            PopulationType p = PopulationType.startPoint;
            if (rbExo1.Checked)
            {
                p |= PopulationType.endPoint;
                newExerciseGenrated = 1;

                this.tsbEndingPoint.Enabled = true;
            }
            else if (rbExo2.Checked)
            {
                p |= PopulationType.lootItem;
                newExerciseGenrated = 2;

                this.tsbWayPoint.Enabled = true;
            }
            else if (rbExo3.Checked)
            {
                p |= PopulationType.rock | PopulationType.pitfall;
                newExerciseGenrated = 3;

                this.tsbPitFall.Enabled = true;
                this.tsbRock.Enabled = true;
            }

            int seed;

            if (!Int32.TryParse(this.tbSeed.Text, out seed)) // si le seed n'est pas valide
            {
                seed = rand.Next(Int32.MinValue, Int32.MaxValue);
            }
            else // le seed est valide
            {
                if (this.tbSeed.Tag.ToString() == seed.ToString() && newExerciseGenrated == exerciseGenrated)
                    // si le seed ou le type de carte n'a pas changé, depuis la dernière création, on en génère un nouveau
                {
                    seed = rand.Next(Int32.MinValue, Int32.MaxValue);
                }
            }
            this.rtbPath.Text = "";
            this.rtbPath.Tag = null;
            this.bAnimate.Enabled = false;
            this.tsddbTimesBetter.Text = "Information inconnue";
            this.tsddbTimesBetter.Enabled = false;

            this.tbSeed.Text = seed.ToString();
            this.tbSeed.Tag = seed;

            grid = new Grille(p, seed);

            exerciseGenrated = newExerciseGenrated;
            toolStripLabel2.Text = grid.PopulationSeed.ToString();

            // mise a jour de la représentation
            this.pictureBox1.BackgroundImage = grid.GetBackGroungMap(Grille.TILLSIZE.Width * grid.TailleX, Grille.TILLSIZE.Height * grid.TailleY);
            this.pictureBox1.Image = grid.GetFrontMap(Grille.TILLSIZE.Width * grid.TailleX, Grille.TILLSIZE.Height * grid.TailleY);
        }


        #region Gestion de l'animation
        private void bAnimatePath_Click(object sender, EventArgs e)
        {
            tsddbTimesBetter.Enabled = false;

            if (bwAnimatePath.IsBusy) // on est en train d'annuler l'animation
            {
                bwAnimatePath.CancelAsync();
                bAnimate.Text = "Animer le chemin";
            }
            else // on cherche à lancer l'annimation
            {
                bwAnimatePath.RunWorkerAsync(rtbPath.Tag);
                bAnimate.Text = "Arrêter l'animation";
            }
        }

        private void bwAnimatePath_DoWork(object sender, DoWorkEventArgs e)
        {
            List<GenericNode> steps = new List<GenericNode>(e.Argument as List<GenericNode>);
            if (steps.Count == 0) // si aucune étape
                return;


            Size tailleCase = Grille.TILLSIZE;
            Rectangle r = new Rectangle(new Point(0, 0), tailleCase);

            #region Chargement des ressources
            Bitmap TileSet = global::PathFinding_Robot.Properties.Resources.Tile;
            Bitmap robot = TileSet.Clone(new Rectangle(4 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap Start = TileSet.Clone(new Rectangle(2 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap End = TileSet.Clone(new Rectangle(3 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap waypoint = TileSet.Clone(new Rectangle(5 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap rock = TileSet.Clone(new Rectangle(7 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap pitfall = TileSet.Clone(new Rectangle(6 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap unknown = TileSet.Clone(new Rectangle(8 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap bosquet = TileSet.Clone(new Rectangle(9 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            #endregion

            double speed = 4; // vitesse, en noeuds par secondes
            double i = double.Epsilon;
            DateTime previousPrint = DateTime.Now;
            while(i < steps.Count && !(sender as BackgroundWorker).CancellationPending)
            {
                // récupération du noeud représantant la position entière précédente
                GenericNode previousNode = steps[(int)Math.Floor(i)];

                #region Gestion de l'affichage de la progression dans la richTextBox
                if (this.rtbPath.InvokeRequired)
                    this.rtbPath.Invoke((MethodInvoker) delegate {

                        // Dans certains rares cas, une exception apparait ici, 
                        // la raison est connue mais une solution qui fonctionne à 100% n'a pas encore été trouvée
                        lock (this.rtbPath)
                        {
                            if (this.rtbPath.SelectedText != previousNode.GetNom())
                            {
                                this.rtbPath.SelectAll();
                                this.rtbPath.SelectionColor = Color.Black;

                                this.rtbPath.Select(this.rtbPath.Text.IndexOf(previousNode.GetNom()), previousNode.GetNom().Length);
                                this.rtbPath.SelectionColor = Color.DarkOrange;
                                // déplacement du début de la selection à une ligne ligna avant pour permettre le scroll
                                this.rtbPath.SelectionStart = this.rtbPath.SelectionStart == 0 ? 0 : this.rtbPath.SelectionStart - 3;
                                this.rtbPath.ScrollToCaret();
                                // on remet le debut du curseur au bon endroit
                                this.rtbPath.SelectionStart = this.rtbPath.SelectionStart == 0 ? 0 : this.rtbPath.SelectionStart + 3;
                            }
                        }
                    });
                #endregion

                // récupération du noeud représantant la position entière suivante
                GenericNode NextNode = previousNode;
                if ((int)Math.Ceiling(i) != steps.Count)
                    NextNode = steps[(int)Math.Ceiling(i)];

                int deltapixels = (int)((i - Math.Truncate(i)) * tailleCase.Width);

                if(previousNode is TileNode) // le noeud comporte les coordonnées du robot
                {
                    // Récupère l'image dans laquelle on va dessiner
                    Image res = new Bitmap(tailleCase.Width * grid.TailleX, tailleCase.Height * grid.TailleY);
                    Graphics g = Graphics.FromImage(res);

                    // drawing start Point (seul point commun entre toutes les versions
                    r.Y = grid.StartPoint.y * tailleCase.Height;
                    r.X = grid.StartPoint.x * tailleCase.Width;
                    g.DrawImage(Start, r);

                    if (previousNode is PathWithStarNode)
                    {
                        List<coordonnee> cristalsLeft = new List<coordonnee>(grid.PopulationCrystals);
                        cristalsLeft.RemoveAll(item => (previousNode as PathWithStarNode).CristauxRecup.Contains(item));
                        foreach (coordonnee item in cristalsLeft)
                        {
                            r.Y = item.y * tailleCase.Height;
                            r.X = item.x * tailleCase.Width;
                            g.DrawImage(waypoint, r);
                        }
                    }
                    else if (previousNode is PathWithRockNode)
                    {
                        r.Y = grid.PitFall.y * tailleCase.Height;
                        r.X = grid.PitFall.x * tailleCase.Width;
                        if (!previousNode.EndState())
                        {
                            g.DrawImage(pitfall, r);
                            DrawPictureBetween(g, (previousNode as PathWithRockNode).Rock, (NextNode as PathWithRockNode).Rock, deltapixels, rock);
                        }
                        else
                            g.DrawImage(bosquet, r);

                    }
                    else // previousNode n'est pas plus qu'un chemin d'un point A à un point B
                    {
                        // drawing end Point
                        r.Y = grid.EndPoint.y * tailleCase.Height;
                        r.X = grid.EndPoint.x * tailleCase.Width;
                        g.DrawImage(End, r);
                    }

                    DrawPictureBetween(g, (previousNode as TileNode).Coordonnees, (NextNode as TileNode).Coordonnees, deltapixels, robot);


                    if (this.pictureBox1.InvokeRequired)
                        this.pictureBox1.Invoke((MethodInvoker)delegate
                        {
                            lock (this.pictureBox1)
                            {
                                this.pictureBox1.Image.Dispose();
                                this.pictureBox1.Image = res;
                            }
                        });

                    DateTime now = DateTime.Now;
                    TimeSpan sinceLast = now - previousPrint;
                    previousPrint = now;
                    i += sinceLast.TotalMilliseconds / (1000 / speed);
                }
            }
            if((sender as BackgroundWorker).CancellationPending)
            {
                e.Cancel = true;
            }
        }

        private void DrawPictureBetween(Graphics g, coordonnee prev, coordonnee next, int deltapixels, Bitmap image)
        {
            // test de la direction du delta
            coordonnee delta = new coordonnee(next.x - prev.x, next.y - prev.y);
            Rectangle r = new Rectangle(new Point(0, 0), image.Size);
            r.X = Grille.TILLSIZE.Width * prev.x;
            r.Y = Grille.TILLSIZE.Height * prev.y;
            if (delta.x != 0)// déplacement sur l'axe horizontal
                r.X += delta.x * deltapixels;
            if (delta.y != 0)// déplacement sur l'axe vertical
                r.Y += delta.y * deltapixels;
            g.DrawImage(image, r);
        }

        private void bwAnimatePath_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                // reinitialisation des images
                this.pictureBox1.Image = grid.GetFrontMap();
                this.pictureBox1.BackgroundImage = grid.GetBackGroungMap();
            }

            this.rtbPath.SelectAll();
            this.rtbPath.SelectionColor = Color.Black;
            bAnimate.Text = "Animer le chemin";
            tsddbTimesBetter.Enabled = true;
        }
        #endregion

        #region Prise en charge de la modification de la grille
        private void tsb_click(object sender, EventArgs e)
        {
            ToolStripButton tsSender = sender as ToolStripButton;
            foreach (ToolStripButton button in tsSender.GetCurrentParent().Items)
            {
                button.Checked = false;
            }
            tsSender.Checked = true;
        }
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                bwAnimatePath.CancelAsync();
                // recupere la case Cochée
                TypeCaseToAdd selectedType = TypeCaseToAdd.none;
                foreach (ToolStripButton button in this.Selecteur.Items)
                {
                    if (button.Checked)
                        selectedType = (TypeCaseToAdd)button.Tag;
                }

                MouseEventArgs mouseEventArgs = e as MouseEventArgs;
                Point positionCase = new Point(mouseEventArgs.X / Grille.TILLSIZE.Width, mouseEventArgs.Y / Grille.TILLSIZE.Height);


                Image pic2draw;

                switch (selectedType)
                {
                    case TypeCaseToAdd.ground:
                        grid[coordonnee.FromPoint(positionCase)] = TypeCase.Ground;
                        grid.removeAnyAt(coordonnee.FromPoint(positionCase));

                        pic2draw = this.tsbGround.Image;
                        break;
                    case TypeCaseToAdd.wall:
                        grid[coordonnee.FromPoint(positionCase)] = TypeCase.Unwalkable;
                        grid.removeAnyAt(coordonnee.FromPoint(positionCase));

                        pic2draw = this.tsbWall.Image;
                        break;
                    case TypeCaseToAdd.Start:
                        grid.removeAnyAt(coordonnee.FromPoint(positionCase));
                        grid.StartPoint = coordonnee.FromPoint(positionCase);
                        grid[coordonnee.FromPoint(positionCase)] = TypeCase.Ground;

                        pic2draw = this.tsbStartingPoint.Image;
                        break;
                    case TypeCaseToAdd.End:
                        grid.removeAnyAt(coordonnee.FromPoint(positionCase));
                        grid.EndPoint = coordonnee.FromPoint(positionCase);
                        grid[coordonnee.FromPoint(positionCase)] = TypeCase.Ground;

                        pic2draw = this.tsbEndingPoint.Image;
                        break;
                    case TypeCaseToAdd.pitfall:
                        grid.removeAnyAt(coordonnee.FromPoint(positionCase));
                        grid.PitFall = coordonnee.FromPoint(positionCase);
                        grid[coordonnee.FromPoint(positionCase)] = TypeCase.Ground;

                        pic2draw = this.tsbPitFall.Image;
                        break;
                    case TypeCaseToAdd.rock:
                        grid.removeAnyAt(coordonnee.FromPoint(positionCase));
                        grid.Rock = coordonnee.FromPoint(positionCase);
                        grid[coordonnee.FromPoint(positionCase)] = TypeCase.Ground;

                        pic2draw = this.tsbRock.Image;
                        break;
                    case TypeCaseToAdd.waypoint:
                        grid.removeAnyAt(coordonnee.FromPoint(positionCase));
                        grid.AddCrystal(coordonnee.FromPoint(positionCase));
                        grid[coordonnee.FromPoint(positionCase)] = TypeCase.Ground;

                        pic2draw = this.tsbWayPoint.Image;
                        break;
                    default:
                        pic2draw = this.tsbGround.Image;
                        break;
                }

                // modification a la volée de l'image 
                Image pic = this.pictureBox1.Image;
                Graphics g = Graphics.FromImage(pic);
                g.DrawImage(pic2draw, new Point(positionCase.X * Grille.TILLSIZE.Width, positionCase.Y * Grille.TILLSIZE.Height));
                this.pictureBox1.Image = pic;
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.pictureBox1_MouseMove(sender, e as MouseEventArgs);
        }
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            this.pictureBox1.Image = grid.GetFrontMap();
            this.pictureBox1.BackgroundImage = grid.GetBackGroungMap();
        }
        #endregion

        #region Gestion du calcul du chemin
        private void bComputePath_Click(object sender, EventArgs e)
        {
            // change le curseur en curseur d'attente
            this.UseWaitCursor = true;
            // bloque le bouton
            bComputePath.Enabled = false;
            bwAnimatePath.CancelAsync();
            rtbPath.Text = "";
            bwComputePath.RunWorkerAsync();
        }

        private void bwComputePath_DoWork(object sender, DoWorkEventArgs e)
        {
            GenericNode startingNode;
            switch (exerciseGenrated)
            {
                case 1:
                    startingNode = new TileNode(grid, grid.StartPoint, grid.EndPoint);
                    break;
                case 2:
                    startingNode = new PathWithStarNode(grid, grid.StartPoint, grid.StartPoint, new List<coordonnee>());
                    break;
                case 3:
                    startingNode = new PathWithRockNode(grid, grid.StartPoint, grid.PitFall, grid.Rock);
                    break;
                default:
                    throw new InvalidOperationException("Exercice généré invalide");
            }


            Graph SolverAstar = new Graph();
            Graph SolverDijkstra = new GraphNoHCost();

            SolverAstar.StartNode = startingNode;
            SolverDijkstra.StartNode = startingNode;

            // calcul la solution dans deux threads séparés, puis continue un fois les deux finis
            Task SolverAStarTask = Task.Factory.StartNew(() => { SolverAstar.Solve(); });
            Task SolverDijkstraTask = Task.Factory.StartNew(() => { SolverDijkstra.Solve(); });
            Task.WaitAll(SolverAStarTask, SolverDijkstraTask);

            /*if (!SolverAstar.Statistiques.SolutionFound)
                throw new InvalidOperationException("Aucune solution n'existe");
            else
             */
            e.Result = new List<Graph> { SolverAstar, SolverDijkstra };
        }

        private void bwComputePath_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            bComputePath.Enabled = true;
            if (e.Error != null) // si une erreur est arrivé
            {
                MessageBox.Show("Error: " + e.Error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            List<GenericNode> chemin = (e.Result as List<Graph>)[0].Solution;
            rtbPath.Tag = chemin;

            // mise a jour du texte de la rtb
            foreach (GenericNode item in chemin)
            {
                rtbPath.Text += item.GetNom() + "\n";
            }

            this.pictureBox1.Image = CreateSolutionPicture(chemin);

            SolverStats statsAetoile = (e.Result as List<Graph>)[0].Statistiques;
            SolverStats statsA = (e.Result as List<Graph>)[1].Statistiques;

            if(!statsAetoile.SolutionFound)
            {
                MessageBox.Show("Aucune solution n'a pu être trouvé", "Aucune solution",MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            this.tsmiAvecHCost.Text = String.Format("avec cout Heuristique : {0} ({1})", statsAetoile.TotalNodesCount, statsAetoile.ClosedNodeCount);
            this.tsmiAvecHCost.Tag = getExploredNodesImage((e.Result as List<Graph>)[0]);
            this.tsmiSansHCost.Text = String.Format("sans cout Heuristique : {0} ({1})", statsA.TotalNodesCount, statsA.ClosedNodeCount);
            this.tsmiSansHCost.Tag = getExploredNodesImage((e.Result as List<Graph>)[1]);

            this.tsddbTimesBetter.Text = String.Format("efficacité de l'heuristique : {0:N}x meilleur que l'heuristique Nulle",
                                                      ((double)statsA.TotalNodesCount) / ((double)statsAetoile.TotalNodesCount));
            this.tsddbTimesBetter.Enabled = true;
            //this.toolStripLabel4.Text = String.Format("{0}/{1} ≈ {2:N}", graph.CountNodesClosedList, graph.CountNodesOpenList, ((double)graph.CountNodesClosedList) / ((double)graph.CountNodesOpenList));

            // remet le curseur normal
            this.UseWaitCursor = false;
            // active le bouton d'animation
            this.bAnimate.Enabled = true;
        }

        private Image getExploredNodesImage(Graph graph)
        {
            Image res = new Bitmap(Grille.TILLSIZE.Width * grid.TailleX, Grille.TILLSIZE.Height * grid.TailleY);
            Graphics g = Graphics.FromImage(res);
            g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
            Rectangle r = new Rectangle(new Point(0, 0), Grille.TILLSIZE);



            foreach (TileNode item in graph.OpenNodesList)
            {
                r.Y = item.Coordonnees.y * Grille.TILLSIZE.Height;
                r.X = item.Coordonnees.x * Grille.TILLSIZE.Width;
                Pen pen = new Pen(Color.Blue);
                pen.Alignment = System.Drawing.Drawing2D.PenAlignment.Inset;
                g.DrawRectangle(pen, r);
                Brush br = new SolidBrush(Color.FromArgb(100, Color.Blue));
                g.FillRectangle(br, r);
            }
            foreach (TileNode item in graph.ClosedNodesList)
            {
                r.Y = item.Coordonnees.y * Grille.TILLSIZE.Height;
                r.X = item.Coordonnees.x * Grille.TILLSIZE.Width;
                Pen pen = new Pen(Color.Red);
                pen.Alignment = System.Drawing.Drawing2D.PenAlignment.Inset;
                g.DrawRectangle(pen, r);
                Brush br = new SolidBrush(Color.FromArgb(100, Color.Red));
                g.FillRectangle(br, r);
            }
            return res;
        }

        private Image CreateSolutionPicture(List<GenericNode> chemin)
        {

            List<coordonnee> cheminCoordonnee = new List<coordonnee>();
            foreach (GenericNode item in chemin)
            {
                cheminCoordonnee.Add((item as TileNode).Coordonnees);
            }
            Image res = grid.GetFrontMap(Grille.TILLSIZE.Width * grid.TailleX, Grille.TILLSIZE.Height * grid.TailleY);
            Graphics g = Graphics.FromImage(res);
            Size tailleCase = Grille.TILLSIZE;
            Rectangle r = new Rectangle(new Point(0, 0), tailleCase);
            Bitmap TileSet = global::PathFinding_Robot.Properties.Resources.Tile;
            Bitmap pathTile = TileSet.Clone(new Rectangle(10 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);

            foreach (GenericNode item in chemin)
            {
                coordonnee c = (item as TileNode).Coordonnees;
                r.X = Grille.TILLSIZE.Width * c.x;
                r.Y = Grille.TILLSIZE.Height * c.y;
                g.DrawImage(pathTile, r);
            }

            return res;
        }
        #endregion

        #region prise en charge de l'affichage des noeuds explorés
        private void tsmi_MouseEnter(object sender, EventArgs e)
        {
            this.bwAnimatePath.CancelAsync();
            this.pictureBox1.Tag = this.pictureBox1.Image; // mise en mémoire de l'image
            this.pictureBox1.Image = (sender as ToolStripMenuItem).Tag as Image;
        }

        private void tsmi_MouseLeave(object sender, EventArgs e)
        {
            this.pictureBox1.Image = this.pictureBox1.Tag as Image;
            this.pictureBox1.BackgroundImage = grid.GetBackGroungMap();
        }
        #endregion
    }
}
