﻿using ProjetIA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PathFinding_Robot
{
    class PathWithStarNode : TileNode
    {
        List<coordonnee> cristaux_recup;

        public List<coordonnee> CristauxRecup
        {
            get { return cristaux_recup; }
            set { cristaux_recup = value; }
        }


        public PathWithStarNode(Grille g, coordonnee pos, coordonnee dest,List<coordonnee> cristaux)
            : base( g,  pos,  dest)
        {
            cristaux_recup = new List<coordonnee>(cristaux);
            if (containingGrid.PopulationCrystals.Contains(position) && !cristaux.Contains(position))
            {
                cristaux_recup.Add(position);
            }

            cristaux_recup.Sort();
            Name = position.ToString() + ":";
            foreach (coordonnee c in cristaux_recup)
            {
                Name += c.ToString();
            }
        }


        public override double GetArcCost(GenericNode N2)
        {
            return 1;
        }

        public override bool EndState()
        {
            if (!this.position.Equals(this.destination))
                return false;

            IEnumerable<coordonnee> lst = this.cristaux_recup.Intersect(containingGrid.PopulationCrystals);
            return lst.Count() == containingGrid.PopulationCrystals.Count;
        }

        public override List<GenericNode> GetListSucc()
        {
            List<GenericNode> listSucc = new List<GenericNode>();
            for (int i = 1; i < 9; i += 2)
            {
                int deltax = (i % 3) - 1;
                int deltay = (i / 3) - 1;
                coordonnee c = new coordonnee(position.x + deltax, position.y + deltay);
                if (c.x < containingGrid.TailleX && c.x >= 0 && c.y < containingGrid.TailleY && c.y >= 0) // si dans la grille
                    if (containingGrid[c] != TypeCase.Unwalkable) // si nouvelle case marchable
                    {
                        listSucc.Add(new PathWithStarNode(containingGrid, c, destination, cristaux_recup));
                    }
            }
            return listSucc;
        }

        public override void CalculeHCost()
        {
            
            IEnumerable<coordonnee> lst = this.cristaux_recup.Intersect(containingGrid.PopulationCrystals);
            int elementRestant = containingGrid.PopulationCrystals.Count - lst.Count();


            List<coordonnee> listLeft = new List<coordonnee>(containingGrid.PopulationCrystals);
            foreach (coordonnee c in lst)
                listLeft.Remove(c);
            HCost = calculHeuristique(position, destination, listLeft);

        }

        private int calculHeuristique(coordonnee position, coordonnee destination, IEnumerable<coordonnee> lstleft)
        {
            if (lstleft.Count() < 1)
                return distance(position, destination);

            List<int> costs = new List<int>();
            foreach (coordonnee c in lstleft)
            {
                List<coordonnee> nlst = new List<coordonnee>(lstleft);
                nlst.Remove(c);
                costs.Add(distance(position, c) + calculHeuristique(c,destination, nlst));
            }
            return costs.Min();
        }

        private int distance(coordonnee position, coordonnee destination)
        {
            return Math.Abs(position.x - destination.x) + Math.Abs(position.y - destination.y);
        }


        public override string ToString()
        {
            return GetNom();
        }
    }
}
