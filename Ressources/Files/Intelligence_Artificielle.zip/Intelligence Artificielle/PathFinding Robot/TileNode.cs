﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjetIA;

namespace PathFinding_Robot
{
    class TileNode : GenericNode
    {
        protected Grille containingGrid;
        protected coordonnee destination;
        protected coordonnee position;

        public coordonnee Coordonnees
        {
            get { return position; }
            set { position = value; }
        }
        

        public TileNode(Grille g, coordonnee pos,coordonnee dest) : base("n/a")
        {
            containingGrid = g;
            destination = dest;
            position = pos;
            Name = position.ToString();
        }

        public override double GetArcCost(GenericNode N2)
        {
            return 1;
        }

        public override bool EndState()
        {
            return position.Equals(destination);
        }

        public override List<GenericNode> GetListSucc()
        {
            List<GenericNode> listSucc = new List<GenericNode>();
            for (int i = 1; i < 9; i+=2)
            {
                int deltax = (i % 3) - 1;
                int deltay = (i / 3) - 1;
                coordonnee c = new coordonnee(position.x + deltax, position.y + deltay);
                if (c.x < containingGrid.TailleX && c.x >= 0 && c.y < containingGrid.TailleY && c.y >= 0) // si dans la grille
                    if (containingGrid[c] != TypeCase.Unwalkable) // si nouvelle case marchable
                        listSucc.Add(new TileNode(containingGrid, c, destination));
            }
            return listSucc;
        }

        public override void CalculeHCost()
        {
            HCost = Math.Abs(position.x - destination.x) + Math.Abs(position.y - destination.y);
        }
    }
}
