﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace PathFinding_Robot
{
    enum TypeCase
    {
        Unwalkable = -1,
        Ground
    };

    struct coordonnee : IComparable
    {
        public int x;
        public int y;

        public coordonnee(int x = 0, int y = 0)
        {
            this.x = x;
            this.y = y;
        }

        public static coordonnee fromInt(int coord, int tailleLigne)
        {
            coordonnee res = new coordonnee();
            res.x = coord / tailleLigne;
            res.y = coord % tailleLigne;
            return res;
        }
     
        public int Distance(coordonnee c)
        {
            return Math.Abs(this.x - c.x) + Math.Abs(this.y - c.y);
        }

        public override string ToString()
        {
            return string.Format("<{0};{1}>", this.x, this.y);
        }

        public int CompareTo(object obj)
        {
            coordonnee c;
            try
            {
                c = (coordonnee)obj;
            }
            catch (Exception)
            {
                return -1;
            }
            if(c.x.CompareTo(this.x) == 0)
                return c.y.CompareTo(this.y);
            return c.x.CompareTo(this.x);
        }

        internal static coordonnee FromPoint(Point point)
        {
            return new coordonnee(point.X, point.Y);
        }
    };


    [Flags]
    enum PopulationType
    {
        none = 0x00,
        lootItem = 0x01,
        startPoint = 0x02,
        endPoint = 0x04,
        rock = 0x08,
        pitfall = 0x10,
    };


    class Grille
    {
        public static readonly Size TILLSIZE = new Size(32, 32);


        TypeCase[,] plateau;
        Dictionary<coordonnee, PopulationType> population;
        public int PopulationSeed { get; set; }


        public int TailleX
        {
            get { return plateau.GetLength(0); }
        }
        public int TailleY
        {
            get { return plateau.GetLength(1); }
        }

        #region Propriétés (point de départ, d'arrivée, emplacement du rocher, du trou, des elements au sol)
        public List<coordonnee> PopulationCrystals
        {
            get {
                return getAllFromPopulation(PopulationType.lootItem);
            }
        }
        public coordonnee StartPoint
        {
            get { return getAllFromPopulation(PopulationType.startPoint)[0]; }
            set 
            {
                // d'abord, on enleve le point de départ
                population.Remove(StartPoint);
                // puis on ajoute le nouveau
                population.Add(value, PopulationType.startPoint);
            }
        }
        public coordonnee EndPoint
        {
            get { return getAllFromPopulation(PopulationType.endPoint)[0]; }
            set
            {
                // d'abord, on enleve le point de départ
                population.Remove(EndPoint);
                // puis on ajoute le nouveau
                population.Add(value, PopulationType.endPoint);
            }
        }
        public coordonnee PitFall
        {
            get { return getAllFromPopulation(PopulationType.pitfall)[0]; }
            set
            {
                // d'abord, on enleve le point de départ
                population.Remove(PitFall);
                // puis on ajoute le nouveau
                population.Add(value, PopulationType.pitfall);
            }
        }
        public coordonnee Rock
        {
            get { return getAllFromPopulation(PopulationType.rock)[0]; }
            set
            {
                // d'abord, on enleve le point de départ
                population.Remove(Rock);
                // puis on ajoute le nouveau
                population.Add(value, PopulationType.rock);
            }
        }
        #endregion

        private List<coordonnee> getAllFromPopulation(PopulationType populationType)
        {
            List<coordonnee> res = new List<coordonnee>();
            foreach (KeyValuePair<coordonnee, PopulationType> item in population)
                if (item.Value == populationType)
                    res.Add(item.Key);
            return res; 
        }

        public TypeCase this[coordonnee c]
        {
            get { return plateau[c.y, c.x];}
            set { plateau[c.y, c.x] = value; }
        }

        public Grille(PopulationType doPopulate = PopulationType.none, int seed = 0)
        {
            plateau = new TypeCase[20, 20];
            this.InitGrille();
            if (seed == 0)
                seed = (int) DateTime.Now.Ticks;
            PopulationSeed = seed;

            Random r = new Random(PopulationSeed);

            population = new Dictionary<coordonnee, PopulationType>();

            if(doPopulate.HasFlag(PopulationType.startPoint))
                InsertValidePopulationItem(PopulationType.startPoint, r);
            if(doPopulate.HasFlag(PopulationType.endPoint))
                InsertValidePopulationItem(PopulationType.endPoint, r);
            if (doPopulate.HasFlag(PopulationType.lootItem))
                PopulateLoots(r);
            if (doPopulate.HasFlag(PopulationType.rock))
                InsertValidePopulationItem(PopulationType.rock, r);
            if (doPopulate.HasFlag(PopulationType.pitfall))
                InsertValidePopulationItem(PopulationType.pitfall, r);
        }

        private void InsertValidePopulationItem(PopulationType populationType, Random r)
        {
            coordonnee c;
            bool done = false;
            do{
                c = coordonnee.fromInt(r.Next(plateau.Length), plateau.GetLength(0));
                if (this[c] != TypeCase.Unwalkable && !this.population.ContainsKey(c))
                {
                    done = true;
                    population.Add(c, populationType);
                }
                else
                    done = false;
            }while (!done); // insert la case de départ à un emplacement valide
                
        }

        private void InitGrille()
        {
            //BORDS DU PLATEAU
            //ligne du haut
            for (int j = 0; j < plateau.GetLength(1); j++)
            {
                plateau[0,j] = TypeCase.Unwalkable;
            }
            //ligne du bas
            for (int j = 0; j < plateau.GetLength(1); j++)
            {
                plateau[19, j] = TypeCase.Unwalkable;
            }
            //ligne de gauche
            for (int i = 0; i < plateau.GetLength(1); i++)
            {
                plateau[i,0] = TypeCase.Unwalkable;
            }
            //ligne du bas
            for (int i = 0; i < plateau.GetLength(1); i++)
            {
                plateau[i,19] = TypeCase.Unwalkable;
            }

            //LES OBSTACLES SUR LE PLATEAU
            //Lesblocs
            for(int lig=3; lig <= 8; lig++)
            {
                for (int col = 4; col <= 5; col++)
                {
                    plateau[lig, col] = TypeCase.Unwalkable;
                }
            }

            for (int lig = 5; lig <= 8; lig++)
            {
                for (int col = 11; col <= 13; col++)
                {
                    plateau[lig, col] = TypeCase.Unwalkable;
                }
            }

            for (int lig = 14; lig <= 18; lig++)
            {
                for (int col = 10; col <= 11; col++)
                {
                    plateau[lig, col] = TypeCase.Unwalkable;
                }
            }
            for (int lig = 12; lig <= 16; lig++)
            {
                for (int col = 15; col <= 16; col++)
                {
                    plateau[lig, col] = TypeCase.Unwalkable;
                }
            }
            for (int lig = 11; lig <= 15; lig++)
            {
                for (int col = 5; col <= 6; col++)
                {
                    plateau[lig, col] = TypeCase.Unwalkable;
                }
            }
            //les lignes
            for (int col = 1; col <= 4; col++)
            {
                plateau[11, col] = TypeCase.Unwalkable;
            }
            for (int col = 8; col <= 9; col++)
            {
                plateau[11, col] = TypeCase.Unwalkable;
            }
            //La colonne
            for (int lig = 1; lig <= 10; lig++)
            {
                plateau[lig, 9] = TypeCase.Unwalkable;
            }
        }

        private void PopulateLoots(Random r)
        {
            do
            {
                coordonnee c = coordonnee.fromInt(r.Next(plateau.Length), plateau.GetLength(0));
                switch (this[c])
                {
                    case TypeCase.Unwalkable:
                    // on ne fait rien, on passe à la suite
                        break;
                    case TypeCase.Ground:
                    // on ajoute une cible au coordonnées
                        if(!this.population.ContainsKey(c))
                            this.population.Add(c, PopulationType.lootItem);
                        break;
                    default:
                        break;
                }

            } while (this.PopulationCrystals.Count < 4);
        }

        public override string ToString()
        {
            string res = "";
            /*
            for (int i = 0; i < this.plateau.GetLength(0); i++)
            {
                for (int j = 0; j < plateau.GetLength(1); j++)
                {
                    if (this.population.Contains(new coordonnee(i, j)))
                        res += "X";
                    else
                        if (StartPosition.Equals(new coordonnee(i, j)) && !EndPosition.Equals(new coordonnee(i, j)))
                            res += "D";
                        else if (EndPosition.Equals(new coordonnee(i, j)))
                            res += "F";
                        else
                            res += (this.plateau[i, j] == TypeCase.Unwalkable ? "█" : " ");
                }
                res += "\n";
            }*/
            return res;
        }

        public Image GetBackGroungMap(int largeur = 640, int hauteur = 640)
        {
            Image res = new Bitmap(largeur, hauteur);
            Graphics g = Graphics.FromImage(res);
            Size tailleCase = new Size(largeur / plateau.GetLength(0), hauteur / plateau.GetLength(1));
            Rectangle r = new Rectangle(new Point(0,0), tailleCase);

            Bitmap TileSet = global::PathFinding_Robot.Properties.Resources.Tile;

            Bitmap ground = TileSet.Clone(new Rectangle(0 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap wall = TileSet.Clone(new Rectangle(1 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap unknown = TileSet.Clone(new Rectangle(5 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);


            for (int i = 0; i < this.plateau.GetLength(0); i++)
            {
                r.Y = tailleCase.Height * i;
                for (int j = 0; j < plateau.GetLength(1); j++)
                {
                    r.X = tailleCase.Width * j;
                    // la case est soit marchable soit non
                    Bitmap cell;
                    switch(this.plateau[i,j])
                    {
                        case TypeCase.Ground:
                            cell = ground;
                            break;
                        case TypeCase.Unwalkable:
                            cell = wall;
                            break;
                        default :
                            cell = unknown;
                            break;
                    }
                    g.DrawImage(cell, r);
                };
            }
            return res;
        }

        public Image GetFrontMap(int largeur = 640, int hauteur = 640)
        {
            Image res = new Bitmap(largeur, hauteur);
            Graphics g = Graphics.FromImage(res);
            Size tailleCase = new Size(largeur / plateau.GetLength(0), hauteur / plateau.GetLength(1));
            Rectangle r = new Rectangle(new Point(0, 0), tailleCase);

            Bitmap TileSet = global::PathFinding_Robot.Properties.Resources.Tile;
            Bitmap Start = TileSet.Clone(new Rectangle(2 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap End = TileSet.Clone(new Rectangle(3 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap waypoint = TileSet.Clone(new Rectangle(5 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap rock = TileSet.Clone(new Rectangle(7 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap pitfall = TileSet.Clone(new Rectangle(6 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);
            Bitmap unknown = TileSet.Clone(new Rectangle(8 * Grille.TILLSIZE.Width, 0 * Grille.TILLSIZE.Height, Grille.TILLSIZE.Width, Grille.TILLSIZE.Height), TileSet.PixelFormat);

            foreach(KeyValuePair<coordonnee, PopulationType> item in population)
            {
                r.Y = item.Key.y * tailleCase.Height;
                r.X = item.Key.x * tailleCase.Width;

                Bitmap cell;

                switch(item.Value)
                {
                    case PopulationType.endPoint:
                        cell = End;
                        break;
                    case PopulationType.startPoint:
                        cell = Start;
                        break;
                    case PopulationType.lootItem:
                        cell = waypoint;
                        break;
                    case PopulationType.rock:
                        // A CHANGER
                        cell = rock;
                        break;
                    case PopulationType.pitfall:
                        // A CHANGER
                        cell = pitfall;
                        break;
                    default:
                        cell = unknown;
                        break;

                }
                g.DrawImage(cell, r);
            }
            return res;
        }

        internal void removeAnyAt(coordonnee coordonnee)
        {
            if (population.ContainsKey(coordonnee))
            {
                if (population[coordonnee] == PopulationType.lootItem)
                    this.population.Remove(coordonnee);
                else
                {
                    PopulationType deletedItem = population[coordonnee];
                    InsertValidePopulationItem(deletedItem, new Random());
                    this.population.Remove(coordonnee);
                }
            }
        }

        internal void AddCrystal(coordonnee coordonnee)
        {
            if(!this.population.ContainsKey(coordonnee))
                this.population.Add(coordonnee, PopulationType.lootItem);
        }
    }
}
