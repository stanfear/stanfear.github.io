﻿namespace PathFinding_Robot
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bwAnimatePath = new System.ComponentModel.BackgroundWorker();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.Selecteur = new System.Windows.Forms.ToolStrip();
            this.tsbGround = new System.Windows.Forms.ToolStripButton();
            this.tsbWall = new System.Windows.Forms.ToolStripButton();
            this.tsbStartingPoint = new System.Windows.Forms.ToolStripButton();
            this.tsbEndingPoint = new System.Windows.Forms.ToolStripButton();
            this.tsbWayPoint = new System.Windows.Forms.ToolStripButton();
            this.tsbPitFall = new System.Windows.Forms.ToolStripButton();
            this.tsbRock = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsddbTimesBetter = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsmiLegend = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAvecHCost = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSansHCost = new System.Windows.Forms.ToolStripMenuItem();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.ExerciceSelectionPanel = new System.Windows.Forms.Panel();
            this.rbExo3 = new System.Windows.Forms.RadioButton();
            this.rbExo2 = new System.Windows.Forms.RadioButton();
            this.rbExo1 = new System.Windows.Forms.RadioButton();
            this.rtbPath = new System.Windows.Forms.RichTextBox();
            this.bAnimate = new System.Windows.Forms.Button();
            this.bComputePath = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSeed = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bwComputePath = new System.ComponentModel.BackgroundWorker();
            this.toolStripContainer1.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.Selecteur.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.SidePanel.SuspendLayout();
            this.ExerciceSelectionPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bwAnimatePath
            // 
            this.bwAnimatePath.WorkerSupportsCancellation = true;
            this.bwAnimatePath.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bwAnimatePath_DoWork);
            this.bwAnimatePath.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bwAnimatePath_RunWorkerCompleted);
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.BottomToolStripPanel
            // 
            this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.Selecteur);
            this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.toolStrip1);
            this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.toolStrip2);
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.SidePanel);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.pictureBox1);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(1040, 640);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.LeftToolStripPanelVisible = false;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.RightToolStripPanelVisible = false;
            this.toolStripContainer1.Size = new System.Drawing.Size(1040, 679);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            this.toolStripContainer1.TopToolStripPanelVisible = false;
            // 
            // Selecteur
            // 
            this.Selecteur.Dock = System.Windows.Forms.DockStyle.None;
            this.Selecteur.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.Selecteur.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.Selecteur.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbGround,
            this.tsbWall,
            this.tsbStartingPoint,
            this.tsbEndingPoint,
            this.tsbWayPoint,
            this.tsbPitFall,
            this.tsbRock});
            this.Selecteur.Location = new System.Drawing.Point(3, 0);
            this.Selecteur.Name = "Selecteur";
            this.Selecteur.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.Selecteur.Size = new System.Drawing.Size(203, 39);
            this.Selecteur.TabIndex = 1;
            this.Selecteur.Text = "toolStrip1";
            // 
            // tsbGround
            // 
            this.tsbGround.CheckOnClick = true;
            this.tsbGround.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbGround.Image = ((System.Drawing.Image)(resources.GetObject("tsbGround.Image")));
            this.tsbGround.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGround.Name = "tsbGround";
            this.tsbGround.Size = new System.Drawing.Size(36, 36);
            this.tsbGround.Text = "Sol";
            this.tsbGround.Click += new System.EventHandler(this.tsb_click);
            // 
            // tsbWall
            // 
            this.tsbWall.CheckOnClick = true;
            this.tsbWall.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbWall.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbWall.Name = "tsbWall";
            this.tsbWall.Size = new System.Drawing.Size(23, 36);
            this.tsbWall.Text = "Mur";
            this.tsbWall.Click += new System.EventHandler(this.tsb_click);
            // 
            // tsbStartingPoint
            // 
            this.tsbStartingPoint.CheckOnClick = true;
            this.tsbStartingPoint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbStartingPoint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStartingPoint.Name = "tsbStartingPoint";
            this.tsbStartingPoint.Size = new System.Drawing.Size(23, 36);
            this.tsbStartingPoint.Text = "Entrée";
            this.tsbStartingPoint.Click += new System.EventHandler(this.tsb_click);
            // 
            // tsbEndingPoint
            // 
            this.tsbEndingPoint.CheckOnClick = true;
            this.tsbEndingPoint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbEndingPoint.Enabled = false;
            this.tsbEndingPoint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEndingPoint.Name = "tsbEndingPoint";
            this.tsbEndingPoint.Size = new System.Drawing.Size(23, 36);
            this.tsbEndingPoint.Text = "Sortie";
            this.tsbEndingPoint.Click += new System.EventHandler(this.tsb_click);
            // 
            // tsbWayPoint
            // 
            this.tsbWayPoint.CheckOnClick = true;
            this.tsbWayPoint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbWayPoint.Enabled = false;
            this.tsbWayPoint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbWayPoint.Name = "tsbWayPoint";
            this.tsbWayPoint.Size = new System.Drawing.Size(23, 36);
            this.tsbWayPoint.Text = "Cristal";
            this.tsbWayPoint.Click += new System.EventHandler(this.tsb_click);
            // 
            // tsbPitFall
            // 
            this.tsbPitFall.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPitFall.Enabled = false;
            this.tsbPitFall.Image = ((System.Drawing.Image)(resources.GetObject("tsbPitFall.Image")));
            this.tsbPitFall.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPitFall.Name = "tsbPitFall";
            this.tsbPitFall.Size = new System.Drawing.Size(36, 36);
            this.tsbPitFall.Text = "Trou";
            this.tsbPitFall.Click += new System.EventHandler(this.tsb_click);
            // 
            // tsbRock
            // 
            this.tsbRock.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRock.Enabled = false;
            this.tsbRock.Image = ((System.Drawing.Image)(resources.GetObject("tsbRock.Image")));
            this.tsbRock.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRock.Name = "tsbRock";
            this.tsbRock.Size = new System.Drawing.Size(36, 36);
            this.tsbRock.Text = "Rocher";
            this.tsbRock.Click += new System.EventHandler(this.tsb_click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripLabel2});
            this.toolStrip1.Location = new System.Drawing.Point(440, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.ShowItemToolTips = false;
            this.toolStrip1.Size = new System.Drawing.Size(200, 39);
            this.toolStrip1.TabIndex = 0;
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripLabel1.Size = new System.Drawing.Size(38, 36);
            this.toolStripLabel1.Text = "Seed :";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripLabel2.Size = new System.Drawing.Size(25, 36);
            this.toolStripLabel2.Text = "n/a";
            // 
            // toolStrip2
            // 
            this.toolStrip2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.toolStrip2.AutoSize = false;
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsddbTimesBetter});
            this.toolStrip2.Location = new System.Drawing.Point(640, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(400, 39);
            this.toolStrip2.TabIndex = 1;
            // 
            // tsddbTimesBetter
            // 
            this.tsddbTimesBetter.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsddbTimesBetter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsddbTimesBetter.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiLegend,
            this.tsmiAvecHCost,
            this.tsmiSansHCost});
            this.tsddbTimesBetter.Enabled = false;
            this.tsddbTimesBetter.Image = ((System.Drawing.Image)(resources.GetObject("tsddbTimesBetter.Image")));
            this.tsddbTimesBetter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsddbTimesBetter.Name = "tsddbTimesBetter";
            this.tsddbTimesBetter.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.tsddbTimesBetter.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tsddbTimesBetter.Size = new System.Drawing.Size(177, 36);
            this.tsddbTimesBetter.Text = "Informations Non Accessibles";
            this.tsddbTimesBetter.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tsmiLegend
            // 
            this.tsmiLegend.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsmiLegend.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsmiLegend.Enabled = false;
            this.tsmiLegend.Name = "tsmiLegend";
            this.tsmiLegend.Overflow = System.Windows.Forms.ToolStripItemOverflow.Always;
            this.tsmiLegend.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tsmiLegend.Size = new System.Drawing.Size(242, 22);
            this.tsmiLegend.Text = "Noeuds générés (dont explorés)";
            this.tsmiLegend.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tsmiLegend.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            // 
            // tsmiAvecHCost
            // 
            this.tsmiAvecHCost.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsmiAvecHCost.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsmiAvecHCost.Name = "tsmiAvecHCost";
            this.tsmiAvecHCost.Overflow = System.Windows.Forms.ToolStripItemOverflow.Always;
            this.tsmiAvecHCost.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tsmiAvecHCost.Size = new System.Drawing.Size(242, 22);
            this.tsmiAvecHCost.Text = "avec cout Heuristique : n/a(n/a)";
            this.tsmiAvecHCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tsmiAvecHCost.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.tsmiAvecHCost.MouseEnter += new System.EventHandler(this.tsmi_MouseEnter);
            this.tsmiAvecHCost.MouseLeave += new System.EventHandler(this.tsmi_MouseLeave);
            // 
            // tsmiSansHCost
            // 
            this.tsmiSansHCost.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsmiSansHCost.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsmiSansHCost.Name = "tsmiSansHCost";
            this.tsmiSansHCost.Overflow = System.Windows.Forms.ToolStripItemOverflow.Always;
            this.tsmiSansHCost.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tsmiSansHCost.Size = new System.Drawing.Size(242, 22);
            this.tsmiSansHCost.Text = "sans cout Heuristique : n/a(n/a)";
            this.tsmiSansHCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tsmiSansHCost.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.tsmiSansHCost.MouseEnter += new System.EventHandler(this.tsmi_MouseEnter);
            this.tsmiSansHCost.MouseLeave += new System.EventHandler(this.tsmi_MouseLeave);
            // 
            // SidePanel
            // 
            this.SidePanel.BackgroundImage = global::PathFinding_Robot.Properties.Resources.ProjetIA_Background;
            this.SidePanel.Controls.Add(this.ExerciceSelectionPanel);
            this.SidePanel.Controls.Add(this.rtbPath);
            this.SidePanel.Controls.Add(this.bAnimate);
            this.SidePanel.Controls.Add(this.bComputePath);
            this.SidePanel.Controls.Add(this.button1);
            this.SidePanel.Controls.Add(this.label1);
            this.SidePanel.Controls.Add(this.tbSeed);
            this.SidePanel.Location = new System.Drawing.Point(640, 0);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(400, 640);
            this.SidePanel.TabIndex = 1;
            // 
            // ExerciceSelectionPanel
            // 
            this.ExerciceSelectionPanel.BackColor = System.Drawing.Color.Transparent;
            this.ExerciceSelectionPanel.Controls.Add(this.rbExo3);
            this.ExerciceSelectionPanel.Controls.Add(this.rbExo2);
            this.ExerciceSelectionPanel.Controls.Add(this.rbExo1);
            this.ExerciceSelectionPanel.Location = new System.Drawing.Point(22, 22);
            this.ExerciceSelectionPanel.Name = "ExerciceSelectionPanel";
            this.ExerciceSelectionPanel.Size = new System.Drawing.Size(354, 75);
            this.ExerciceSelectionPanel.TabIndex = 7;
            // 
            // rbExo3
            // 
            this.rbExo3.AutoSize = true;
            this.rbExo3.ForeColor = System.Drawing.Color.White;
            this.rbExo3.Location = new System.Drawing.Point(7, 52);
            this.rbExo3.Name = "rbExo3";
            this.rbExo3.Size = new System.Drawing.Size(141, 17);
            this.rbExo3.TabIndex = 2;
            this.rbExo3.Text = "Déplacement de rochers";
            this.rbExo3.UseVisualStyleBackColor = true;
            // 
            // rbExo2
            // 
            this.rbExo2.AutoSize = true;
            this.rbExo2.ForeColor = System.Drawing.Color.White;
            this.rbExo2.Location = new System.Drawing.Point(7, 29);
            this.rbExo2.Name = "rbExo2";
            this.rbExo2.Size = new System.Drawing.Size(261, 17);
            this.rbExo2.TabIndex = 1;
            this.rbExo2.Text = "chemin le plus court passant par tous les éléments";
            this.rbExo2.UseVisualStyleBackColor = true;
            // 
            // rbExo1
            // 
            this.rbExo1.AutoSize = true;
            this.rbExo1.Checked = true;
            this.rbExo1.ForeColor = System.Drawing.Color.White;
            this.rbExo1.Location = new System.Drawing.Point(7, 6);
            this.rbExo1.Name = "rbExo1";
            this.rbExo1.Size = new System.Drawing.Size(203, 17);
            this.rbExo1.TabIndex = 0;
            this.rbExo1.TabStop = true;
            this.rbExo1.Text = "chemin le plus court entre deux points";
            this.rbExo1.UseVisualStyleBackColor = true;
            // 
            // rtbPath
            // 
            this.rtbPath.Location = new System.Drawing.Point(44, 193);
            this.rtbPath.Name = "rtbPath";
            this.rtbPath.ReadOnly = true;
            this.rtbPath.Size = new System.Drawing.Size(312, 359);
            this.rtbPath.TabIndex = 6;
            this.rtbPath.Text = "";
            // 
            // bAnimate
            // 
            this.bAnimate.Enabled = false;
            this.bAnimate.Location = new System.Drawing.Point(218, 591);
            this.bAnimate.Name = "bAnimate";
            this.bAnimate.Size = new System.Drawing.Size(90, 41);
            this.bAnimate.TabIndex = 5;
            this.bAnimate.Text = "Animer le chemin";
            this.bAnimate.UseVisualStyleBackColor = true;
            this.bAnimate.Click += new System.EventHandler(this.bAnimatePath_Click);
            // 
            // bComputePath
            // 
            this.bComputePath.Location = new System.Drawing.Point(98, 591);
            this.bComputePath.Name = "bComputePath";
            this.bComputePath.Size = new System.Drawing.Size(114, 41);
            this.bComputePath.TabIndex = 4;
            this.bComputePath.Text = "Calculer le chemin le plus court";
            this.bComputePath.UseVisualStyleBackColor = true;
            this.bComputePath.Click += new System.EventHandler(this.bComputePath_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(210, 119);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(173, 21);
            this.button1.TabIndex = 2;
            this.button1.Text = "Générer une nouvelle population";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.bGenerateMap_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(19, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Seed : ";
            // 
            // tbSeed
            // 
            this.tbSeed.Location = new System.Drawing.Point(66, 119);
            this.tbSeed.Name = "tbSeed";
            this.tbSeed.Size = new System.Drawing.Size(138, 20);
            this.tbSeed.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 640);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // bwComputePath
            // 
            this.bwComputePath.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bwComputePath_DoWork);
            this.bwComputePath.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bwComputePath_RunWorkerCompleted);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1040, 679);
            this.Controls.Add(this.toolStripContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStripContainer1.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.BottomToolStripPanel.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.Selecteur.ResumeLayout(false);
            this.Selecteur.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.SidePanel.ResumeLayout(false);
            this.SidePanel.PerformLayout();
            this.ExerciceSelectionPanel.ResumeLayout(false);
            this.ExerciceSelectionPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker bwAnimatePath;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbSeed;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton rbExo3;
        private System.Windows.Forms.RadioButton rbExo2;
        private System.Windows.Forms.RadioButton rbExo1;
        private System.Windows.Forms.Button bAnimate;
        private System.Windows.Forms.Button bComputePath;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.RichTextBox rtbPath;
        private System.Windows.Forms.ToolStrip Selecteur;
        private System.Windows.Forms.ToolStripButton tsbGround;
        private System.Windows.Forms.ToolStripButton tsbWall;
        private System.Windows.Forms.ToolStripButton tsbStartingPoint;
        private System.Windows.Forms.ToolStripButton tsbEndingPoint;
        private System.Windows.Forms.ToolStripButton tsbWayPoint;
        private System.Windows.Forms.ToolStripButton tsbPitFall;
        private System.Windows.Forms.ToolStripButton tsbRock;
        private System.ComponentModel.BackgroundWorker bwComputePath;
        private System.Windows.Forms.ToolStripDropDownButton tsddbTimesBetter;
        private System.Windows.Forms.ToolStripMenuItem tsmiLegend;
        private System.Windows.Forms.ToolStripMenuItem tsmiAvecHCost;
        private System.Windows.Forms.ToolStripMenuItem tsmiSansHCost;
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Panel ExerciceSelectionPanel;
    }
}

