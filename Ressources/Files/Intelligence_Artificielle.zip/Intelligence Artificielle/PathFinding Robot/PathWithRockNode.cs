﻿using ProjetIA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PathFinding_Robot
{
    class PathWithRockNode:TileNode
    {
        private coordonnee _rock;
        public coordonnee Rock
        {
            get { return _rock; }
            set { _rock = value; }
        }

        //fait appel a la class mere pour q ns rajoutions nos valeur a nous ensuite

        //constructeur
        public PathWithRockNode(Grille containingGrid, coordonnee c, coordonnee destination, coordonnee stone)
            : base(containingGrid,c,destination)
        {
            this._rock = stone;

            Name = position.ToString() + ":" + _rock.ToString();
        }

        //methodes
        public override double GetArcCost(GenericNode N2)
        {
            return 1;
        }
        public override bool EndState()
        {
            return _rock.Equals(destination);
        }
        public override List<GenericNode> GetListSucc()
        {
            List<GenericNode> listSucc = new List<GenericNode>();
            for (int i = 1; i < 9; i += 2)
            {
                int deltax = (i % 3) - 1;
                int deltay = (i / 3) - 1;
                //successeurs possibles
                coordonnee c = new coordonnee(position.x + deltax, position.y + deltay);
                //si mur, si ground,
                if (c.x < containingGrid.TailleX && c.x >= 0 && c.y < containingGrid.TailleY && c.y >= 0) // si dans la grille
                    if (containingGrid[c] != TypeCase.Unwalkable) // si nouvelle case marchable
                        if (c.Equals(_rock))
                        {
                            coordonnee stone=new coordonnee(_rock.x + deltax, _rock.y + deltay);
                            //mtn qon la bougé, on verifie qu'il peut vmt y marcher, ET qu'il est tjs dans la grille
                            if ((containingGrid[stone] != TypeCase.Unwalkable) && (stone.x < containingGrid.TailleX && stone.x >= 0 && stone.y < containingGrid.TailleY && stone.y >= 0)) // si nouvelle case marchable
                            {
                                //creation de la nouvelle position du cailloux et donc on le met en paramètre!
                                listSucc.Add(new PathWithRockNode(containingGrid,c,destination,stone));
                            }
                            
                        }
                        else
                        {
                            //rock car le cailloux n'a pas bougé de place
                            listSucc.Add(new PathWithRockNode(containingGrid, c, destination, _rock));
                        }

            }
            return listSucc;
        }

        public override void CalculeHCost()
        {
            List<coordonnee> lBlocked = new List<coordonnee>();
            for (int i = 1; i < 9; i += 2)
            {
                int deltax = (i % 3) - 1;
                int deltay = (i / 3) - 1;
                //c sont toutes les positions qu'il y a tout autour
                coordonnee c = new coordonnee(Rock.x + deltax, Rock.y + deltay);
                if(containingGrid[c] == TypeCase.Unwalkable)
                    lBlocked.Add(c);
            }

            bool canMove = false;
            //compte le nb de casses bloquees autour du stone
            switch (lBlocked.Count)
            {
                case 0:
                case 1:
                    canMove = true;
                    break;
                case 2:
                    if (Math.Abs(lBlocked[0].x - lBlocked[1].x) == 2 || Math.Abs(lBlocked[0].y - lBlocked[1].y) == 2)
                        //peut faire le calcul heuristique
                        canMove = true;
                    break;

                default: // on a au moins 3 cases dans la liste des cases non marchables
                    canMove = false;
                    break;
            }

            //canMove = true;
            if(canMove)
            {
                //calcul des heuristiques
                //HCost = Math.Abs(position.x - destination.x) + Math.Abs(position.y - destination.y);
                 //cout pour aller à la pierre
                int costFetchStone = position.Distance(_rock) - 1;
                int costStoneDest = _rock.Distance(destination);
                HCost = costFetchStone + costStoneDest;

                //si changemnt à faire pour pousser l'obstacle
                if (_rock.x != destination.x && _rock.y != destination.y)
                    HCost += 2;

            }
            else
            {
                HCost = double.PositiveInfinity;
            }

            
        }


    }
}
