﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reconnaissance_de_formes
{
    public partial class Form1 : Form
    {

        private RecoForm Forme;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void ouvrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            OpenFileDialog fd = sender as OpenFileDialog;
            if (fd != null)
            {
                richTextBox1.Text = System.IO.File.ReadAllText(fd.FileName);
            }
        }

        private void btnInterpreterCode_Click(object sender, EventArgs e)
        {
            char[] delimiters = new char[] { '\r', '\n' };
            string[] lines = richTextBox1.Text.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

            List<String> relations = new List<String>();
            foreach (string line in lines)
            {
                String s = line.Split('#')[0];
                if (s != "")
                {
                    relations.Add(s);
                }
            }

            Forme = new RecoForm(relations.ToArray());
            this.pictureBox1.Image = CreateGraphImage(Forme);
            tBResultat.Text = Forme.GetNumber().ToString();
            tBRelations.Text = Forme.GetNbRelations().ToString();
            tBextremitees.Text = Forme.GetNbExtremites().ToString();

            Console.WriteLine(Forme.ToString());
        }

        private Image CreateGraphImage(RecoForm Forme)
        {

            return new Bitmap(100, 100);
        }
    }
}
