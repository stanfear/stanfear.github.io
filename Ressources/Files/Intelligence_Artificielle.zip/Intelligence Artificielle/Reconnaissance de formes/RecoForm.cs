﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reconnaissance_de_formes
{
    class RecoForm
    {
        //FIELDS
        //nb d'éléments différents
        char[,] ma_matrice;
        // matrice avant simplification 
        char[,] matriceDonnee;

        //string pour avoir des etats n° ou lettres
        List<string> mes_noeuds;


        public char[,] MatriceInit { get { return (char[,])matriceDonnee.Clone(); } }
        public List<String> NomsNoeuds { get { return new List<string>(mes_noeuds);} }
        
        //CONSTRUCTORS
        public RecoForm(string[] mon_tableau)
        {
            
            mes_noeuds = new List<string>();
            for(int i=0; i< mon_tableau.Length;i++)
            {
                mon_tableau[i] = mon_tableau[i].Replace(" ", string.Empty);
                string[] temp = mon_tableau[i].Split(',');
                //ajoute le nom du noeud s'il n'y ai pas
                if (!mes_noeuds.Contains(temp[0]))
                {
                    mes_noeuds.Add(temp[0]);                
                }
                if (!mes_noeuds.Contains(temp[2]))
                {
                    mes_noeuds.Add(temp[2]);
                }
            }

            mes_noeuds.Sort();

            this.ma_matrice = new char[mes_noeuds.Count, mes_noeuds.Count];
            this.matriceDonnee = new char[mes_noeuds.Count, mes_noeuds.Count];
            //initialisation matrice
            for (int i = 0; i < ma_matrice.GetLength(0); i++)
            {
                for (int j = 0; j < ma_matrice.GetLength(1); j++)
                {
                    this.ma_matrice[i, j] = ' ';
                    this.matriceDonnee[i, j] = ' ';
                }
            }
            // on remplie la matrice avec les infomations de direction
            for (int i = 0; i < mon_tableau.Length; i++)
            {
                string[] temp = mon_tableau[i].Split(',');
                //on ajoute la relation dans la matrice
                int indexRelationFrom = this.mes_noeuds.IndexOf(temp[0]);
                int indexRelationTo = this.mes_noeuds.IndexOf(temp[2]);

                this.ma_matrice[indexRelationTo, indexRelationFrom] = temp[1][0];
                this.matriceDonnee[indexRelationTo, indexRelationFrom] = temp[1][0];
                
            }
            //la place de la relation = mes.noeuds.index 1 et de 2
            //ma_matrice[mes_noeuds.IndexOf(0), mes_noeuds(2)];
            this.simplifier();
        }
        
        //METHODS
        private void simplifier()
        {
            Dictionary<string, int> relations = GetNbRelationsNoeuds();
            foreach (KeyValuePair<string, int> noeud in relations.Where(Assos => Assos.Value == 2))
            {
                char[] res = GetRelations(noeud);
                if(res.Length == 2)// a priori l'autre cas ne devrait pas se présenter, mais pour être sûr, on verifie
                {
                    if(res[0] == res[1]) // les deux liens sont identiques, le noeud est inutile, on peut le retirer !
                    {
                        // clonage de la liste
                        List<string> listMesNoeudTemp = new List<string>();
                        listMesNoeudTemp.AddRange(this.mes_noeuds.ToArray());
                        // on retire de la nouvelle liste le noeud a supprimer
                        listMesNoeudTemp.Remove(noeud.Key);
                        listMesNoeudTemp.Sort();

                        // maintenant, on recopie dans une nouvelle matrice
                        char[,] MatriceTansitionTemp = new char[listMesNoeudTemp.Count, listMesNoeudTemp.Count];
                        //initialisation matrice
                        for (int i = 0; i < MatriceTansitionTemp.GetLength(0); i++)
                        {
                            for (int j = 0; j < MatriceTansitionTemp.GetLength(1); j++)
                            {
                                int index1 = mes_noeuds.IndexOf(listMesNoeudTemp[i]);
                                int index2 = mes_noeuds.IndexOf(listMesNoeudTemp[j]);

                                MatriceTansitionTemp[i, j] = this.ma_matrice[index1, index2];
                            }
                        }
                        // on vient de remplir la liste sans prendre en compte le noeud retiré, maintenant, on remet les liens.
                        // on trouve le noeud source de la relation a simplifier
                        int indexRelationFrom = 0;
                        while (indexRelationFrom < this.mes_noeuds.Count && // si on a pas dépassé et 
                              (indexRelationFrom == this.mes_noeuds.IndexOf(noeud.Key) || this.ma_matrice[this.mes_noeuds.IndexOf(noeud.Key), indexRelationFrom] == ' '))
                            indexRelationFrom++;
                        // on cherche maintenant le noeud cible
                        int indexRelationTo = 0;
                        while (indexRelationTo < this.mes_noeuds.Count && // si on a pas dépassé et 
                              (indexRelationTo == this.mes_noeuds.IndexOf(noeud.Key) || this.ma_matrice[indexRelationTo, this.mes_noeuds.IndexOf(noeud.Key)] == ' '))
                            indexRelationTo++;
                        // on complete la case !

                        if (this.mes_noeuds.IndexOf(noeud.Key) < indexRelationTo)// si la case concernée est après le noeud a retirer
                            indexRelationTo--;
                        if (this.mes_noeuds.IndexOf(noeud.Key) < indexRelationFrom)// si la case concernée est après le noeud a retirer
                            indexRelationFrom--;

                        MatriceTansitionTemp[indexRelationTo, indexRelationFrom] = res[0];


                        // on remplace la matrice et la liste des noeuds
                        this.ma_matrice = MatriceTansitionTemp;
                        this.mes_noeuds = listMesNoeudTemp;

                        // on appel la fonction en récursive (pour le chargement des connections)
                        simplifier();
                        // puis on sort de la boucle foreach
                        break;
                    }
                }
            }
        }
        private char[] GetRelations(KeyValuePair<string, int> noeud)
        {
            List<char> res = new List<char>();

            int index = this.mes_noeuds.IndexOf(noeud.Key);
            for (int j = 0; j < this.ma_matrice.GetLength(0); j++)
            {
                if (this.ma_matrice[index, j] != ' ')
                    res.Add(this.ma_matrice[index, j]);
                if (this.ma_matrice[j, index] != ' ')
                    res.Add(this.ma_matrice[j, index]);
            }
            return res.ToArray();
        }
        /// <summary>
        /// Cherche le nb de relations dans une forme
        /// </summary>
        /// <returns>Renvoie le nombre de relations de la forme</returns>
        public int GetNbRelations()
        {
            //peut Aussi récupérer le nombre membres que contient ma_direction
            //puisqu'elle a toutes les relations qu'elle a juste a remplir dans le nouveau tableau
            int cpt = 0;
            foreach (char c in this.ma_matrice)    
            {
                if (c != ' ')
                    cpt++;
            }
            //cherche si on a d ou b dans notre matrice
            return cpt;
        }
        public int GetNbExtremites() 
        {
            Dictionary<string, int> relations = GetNbRelationsNoeuds();
            return relations.Count(Assos => Assos.Value == 1);
        }
        private Dictionary<string, int> GetNbRelationsNoeuds()
        {
            Dictionary<string, int> dico = new Dictionary<string, int>();

            for (int i = 0; i < this.mes_noeuds.Count; i++)
            {
                int cpt = 0;
                for (int j = 0; j < this.ma_matrice.GetLength(0); j++)
                {
                    // la matrice est carrée donc on peut verifier les deux dimentions dans la même boucle
                    if (this.ma_matrice[i, j] != ' ')
                        cpt++;
                    if (this.ma_matrice[j, i] != ' ')
                        cpt++;
                }
                dico.Add(this.mes_noeuds[i], cpt);
            }

            return dico;
        }
        public override string ToString()
        {
            string res = "";
            res += "\t";
            foreach (string nomnoeud in this.mes_noeuds)
            {
                res += nomnoeud + "|";
            }
            res += "\n";

            for (int i = 0; i < ma_matrice.GetLength(0); i++)
            {
                res += this.mes_noeuds[i] + "\t";
                for (int j = 0; j < ma_matrice.GetLength(1); j++)
                {
                    res += this.ma_matrice[i, j] + "|";
                }
                res += "\n";
            }
            return res;
        }

        public int GetNumber()
        {
            int nbRelations = GetNbRelations();

            switch (nbRelations)
            {
                case 1 :
                    return 1;
                case 4 :
                    int nbExtremites = GetNbExtremites();
                    switch (nbExtremites)
                    {
                        case 0:
                            return 0;
                        case 3 :
                            return 4;
                        default:
                            return -1;
	                }
                case 5:
                    nbExtremites = GetNbExtremites();
                    switch (nbExtremites)
                    {
                        case 2:
                            return 2;
                        case 3:
                            return 3;
                        default:
                            return -1;
                    }
                default:
                    return -1;
            } 
        }
    }
}
