﻿using Apprentissage.supervise;
using Apprentissage;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apprentissage
{
    public partial class Form1 : Form
    {
        ClasseCreator cc1, cc2;
        internal NuagePoint np;
        UserControl learningMachineOption;

        public Form1()
        {
            InitializeComponent();
            cc1 = new ClasseCreator();
            cc1.initDefault(new PointF(-0.5F, -0.25F), 1D, 0.05D, 1);
            cc1.Location = new Point(12, 12);
            this.Controls.Add(cc1);
            cc2 = new ClasseCreator();
            cc2.initDefault(new PointF(0.5F, 0.25F), 1D, 0.05D, 0);
            cc2.Location = new Point(287, 12);
            this.Controls.Add(cc2);

            cc1.bValidate.Click += GenerateNuagePoint;
            cc2.bValidate.Click += GenerateNuagePoint;

            this.cbExoType.SelectedIndex = 0;
        }

        private void GenerateNuagePoint(object sender, EventArgs e)
        {
            np = new NuagePoint();
            ClassePoints c1, c2;
            Random r = new Random();
            c1 = new ClassePoints(500, 0, cc1.Angle, cc1.Rayon, cc1.Sigma, cc1.Center, Color.Blue, r.Next());
            c2 = new ClassePoints(500, 0, cc2.Angle, cc2.Rayon, cc2.Sigma, cc2.Center, Color.Red, r.Next());
            np.addClasse(c1);
            np.addClasse(c2);

            this.pbNuagePoints.Image = np.CreateImage((int)(pbNuagePoints.Width/1.5), (int)(pbNuagePoints.Height/1.5));

            Dictionary<PointF, int> ei = np.EnsemblePointsClasses;
        }

        private void Apprendre_Click(object sender, EventArgs e)
        {
            double alpha;
            int nbIteration;
            if (!double.TryParse(this.tbAlpha.Text, out alpha))
                return; 
            if (!Int32.TryParse(this.textBox2.Text, out nbIteration))
                return;


            this.button2.Enabled = false;
            this.Invalidate();


            int largeur = (int)(pbNuagePoints.Width / 1.5);
            int hauteur = (int)(pbNuagePoints.Height / 1.5);
            Bitmap pointCloudPic = new Bitmap(largeur, hauteur);
            int ErrorClass0, ErrorClass1;


            if (this.cbExoType.SelectedIndex == 0)
            {
                (learningMachineOption as PerceptronOptions).Apprendre(nbIteration, alpha, np, ref pointCloudPic, out ErrorClass0, out ErrorClass1);
                this.label5.Text = String.Format("{0} elements mal catégorisé ({3}%) \n\t- {1} appartenant à la classe 0 ({4}%)\n\t- {2} appartenant à la classe 1 ({5}%)", 
                    ErrorClass0 + ErrorClass1,
                    ErrorClass0,
                    ErrorClass1,
                    (ErrorClass0 + ErrorClass1) * 100 / np.EnsemblePointsClasses.Count,
                    ErrorClass0*100/np.Classes[0].Points.Count,
                    ErrorClass1*100/np.Classes[1].Points.Count
                    );
            }
            else
            {
                (learningMachineOption as CarteSOMOption).Apprendre(nbIteration, alpha, ref pointCloudPic);
                this.label5.Text = String.Format("Apprentissage effectué, \nutilisez \"regoupement\" \npour obtenir les statistiques");
            }

            this.pbNuagePoints.Image = pointCloudPic;
            this.button2.Enabled = true;  
        }

        private void cbExoType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (np == null)
                GenerateNuagePoint(sender, e);
            if (np == null) // erreur lors de la création du nuage de points
                return;
            switch ((sender as ComboBox).SelectedIndex)
            {
                case 0:
                    learningMachineOption = new PerceptronOptions();
                    this.button1.Hide();
                    break;
                case 1:
                    learningMachineOption = new CarteSOMOption(np);
                    this.button1.Show();
                    break;
                default:
                    learningMachineOption = new PerceptronOptions();
                    this.button1.Hide();
                    break;
	        }
            if (LearningMachineOptionPanel.Controls.Count > 1)
                LearningMachineOptionPanel.Controls.RemoveAt(1);
            LearningMachineOptionPanel.Controls.Add(learningMachineOption);
            learningMachineOption.Location = new Point(3, 43);

        }

        private void Regroupement_Click(object sender, EventArgs e)
        {



            if (cbExoType.SelectedIndex != 1)
                return;


            int largeur = (int)(pbNuagePoints.Width / 1.5);
            int hauteur = (int)(pbNuagePoints.Height / 1.5);
            Bitmap pointCloudPic = new Bitmap(largeur, hauteur);
            int ErrorClass0, ErrorClass1;

            if ((learningMachineOption as CarteSOMOption).IsInitiated)
                (learningMachineOption as CarteSOMOption).Regrouppement(np, ref pointCloudPic, out ErrorClass0, out ErrorClass1);
            else
                return;

            this.label5.Text = String.Format("{0} elements mal catégorisé ({3}%) \n\t- {1} appartenant à la classe 0 ({4}%)\n\t- {2} appartenant à la classe 1 ({5}%)",
                ErrorClass0 + ErrorClass1,
                ErrorClass0,
                ErrorClass1,
                (ErrorClass0 + ErrorClass1) * 100 / np.EnsemblePointsClasses.Count,
                ErrorClass0 * 100 / np.Classes[0].Points.Count,
                ErrorClass1 * 100 / np.Classes[1].Points.Count
                );

            this.pbNuagePoints.Image = pointCloudPic;
        }

    }
}
