﻿namespace Apprentissage
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbNuagePoints = new System.Windows.Forms.PictureBox();
            this.LearningMachineOptionPanel = new System.Windows.Forms.Panel();
            this.cbExoType = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbAlpha = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbNuagePoints)).BeginInit();
            this.LearningMachineOptionPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbNuagePoints
            // 
            this.pbNuagePoints.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbNuagePoints.Location = new System.Drawing.Point(12, 164);
            this.pbNuagePoints.Name = "pbNuagePoints";
            this.pbNuagePoints.Size = new System.Drawing.Size(562, 415);
            this.pbNuagePoints.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbNuagePoints.TabIndex = 0;
            this.pbNuagePoints.TabStop = false;
            // 
            // LearningMachineOptionPanel
            // 
            this.LearningMachineOptionPanel.Controls.Add(this.cbExoType);
            this.LearningMachineOptionPanel.Location = new System.Drawing.Point(574, 12);
            this.LearningMachineOptionPanel.Name = "LearningMachineOptionPanel";
            this.LearningMachineOptionPanel.Size = new System.Drawing.Size(200, 207);
            this.LearningMachineOptionPanel.TabIndex = 2;
            // 
            // cbExoType
            // 
            this.cbExoType.FormattingEnabled = true;
            this.cbExoType.Items.AddRange(new object[] {
            "Apprentissage Supervisé",
            "Apprentissage non Supervisé"});
            this.cbExoType.Location = new System.Drawing.Point(11, 10);
            this.cbExoType.Name = "cbExoType";
            this.cbExoType.Size = new System.Drawing.Size(182, 21);
            this.cbExoType.TabIndex = 10;
            this.cbExoType.SelectedIndexChanged += new System.EventHandler(this.cbExoType_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(585, 333);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(169, 50);
            this.button2.TabIndex = 8;
            this.button2.Text = "Apprendre !";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Apprendre_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(654, 292);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(103, 20);
            this.textBox2.TabIndex = 7;
            this.textBox2.Text = "10000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(582, 276);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "exemples par apprentissage :";
            // 
            // tbAlpha
            // 
            this.tbAlpha.Location = new System.Drawing.Point(654, 253);
            this.tbAlpha.Name = "tbAlpha";
            this.tbAlpha.Size = new System.Drawing.Size(103, 20);
            this.tbAlpha.TabIndex = 5;
            this.tbAlpha.Text = "0,05";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(582, 237);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Alpha (coefficient d\'apprentissage) :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(582, 386);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(197, 39);
            this.label5.TabIndex = 9;
            this.label5.Text = "1000 elements mal catégorisé (100%)\r\n   - 500 appartenant à la classe 0 (100%)\r\n " +
    "  - 500 appartenant à la classe 1 (100%)";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(592, 503);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(172, 24);
            this.button1.TabIndex = 10;
            this.button1.Text = "Regroupement";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Regroupement_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 591);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.LearningMachineOptionPanel);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.pbNuagePoints);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbAlpha);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbNuagePoints)).EndInit();
            this.LearningMachineOptionPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbNuagePoints;
        private System.Windows.Forms.Panel LearningMachineOptionPanel;
        private System.Windows.Forms.TextBox tbAlpha;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbExoType;
        private System.Windows.Forms.Button button1;
    }
}

