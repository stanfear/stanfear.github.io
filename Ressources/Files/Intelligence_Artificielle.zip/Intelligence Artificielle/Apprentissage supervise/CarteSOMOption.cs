﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Apprentissage.NonSupervise;

namespace Apprentissage
{
    public partial class CarteSOMOption : UserControl
    {
        CarteSOM cSOM = null;
        NuagePoint np = null;

        public CarteSOMOption()
        {
            InitializeComponent();
        }
        internal CarteSOMOption(NuagePoint np) : this()
        {
            this.np = np;
        }


        private void bInitReseau_Click(object sender, EventArgs e)
        {
            this.bInitReseau.Text = "Réinitialiser le reseau";

            int nblignes;
            if (!Int32.TryParse(this.tbNBlignes.Text, out nblignes))
            {
                this.bInitReseau.Text = "initialiser le reseau";
                return;
            }
            int nbcolonnes;
            if (!Int32.TryParse(this.tbNBcolonnes.Text, out nbcolonnes))
            {
                this.bInitReseau.Text = "initialiser le reseau";
                return;
            }

            IsInitiated = true;
            cSOM = new CarteSOM(nbcolonnes, nblignes,2, this.np.RightMost.X, this.np.LeftMost.X);
            np = (this.Parent.Parent as Form1).np;
        }

        internal void Apprendre(int nbIteration, double alpha, ref Bitmap pointCloudPic)
        {
            List<Observation> lobs = np.ListObs;

            if (cSOM == null)
                bInitReseau_Click(this, EventArgs.Empty);
            if(cSOM == null)
                return;

            cSOM.AlgoKohonen(lobs, alpha); // apprentissage


            int largeur = pointCloudPic.Width;
            int hauteur = pointCloudPic.Height;

            float uniteX = (largeur - 1) / (np.RightMost.X - np.LeftMost.X);
            float uniteY = (hauteur - 1) / (np.DownMost.Y - np.UpMost.Y);

            Graphics g = Graphics.FromImage(pointCloudPic);

            // création de l'image de sortie -> observations
            for (int i = 0; i < lobs.Count; i++)
            {
                pointCloudPic.SetPixel((int)((lobs[i].Getx() - np.LeftMost.X) * uniteX), (int)((lobs[i].Gety() - np.UpMost.Y) * uniteY), Color.Black);
            }
            // création de l'image de sortie -> neurones
                      
            int x, y;
            Pen pen = new Pen(Color.Blue);

            for (int i = 0; i < cSOM.Colonnes; i++)
                for (int j = 0; j < cSOM.Lignes; j++)
                {
                    x = (int)((cSOM.GetNeurone(i, j).GetPoids(0) - np.LeftMost.X) * uniteX);
                    y = (int)((cSOM.GetNeurone(i, j).GetPoids(1) - np.UpMost.Y) * uniteY);
                    g.DrawEllipse(pen, x - 2, y - 2, 4, 4);
                }
        }


        public bool IsInitiated { get; set; }

        internal void Regrouppement(NuagePoint np, ref Bitmap pointCloudPic, out int ErrorClass0, out int ErrorClass1)
        {

            List<Observation> lobs = np.ListObs;
            // Regroupement pour obtenir 2 classes
            List<Classe> lisClasse = cSOM.regroupement(np.ListObs, 2);

            int largeur = pointCloudPic.Width;
            int hauteur = pointCloudPic.Height;

            float uniteX = (largeur - 1) / (np.RightMost.X - np.LeftMost.X);
            float uniteY = (hauteur - 1) / (np.DownMost.Y - np.UpMost.Y);

            Graphics g = Graphics.FromImage(pointCloudPic);

            // création de l'image de sortie -> observations
            for (int i = 0; i < lobs.Count; i++)
            {
                pointCloudPic.SetPixel((int)((lobs[i].Getx() - np.LeftMost.X) * uniteX), (int)((lobs[i].Gety() - np.UpMost.Y) * uniteY), Color.Black);
            }


            #region coloriage des plages de points
            for (int i = 0; i < hauteur; i++)
            {
                for (int j = 0; j < largeur; j++)
                {
                    Color col;
                    Observation obs = new Observation((j / uniteX) + np.LeftMost.X, (i / uniteY) + np.UpMost.Y);
                    if (cSOM.Evaluate(obs, lisClasse) == 0)
                        col = Color.Green;
                    else // if == 0
                        col = Color.Orange;
                    Rectangle rect = new Rectangle(j, i, 1, 1);
                    Brush br = new SolidBrush(Color.FromArgb(100, col));
                    g.FillRectangle(br, rect);
                }
            }
            #endregion

            #region affichage des neurones
            // Affichage final des 2 classes
            int x, y;
            Pen pen = new Pen(Color.Green);
            foreach (Neurone n in lisClasse[0].GetNeurones())
            {
                x = (int)((n.GetPoids(0) - np.LeftMost.X) * uniteX);
                y = (int)((n.GetPoids(1) - np.UpMost.Y) * uniteY);
                g.DrawEllipse(pen, x - 2, y - 2, 4, 4);
            }

            pen.Color = Color.Orange;
            foreach (Neurone n in lisClasse[1].GetNeurones())
            {
                x = (int)((n.GetPoids(0) - np.LeftMost.X) * uniteX);
                y = (int)((n.GetPoids(1) - np.UpMost.Y) * uniteY);
                g.DrawEllipse(pen, x - 2, y - 2, 4, 4);
            }
            #endregion


            ErrorClass0 = 0;
            ErrorClass1 = 0;

            foreach (Observation obs in np.ListObs)
            {
                Color col;
                if (cSOM.Evaluate(obs, lisClasse) == 0)
                {
                    col = Color.Green;
                    if (np.EnsemblePointsClasses[new PointF((float)obs.Getx(), (float)obs.Gety())] != 0) // mal placé -> erreur
                        ErrorClass0++;
                }
                else // if == 1
                {
                    col = Color.Orange;
                    if (np.EnsemblePointsClasses[new PointF((float)obs.Getx(), (float)obs.Gety())] != 1)
                        ErrorClass1++;
                }
                pointCloudPic.SetPixel((int)((obs.Getx() - np.LeftMost.X) * uniteX), (int)((obs.Gety() - np.UpMost.Y) * uniteY), col);
            }
        }
    }
}
