﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apprentissage
{
    internal class NuagePoint
    {
        private List<ClassePoints> _classes;
        public List<ClassePoints> Classes
	    {
            get { return new List<ClassePoints>(_classes); }
	    }

        private PointF? um = null;
        private PointF? dm = null;
        private PointF? lm = null;
        private PointF? rm = null;

        public PointF UpMost
        {
            get
            {

                if (Classes.Count == 0)
                    throw new InvalidOperationException();
                if (um != null)
                    return (PointF)um;
                PointF p = Classes[0].UpMost;
                foreach (ClassePoints c in _classes)
                {
                    if (p.Y > c.UpMost.Y)
                        p = c.UpMost;
                }
                um = p;
                return p;
            }
        }
        public PointF DownMost
        {
            get
            {
                if (Classes.Count == 0)
                    throw new InvalidOperationException();
                if (dm != null)
                    return (PointF)dm;
                PointF p = Classes[0].DownMost;
                foreach (ClassePoints c in _classes)
                {
                    if (p.Y < c.DownMost.Y)
                        p = c.DownMost;
                }
                dm = p;
                return p;
            }
        }
        public PointF LeftMost
        {
            get
            {
                if (Classes.Count == 0)
                    throw new InvalidOperationException();
                if (lm != null)
                    return (PointF)lm;
                PointF p = Classes[0].LeftMost;
                foreach (ClassePoints c in _classes)
                {
                    if (p.X > c.LeftMost.X)
                        p = c.LeftMost;
                }
                lm = p;
                return p;
            }
        }
        public PointF RightMost
        {
            get
            {
                if (Classes.Count == 0)
                    throw new InvalidOperationException();
                if (rm != null)
                    return (PointF)rm;
                PointF p = Classes[0].RightMost;
                foreach (ClassePoints c in _classes)
                {
                    if (p.X < c.RightMost.X)
                        p = c.RightMost;
                }
                rm = p;
                return p;
            }
        }

        public Dictionary<PointF, int> EnsemblePointsClasses
        {
            get
            {
                Dictionary<PointF, int> res = new Dictionary<PointF, int>();
                int i = 0;
                foreach (ClassePoints item in _classes)
                {
                    foreach (PointF p in item.Points)
                    {
                        if (!res.ContainsKey(p))
                            res.Add(p, i);
                    }
                    i++;
                }
                Random rand = new Random();
                res = res.OrderBy(x => rand.Next())
                  .ToDictionary(item => item.Key, item => item.Value);
                return res;
            }
        }

        public NuagePoint() 
        {
            _classes = new List<ClassePoints>();
        }

        public void addClasse(ClassePoints c)
        {
            _classes.Add(c);
        }

        public Bitmap CreateImage(int largeur, int hauteur)
        {
            Bitmap Res = new Bitmap(largeur, hauteur);
            float uniteX = (largeur - 1) / (RightMost.X - LeftMost.X);
            float uniteY = (hauteur - 1) / (DownMost.Y - UpMost.Y);
            
            foreach (ClassePoints item in this._classes)
            {
                foreach (PointF point in item.Points)
                {
                    Res.SetPixel((int)((point.X - LeftMost.X) * uniteX), (int)((point.Y - UpMost.Y) * uniteY), item.Couleur);
                }                
            }
            return Res;
        }

        public List<NonSupervise.Observation> ListObs
        {
            get
            {
                List<NonSupervise.Observation> Res = new List<NonSupervise.Observation>();

                foreach (ClassePoints item in _classes)
                {
                    foreach (PointF p in item.Points)
                    {
                        NonSupervise.Observation obs = new NonSupervise.Observation(p.X, p.Y);
                            Res.Add(obs);
                    }
                }


                return Res;
            }
        }
    }
}
