﻿using System;
using System.Collections.Generic;
using System.Drawing;

using System.Windows.Forms;

namespace Apprentissage.supervise
{
    class Reseau
    {
        Random rnd = new Random();
        //int nbcouches;
        List<Neurone> listeneurones;     // Liste des neurones du réseau
        List<Neurone>[] tabcouches;  // tableau des couches de neurones
        double[,] tabpoids;      // Matrice d'adjacence des poids synaptiques

        // Constructeur
        // On initialise un réseau de neurones à partir du nombre d'entrées, du nb de couches
        // et du nb de neurones par couche
        public Reseau(int nbentrees, int nbcouches, int neuronesparcouche)
        {
            int i, j, k, cpt;
            Neurone neurone;

            // Nombre de neurones
            // nbneurones= nbentrees+(nbcouches-2)*neuronesparcouche+1;
            // Initialisation des listes avant de poursuivre
            listeneurones = new List<Neurone>();
            tabcouches = new List<Neurone>[nbcouches];
            for (i = 0; i < nbcouches; i++)
            {
                tabcouches[i] = new List<Neurone>();
            }
            cpt = 0;
            for (i = 0; i < nbentrees; i++)
            {
                neurone = new Neurone(cpt++, 0);
                listeneurones.Add(neurone);
                tabcouches[0].Add(neurone);
            }
            // On fait les couches cachées :
            for (i = 1; i < nbcouches - 1; i++)
                for (j = 0; j < neuronesparcouche; j++)
                {
                    neurone = new Neurone(cpt++, i);
                    listeneurones.Add(neurone);
                    tabcouches[i].Add(neurone);
                    // Connexion avec neurones couche précédente
                    for (k = 0; k < tabcouches[i - 1].Count; k++)
                    {
                        tabcouches[i - 1][k].sorties.Add(neurone);
                        neurone.entrees.Add(tabcouches[i - 1][k]);
                    }
                }
            neurone = new Neurone(cpt++, nbcouches - 1);
            listeneurones.Add(neurone);
            tabcouches[nbcouches - 1].Add(neurone);
            // Connexion avec neurones couche précédente
            for (k = 0; k < tabcouches[nbcouches - 2].Count; k++)
            {
                tabcouches[nbcouches - 2][k].sorties.Add(neurone);
                neurone.entrees.Add(tabcouches[nbcouches - 2][k]);
            }

            // Initialisation de la matrice des poids synap. : 0= pas de synapse
            int nbneurones = listeneurones.Count;
            tabpoids = new double[nbneurones, nbneurones];
            Random rnd = new Random();
            for (i = 0; i < nbneurones; i++)
                for (j = 0; j < nbneurones; j++)
                    tabpoids[i, j] = rnd.NextDouble() * 2 - 1;

        }

        /*****************************************************************/
        public void ReInitializationActivation()
        {
            this.listeneurones.ForEach(n => n.ResetSortie());
        }

        //********************************************************************
        // Calcul de la sortie de tous les neurones d'une couche donnée
        // Méthode appelée par backprop
        public void ProcessLayerK(int k)
        {
            // Calcul de la somme des entrées pondérées par les poids
            // synaptiques + sigmoïde.
            tabcouches[k].ForEach(n => n.CalculeSortie(tabpoids));
        }

        //************************************************************/
        /*  Affichage des infos d'1 neurone */
        public void AfficheInfoNeurone(int couche, int num, ListBox lbox)
        {
            Neurone neurone, neurone2;
            int i;

            neurone = tabcouches[couche][num];
            lbox.Items.Add("Neurone " + Convert.ToString(neurone.GetNumero()));
            lbox.Items.Add("Somme :" + Convert.ToString(neurone.GetSomme()));
            lbox.Items.Add("Sortie :" + Convert.ToString(neurone.GetSortie()));
            lbox.Items.Add(Convert.ToString(neurone.entrees.Count) + " entrées :");
            for (i = 0; i < neurone.entrees.Count; i++)
            {
                neurone2 = neurone.entrees[i];
                lbox.Items.Add("Num.:" + Convert.ToString(neurone2.GetNumero())
                    + " Poids:" + Convert.ToString(tabpoids[neurone2.GetNumero(), neurone.GetNumero()]));
            }
            lbox.Items.Add(Convert.ToString(neurone.sorties.Count) + "sorties :");
            for (i = 0; i < neurone.sorties.Count; i++)
            {
                neurone2 = neurone.sorties[i];
                lbox.Items.Add("Num.:" + Convert.ToString(neurone2.GetNumero())
                    + " Poids:" + Convert.ToString(tabpoids[neurone.GetNumero(), neurone2.GetNumero()]));
            }

        }

        /*****************************************************************/
        // Calcul nécessaire pour backprop
        private double sommedelta(Neurone neur)
        {
            int i;
            Neurone neuronesucc;
            double somme;

            somme = 0;
            for (i = 0; i < neur.sorties.Count; i++)
            {
                neuronesucc = neur.sorties[i];
                somme = somme + tabpoids[neur.GetNumero(), neuronesucc.GetNumero()]
                                * neuronesucc.Getdelta();
            }
            return somme;
        }

        /******************************************************************/
        public void backprop(double alpha, int nbite, Dictionary<PointF, int> values)
        {
            int i, j, k, exemple;
            double x, z;
            Neurone neur, neursucc;
            int nbcouches = tabcouches.Length;
            Random rnd2 = new Random();

            // NbIte est le nombre d'itérations, cad le nombre d'exemples qu vont servir à l'apprentissage
            for (exemple = 0; exemple < nbite; exemple++)
            {

                int id = rnd.Next(values.Count);
                PointF[] tempP = new PointF[values.Count];
                values.Keys.CopyTo(tempP, 0);
                PointF key = tempP[id];
                int []tempC = new int[values.Count];
                values.Values.CopyTo(tempC,0);
                z = tempC[id];

                // Il faut imposer 1 en sortie du neurone associé à la constante qui est positionné
                // à la couche 0 (couche des entrées), au numéro 0
                neur = tabcouches[0][0];
                neur.ImposeSortie(1);
                // On impose x en sortie du neurone 1 de la couche 0
                neur = tabcouches[0][1];
                neur.ImposeSortie(key.X);
                neur = tabcouches[0][2];
                neur.ImposeSortie(key.Y);

                // Calcul de la sortie de chaque neurone
                for (k = 1; k < nbcouches; k++)
                    ProcessLayerK(k);

                neur = tabcouches[nbcouches - 1][0];
                //if (Math.Abs(neur.GetSortie() - z) > 0.1)     // on se focalise sur les sorties qui posent problème
                {
                    // Calcul du gradient et de la modification de chaque poids
                    //pour chaque neurone de sortie i faire; ici 1 seul neurone de sortie
                    for (i = 0; i < tabcouches[nbcouches - 1].Count; i++)
                    {
                        // ici 1 seul neurone de sortie, i varie entre 0 et 0 !
                        neur = tabcouches[nbcouches - 1][i];
                        neur.Setdelta( //(z - neur.sortie);
                                 neur.gprime(neur.GetSomme()) * (z - neur.GetSortie()));
                    }

                    // On redescend vers les couches les plus basses
                    for (k = nbcouches - 2; k > -1; k--)
                    {
                        // Pour chaque neurone de cette couche, on met à jour les poids
                        for (j = 0; j < tabcouches[k].Count; j++)
                        {
                            neur = tabcouches[k][j];
                            neur.Setdelta(neur.gprime(neur.GetSomme()) * sommedelta(neur));
                            // Mise à jour des poids entre j et les neurones i d'arrivée
                            for (i = 0; i < tabcouches[k + 1].Count; i++)
                            {
                                neursucc = tabcouches[k + 1][i];
                                tabpoids[neur.GetNumero(), neursucc.GetNumero()] =
                                  tabpoids[neur.GetNumero(), neursucc.GetNumero()]
                                   + alpha * neur.GetSortie() * neursucc.Getdelta();
                            }
                        }
                    }
                }
            }
        }


        public int ComputeClasse(PointF pf, double marge)
        {
            Neurone neurone;
            neurone = tabcouches[0][1];
            neurone.ImposeSortie(pf.X);
            neurone = tabcouches[0][2];
            neurone.ImposeSortie(pf.Y);


            // Calcul de la sortie de chaque neurone
            for (int k = 1; k < tabcouches.Length; k++)
                ProcessLayerK(k);

            neurone = tabcouches[tabcouches.Length - 1][0];

            return neurone.GetSortie() > 1 - marge ? 1 : 0;
        }

        /**********************************************************************/

        /***********************************************************************/
        /*public void Tests (  Graphics g, Bitmap bmp)
        {
            int k; 
            int x, val,z ; 
            double x2,z2;
            Neurone neur ;
            for (x = 0; x < bmp.Width; x++)
                for (z = 0; z < bmp.Height ; z++)
                    bmp.SetPixel(x, z, Color.Black);
            
          // On teste 200 exemples de x pris entre -100 et +100
          // En fait, x2 sera compris entre -100 et 100, x sera utilisé pour l'affichage entre 0 et 200
          for (x=0; x< 200; x++)
          {
             x2 = (x - 100.0)/100.0;
            // Initialisation des activations  ai correspondant aux entrées xi
            // Le premier neurone est une constante égale à 1
            neur = tabcouches[0][0];
            neur.ImposeSortie( 1);
            // Le 2ème neurone est l'entrée x
            neur = tabcouches[0][1];
            neur.ImposeSortie(x2);
            // Calcul de la sortie de chaque neurone
            for (k=1; k < tabcouches.Length; k++)
                ProcessLayerK(k);
            // Le neurone de sortie est le 1er de la dernière couche
            neur =  tabcouches[tabcouches.Length-1][0];
            // calcul de la sortie qu'il faudrait obtenir selon la fonction à apprendre
            z2 = fonctionmodele(x2);
            // z2 valeur attendu entre 0 et 1 ; conversion pour z qui est retenu pour l'affichage
            z = (int)(200*z2);                  //round((0.5-cos(x2*pi*2)/2));
            bmp.SetPixel(x,bmp.Height -z-1,Color.Yellow);
            val = (int)(neur.GetSortie()*200);
            bmp.SetPixel(x,bmp.Height -val-1,Color.White);
          }

        }*/
    }
}