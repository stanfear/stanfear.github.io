﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apprentissage
{
    class ClassePoints
    {
        private List<PointF> _points;

	    public List<PointF> Points
	    {
		    get { return new List<PointF>(_points);}
	    }

        public PointF LeftMost { get; set; }
        public PointF RightMost { get; set; }
        public PointF UpMost { get; set; }
        public PointF DownMost { get; set; }
        public Color Couleur { get; set; }

        public ClassePoints(int nbPoints, double angleDepart, double angleMax, double rayon, double ecartype, PointF Centre, Color c, int seed)
        {
            _points = new List<PointF>();

            this.Couleur = c;

            Random r = new Random(seed);
            RandomNormal rNrom = new RandomNormal(seed+1);

            double angle = (r.NextDouble() * (angleMax - angleDepart) + angleDepart);
            double distance = rNrom.NextDouble(rayon, ecartype);
            PointF p = new PointF((float)(distance * Math.Cos(angle)), (float)(distance * Math.Sin(angle)));
            _points.Add(p);

            UpMost = DownMost = RightMost = LeftMost = p;

            for (int i = 1; i < nbPoints; i++)
            {
                angle = (r.NextDouble() * (angleMax - angleDepart) + angleDepart);
                distance = rNrom.NextDouble(rayon, ecartype);
                p = new PointF((float) (distance * Math.Cos(angle) + Centre.X), (float) (distance * Math.Sin(angle) + Centre.Y));
                _points.Add(p);

                // mise a jour des points extrèmes 
                if (UpMost.Y > p.Y)
                    UpMost = p; 
                else if (DownMost.Y < p.Y)
                    DownMost = p;


                if (LeftMost.X > p.X)
                    LeftMost = p; 
                else if (RightMost.X < p.X)
                    RightMost = p;
            }
        }

    }
}
