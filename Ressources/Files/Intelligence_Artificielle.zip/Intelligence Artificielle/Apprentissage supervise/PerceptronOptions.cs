﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Apprentissage.supervise;

namespace Apprentissage
{
    public partial class PerceptronOptions : UserControl
    {

        Reseau r = null;
        public PerceptronOptions()
        {
            InitializeComponent();
        }

        private void bInitReseau_Click(object sender, EventArgs e)
        {
            this.bInitReseau.Text = "Réinitialiser le reseau";

            int nbcouche;
            if (!Int32.TryParse(this.tbNBcouches.Text, out nbcouche))
            {
                this.bInitReseau.Text = "initialiser le reseau";
                return;
            }
            int nbneuronescouche;
            if (!Int32.TryParse(this.tbNBneuroneCouche.Text, out nbneuronescouche))
            {
                this.bInitReseau.Text = "initialiser le reseau";
                return;
            }

            r = new Reseau(3,nbcouche, nbneuronescouche);
        }

        internal void Apprendre(int nbIteration, double alpha, NuagePoint np, ref Bitmap pointCloudPic, out int ErrorClass0, out int ErrorClass1)
        {
            ErrorClass0 = ErrorClass1 = -1;
            if (r == null)
                bInitReseau_Click(this, EventArgs.Empty);
            if (r == null) // une erreur a été rencontré dans l'initialisation du reseau
                return;

            r.backprop(alpha, nbIteration, np.EnsemblePointsClasses);

            int largeur = pointCloudPic.Width;
            int hauteur = pointCloudPic.Height;

            float uniteX = (largeur - 1) / (np.RightMost.X - np.LeftMost.X);
            float uniteY = (hauteur - 1) / (np.DownMost.Y - np.UpMost.Y);

            Graphics g = Graphics.FromImage(pointCloudPic);

            for (int i = 0; i < hauteur; i++)
            {
                for (int j = 0; j < largeur; j++)
                {
                    Color col;
                    PointF p = new PointF((j / uniteX) + np.LeftMost.X, (i / uniteY) + np.UpMost.Y);
                    if (r.ComputeClasse(p, 0.5) == 1)
                        col = Color.Green;
                    else // if == 0
                        col = Color.Orange;
                    Rectangle rect = new Rectangle(j, i, 1, 1);
                    Brush br = new SolidBrush(Color.FromArgb(100, col));
                    g.FillRectangle(br, rect);
                }
            }

            ErrorClass0 = 0;
            ErrorClass1 = 0;

            foreach (PointF p in np.EnsemblePointsClasses.Keys)
            {
                Color col;
                if (r.ComputeClasse(p, 0.5) == 0)
                {
                    col = Color.Orange;

                    if (np.EnsemblePointsClasses[p] != 0) // mal placé -> erreur
                        ErrorClass0++;
                }
                else // if == 1
                {

                    col = Color.Green;

                    if (np.EnsemblePointsClasses[p] != 1)
                        ErrorClass1++;
                }
                pointCloudPic.SetPixel((int)((p.X - np.LeftMost.X) * uniteX), (int)((p.Y - np.UpMost.Y) * uniteY), col);
            }
            pointCloudPic.Save("Nuage_de_point-" + DateTime.Now.ToString("MMMyyyy-HHmmss") + ".png", System.Drawing.Imaging.ImageFormat.Png);

        }
    }
}
