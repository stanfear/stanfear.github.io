﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apprentissage
{
    public partial class ClasseCreator : UserControl
    {
        public ClasseCreator()
        {
            InitializeComponent();
        }

        internal void initDefault(PointF pointF, double Rayon, double sigma, int direction)
        {
            this.Center = pointF;
            this.Rayon = Rayon;
            this.Sigma = sigma;
            this.comboBox1.SelectedIndex = direction;
        }

        public PointF Center 
        {
            get
            {
                PointF pf = new PointF();
                float temp;
                this.centerX.Text.Replace('.', ',');
                float.TryParse(this.centerX.Text, out temp);
                pf.X = temp;
                this.centerY.Text.Replace('.', ',');
                float.TryParse(this.centerY.Text, out temp);
                pf.Y = temp;
                return pf;
            }
            set
            {
                this.centerX.Text = value.X.ToString();
                this.centerY.Text = value.Y.ToString();
            }
        }

        public double Rayon 
        { 
            get
            {
                double temp;
                this.rayon.Text.Replace('.', ',');
                double.TryParse(this.rayon.Text, out temp);
                return temp;
            }
            set
            {
                this.rayon.Text = value.ToString();
            }
        }

        public double Sigma
        {
            get
            {
                double temp;
                this.sigma.Text.Replace('.', ',');
                double.TryParse(this.sigma.Text, out temp);
                return temp;
            }
            set
            {
                this.sigma.Text = value.ToString();
            }
        }

        public double Angle { 
            get
            {
                return this.comboBox1.SelectedIndex == 0 ? -Math.PI : Math.PI;
            }
        }
    }
}
