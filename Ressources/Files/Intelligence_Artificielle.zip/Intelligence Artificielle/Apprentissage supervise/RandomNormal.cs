﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apprentissage
{
    class RandomNormal : Random
    {
        public RandomNormal(int seed) : base(seed)
        {

        }

        public double NextDouble(double mu,double sigma)
        {
            double u1 = this.NextDouble();
            double u2 = this.NextDouble();

            double T = Math.Sqrt(-2 * Math.Log(u1)) * Math.Cos(2 * Math.PI * u2);
            return mu + sigma * T;
        }
    }
}
