%%%%%%%%%%%%%%%%%%%%%%%%%%
%% AFFICHAGE DE LA MAIN %%
%%%%%%%%%%%%%%%%%%%%%%%%%%

%affichage de la carte
printCarte(carte(Famille, Rang)) :- write(' '), writeln(Famille),write(' | '), writeln(Rang).
printCarte(carte(Famille, Rang), Famille) :- write(' | '), writeln(Rang),!.
printCarte(carte(Famille, Rang), _) :- printCarte(carte(Famille, Rang)).

% affichage d'une liste de cartes
printMain([]) :-!.
printMain([C|ResteJeu]) :- sort([C|ResteJeu], [carte(F, R)|RJ]),
											  printCarte(carte(F, R)),
											  printMain(RJ,F).
printMain([],_):-!.
printMain([carte(Famille, Rang)|ResteJeu], FamilleCartePrecedente) :- printCarte(carte(Famille, Rang), FamilleCartePrecedente), 
																	  printMain(ResteJeu, Famille).

montrerJeu(JActuel) :- jeux(JActuel, J1),
					   nl, write('Votre Jeux : '), nl,
					   printMain(J1).
									
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PROMPT DE SAISIE DE LA CARTE A DEMANDER %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% prompt
promptDemanderCarte(Famille, Rang) :- write('Dans la famille : '),
                                      read(Famille), 
                                      write('je demande : '),
                                      read(Rang),
                                      carte(Famille, Rang).

demanderCarteValide(carte(Famille, Rang), JActuel) :-
			jeux(JActuel, J1),
			repeat, % tant que la carte saisie n'est pas valide
				promptDemanderCarte(Famille, Rang),
				verifFamilleRangExiste(Famille, Rang),
				verifFamillePresenteJeu(Famille, J1),
			!.% fin tant que

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% AFFICHAG DE FIN DE PARTIE %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

afficherVictoire(P1,P2) :- points(P1,PointsJ1), points(P2,PointsJ2), PointsJ1 > PointsJ2, !, 
						   write('Bravo, vous avez gagné !! (score : '), write(PointsJ1), write(' à '), write(PointsJ2),write(')').
afficherVictoire(P1,P2) :- points(P1,PointsJ1), points(P2,PointsJ2),
						   write('Dommage !, vous avez perdu ! (score : '), write(PointsJ1), write(' à '), write(PointsJ2),write(')').


%%%%%%%%%%%%%%%%%%%%%%%%%%
%% AFFICHAGE INFORMATIF %%
%%%%%%%%%%%%%%%%%%%%%%%%%%

printDemander(ia, Carte) :- printDemander('[IA] : ', Carte), !.
printDemander(h, Carte) :- printDemander('[VOUS] : ', Carte), !.

printDemander(TEXT, carte(F,R)) :- nl,nl, write(TEXT),
								   write('Dans la famille '), write(F), 
								   write(', Je demande le '), write(R), nl,nl.

printPiocheVide :- write('[SYSTEM] : plus de carte dans la pioche'),nl.

printBonnePioche(C) :- write('Pioche !'), nl, 
					   write('Carte Piochée : '),nl,
					   printCarte(C), nl,
					   write('Bonne pioche !'),nl,nl.
printMauvaisePioche :- write('Pioche !'), nl,
						  write('Mauvaise pioche !'),nl,nl.

printDebutTour(J) :- write('--------------------'),nl,
					 write('-------'), write(J), write('-------'),nl,
					 write('--------------------'),nl.
