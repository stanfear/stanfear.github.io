:- consult('utilitaires.pl').
:- consult('definitions.pl').
:- consult('interactions.pl').
:- consult('moteurJeux.pl').
:- consult('actionsJeux.pl').

:- dynamic(jeux/2).
:- dynamic(points/2).

main :- retractall(jeux(_,_)),
        retractall(points(_,_)),
        genererJeux(P,J1,J2),
        writeln('votre jeux :'),
        printMain(J1),
        nl,
        writeln('jeux de l''adversaire :'),
        printMain(J2),
        nl,nl,nl,nl,

        asserta(jeux(pioche, P)),
        asserta(jeux(jh, J1)),
        asserta(jeux(jia, J2)),

        jeux(Joueur1, J1),
        jeux(Joueur2, J2),

        asserta(points(Joueur1, 0)),
        asserta(points(Joueur2, 0)),

        jouer(Joueur1,Joueur2,pioche),

        afficherVictoire(Joueur1,Joueur2).