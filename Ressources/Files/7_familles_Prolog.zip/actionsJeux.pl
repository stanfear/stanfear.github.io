%%%%%%%%%%%%%%%%%%%%%%%%%
%% TOUR DE JEUX HUMAIN %%
%%%%%%%%%%%%%%%%%%%%%%%%%

% tourJeuxHumain/3
tourJeuxHumain(JActuel,JAdverse,Pioche) :- tourJeuxHumain(JActuel, JAdverse, Pioche, true).
% tourJeuxHumain/4
tourJeuxHumain(JActuel,JAdverse,Pioche, _) :- jeux(JActuel, []), jeux(JAdverse, []), jeux(Pioche, []),!.
tourJeuxHumain(_,_,_, false) :- !.
tourJeuxHumain(JActuel,JAdverse,Pioche, true) :-  initTour(JActuel,JAdverse,Pioche),
												  montrerJeu(JActuel),

												  demanderCarteValide(Carte, JActuel),
												  printDemander(h, Carte),

												  demander(Carte, JActuel,JAdverse,Pioche, Rejouer),
												  viderFamille(JActuel),
												  tourJeuxHumain(JActuel,JAdverse,Pioche, Rejouer).

% tourJeuxIA/3
tourJeuxIA(JActuel,JAdverse,Pioche) :- tourJeuxIA(JActuel,JAdverse,Pioche, true).
% tourJeuxIA/4
tourJeuxIA(JActuel,JAdverse,Pioche, _) :- jeux(JActuel, []), jeux(JAdverse, []), jeux(Pioche, []),!.
tourJeuxIA(_,_,_, false) :- !.
tourJeuxIA(JActuel,JAdverse,Pioche, true) :-  initTour(JActuel,JAdverse,Pioche),

											  choisirCarteIA(Carte, JActuel),
											  printDemander(ia, Carte),

											  demander(Carte, JActuel,JAdverse,Pioche, Rejouer),
											  viderFamille(JActuel),
											  tourJeuxIA(JActuel,JAdverse,Pioche, Rejouer).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% MOTEUR DE REFLEXION IA %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pour le moment, l'IA choisis une carte aléatoire parmis celles qu'elle peut appeler 
% (on considère qu'elle ne peut pas demander une carte qu'elle a déja)
choisirCarteIA(Carte, JActuel) :- jeux(JActuel, Jeu),
								  % récuperation de la liste des familles que le joueur possede
								  findall(Famille, member(carte(Famille, Rang), Jeu), LfamillesDoublons),
								  %suppression des doublons
								  sort(LfamillesDoublons, Lfamilles),
								  % récupération des cartes des familles que l'adversaire a
								  findall(carte(Famille, Rang), (member(Famille, Lfamilles), carte(Famille, Rang)), LC),
								  subtract(LC, Jeu, CartesAppelable),
								  shuffle(CartesAppelable, [Carte|_]).

commentaireIA('tiens ! :''(').


jouer(J1,J2,P) :-
        repeat,
        	tourJeu(J1,J2,P),
        	tourJeu(J2,J1,P),
	    controlFinJeux(J1,J2,P), !.% end repeat

tourJeu(jh, J2, P) :- printDebutTour(' VOUS '),
					  tourJeuxHumain(jh,J2,P).

tourJeu(jia, J2, P) :- printDebutTour('  IA  '),
					   tourJeuxIA(jia,J2,P).
