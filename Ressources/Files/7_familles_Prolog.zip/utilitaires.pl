shuffle(List, Shuffled) :-
  length(List, Len),
  shuffle(Len, List, Shuffled).
shuffle(0, [], []) :- !.
shuffle(Len, List, [Elem|Tail]) :-
  RandInd is random(Len),
  nth0(RandInd, List, Elem),
  select(Elem, List, Rest),
  !,
  NewLen is Len - 1,
  shuffle(NewLen, Rest, Tail).

dans(X,[X|_]).
dans(X,[_|Q]):-dans(X,Q).