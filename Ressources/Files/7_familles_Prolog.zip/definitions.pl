% DEFINITIONS
% definition des cartes
rang(1).
rang(2).
rang(3).
rang(4).
rang(5).
rang(6).

famille(a).
famille(b).
famille(c).
famille(d).
famille(e).
famille(f).
famille(g).

carte(F,R):-famille(F),rang(R).

pioche([carte(F,R)]) :- carte(F,R),!.
pioche([carte(F,R)|Q]) :- carte(F,R), \+ dans(carte(F,R),Q), pioche(Q).
