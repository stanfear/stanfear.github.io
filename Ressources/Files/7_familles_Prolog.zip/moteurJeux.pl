%%%%%%%%%%%%%%%%%%%%%
% ACTIONS POSSIBLES %
%%%%%%%%%%%%%%%%%%%%%

demander(carte(Famille, Rang), JActuel,JAdverse,Pioche, Rejouer) :- 
		retract(jeux(Pioche, P)), retract(jeux(JActuel, J1)), retract(jeux(JAdverse, J2)),
		demander(carte(Famille, Rang), J1,J2,P, J1F,J2F,PF, Rejouer),
		asserta(jeux(Pioche, PF)), asserta(jeux(JActuel, J1F)), asserta(jeux(JAdverse, J2F)).

% l'adversaire a la carte demandée
demander(carte(Famille, Rang), J1,J2,P, J1F,J2F,P, true) :- volerCarteAdversaire(carte(Famille, Rang),J1,J2,J1F,J2F),!,	writeln(''), commentaireIA(A), writeln(A), writeln(''). 
% pioche de la bonne carte
demander(carte(Famille, Rang), J1,J2,[carte(Famille, Rang)|PF], [carte(Famille, Rang)|J1],J2,PF,true) :- !,printBonnePioche(carte(Famille, Rang)).
% pioche de la mauvaise carte
demander(_, J1,J2,[C|P], [C|J1],J2,P,false) :-!, printMauvaisePioche.
% pioche vide
demander(_, J1,J2,[], J1,J2,[],false) :- printPiocheVide.


%ajouter une carte à un jeu
ajouterCarteJeu(Carte, Jeu, [Carte|Jeu]).
% retirer une carte d'un jeu
retirerCarteJeu(Carte, [Carte|ResteJeu], ResteJeu).
retirerCarteJeu(Carte, [CarteTete|ResteJeu], [CarteTete|Jeu]) :- Carte \== CarteTete, retirerCarteJeu(Carte, ResteJeu, Jeu).

% on essaie de voler une carte à l'adversaire, renvoie faux si l'adversaire n'a pas la carte
volerCarteAdversaire(C,J1,J2,J1Final,J2Final) :- retirerCarteJeu(C, J2, J2Final), ajouterCarteJeu(C, J1, J1Final).



%%%%%%%%%%%%%%%%%%%%%%%%%
% INITIALISATION DU JEU %
%%%%%%%%%%%%%%%%%%%%%%%%%

piocher([T|PiocheRest],T,PiocheRest):- pioche([T|PiocheRest]).

genererJeux(P,J1,J2) :- genererPioche(Pinit),
                        distribuer(Pinit,7,J1,J2,P).

distribuer(Pinit, 0, [], [], Pinit) :- !.
distribuer(Pinit, NbCarte, [C1|Q1], [C2|Q2], PFinale) :- piocher(Pinit, C1, P1),
                                                         piocher(P1, C2, P2),
                                                         NbCarteNext is NbCarte -1,
                                                         distribuer(P2, NbCarteNext, Q1, Q2, PFinale).

genererPioche(P) :- findall(carte(F,R), carte(F,R),L),
                    shuffle(L, P),
                    pioche(P).




%%%%%%%%%%%%%%%%%%%%%%%%%%
% PREDICATS 'INVISIBLES' %
%%%%%%%%%%%%%%%%%%%%%%%%%%

% rearme les jeux (cas où un des jeux serait vide).
initTour(JActuel,JAdverse,Pioche) :- rearmJeux(JActuel,JAdverse,Pioche),
									 rearmJeux(JAdverse,JActuel,Pioche).

% rearmJeux/3
% le cas ou tous les jeux sont vides est traité dans le tour de jeux Humain
rearmJeux(JActuel,JAdverse,Pioche) :- 
	retract(jeux(Pioche, P)), retract(jeux(JActuel, J1)), retract(jeux(JAdverse, J2)),
	rearmJeux(J1, P, J2, J1F, PF, J2F),
	asserta(jeux(Pioche, PF)), asserta(jeux(JActuel, J1F)), asserta(jeux(JAdverse, J2F)).

% rearmJeux/6
rearmJeux([],P,J2, [Carte],PF,J2) :- pioche(P), piocher(P, Carte, PF), !.
rearmJeux([],[],J2, [Carte], [], J2F) :- shuffle(J2, J2Shuffled), piocher(J2Shuffled, Carte, J2F),!.
rearmJeux(MainJ1, Pioche, MainJ2, MainJ1, Pioche, MainJ2).

% vidage des familles finies (on les pose sur la table)
viderFamille(JActuel) :- jeux(JActuel, J),
						 points(JActuel, PJ),
						 viderFamille(J,JF), !,
						 PJF is PJ + 1,
						 retract(jeux(JActuel, J)),
						 retract(points(JActuel, PJ)),
						 asserta(points(JActuel, PJF)),
						 asserta(jeux(JActuel, JF)).
viderFamille(_).

viderFamille([carte(F,R)|Q],JF) :-  findall(Rang,member(carte(F,Rang),[carte(F,R)|Q]) ,RangsFamille), 
									length(RangsFamille, 6), !,
									findall(carte(F,Rang), member(Rang,RangsFamille), LCF),
									subtract([carte(F,R)|Q], LCF, JF),
									nl,nl,nl, write('FAMILLLLLLLLLE !!'),nl,nl,nl.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PREDICATS DE VERIFICATION %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
controlFinJeux(J1,J2,P) :- jeux(P, []),
						   jeux(J1, []),
						   jeux(J2, []).
% verifier si une carte existe
verifFamilleRangExiste(Famille, Rang) :- findall(carte(F,R), carte(F,R),L),
								   		 member(carte(Famille, Rang), L).
% verifie si un joueur a une famille
verifFamillePresenteJeu(Famille, J1) :- member(carte(Famille,_),J1).